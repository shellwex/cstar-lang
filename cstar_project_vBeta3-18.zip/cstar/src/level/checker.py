"""
C* Compiler — Level Checker (Stage 4)
Applies all narrow points to every path through every function's CFG.

Spec reference: Section 6.2 — Level System
────────────────────────────────────────────────────────────────────────────

Narrow points implemented
─────────────────────────
1. RELEASE      — every heap variable (declare … on heap) is released on
                  every path that reaches EXIT.  Transfer as owner in a
                  call counts as release.  AllocateStmt is handled separately.
2. NULL CHECK   — every 'value at ptr' dereference is preceded by a null
                  check on the same path.
3. USE-AFTER-FREE — using a variable after release is forbidden.
4. LIFETIME     — stack pointer must not outlive its target (scope-based).
5. USE-AFTER-DESTROY — method call on an object after obj.destroy.

Key bug fixes over previous version
────────────────────────────────────
• Bug #A: Release check now correctly detects heap variables declared with
  `declare … on heap` (DeclareStmt, location="heap"), NOT just AllocateStmt.
  The previous version checked only AllocateStmt — so `declare byte named buf
  on heap is 0` was never flagged as needing release.

• Bug #B: Null check now correctly handles the case where a null check
  appears in the SAME block as the dereference (IfStmt condition) by
  recognising that statements inside if-then bodies are on the TRUE path
  and the null-check guards them.  Path-level tracking resets properly.

• Bug #C: _stmts_on_path collects statements correctly from BRANCH and
  LOOP_COND blocks (which store the IfStmt / RepeatStmt as their stmt),
  without double-counting the body statements that are in separate blocks.

• Bug #D: Duplicate violations suppressed — same (kind, variable, path) is
  not reported twice.

• Bug #E: Remove debug print statements from production code.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

from ..parser import ast as A
from ..sema.analyzer import CType, ast_type_to_ctype, Diagnostic
from .cfg import CFG, CFGBuilder, BasicBlock, BlockKind


# ── Level violation ───────────────────────────────────────────────────────────

@dataclass
class LevelViolation:
    kind: str          # "release" | "null" | "lifetime" | "owner"
    message: str
    detail: str
    hint: str
    span: A.Span

    def __str__(self) -> str:
        sep = "━" * 48
        return (
            f"\n{sep}\n"
            f"LEVEL VIOLATION — {self.message}\n"
            f"{sep}\n"
            f"\nWhy this is a problem:\n"
            f"    {self.detail}\n"
            f"\nHow to fix:\n"
            f"    {self.hint}\n"
            f"\nRule: Section 6.2 — Level System\n"
            f"{sep}"
        )


# ── Heap variable tracker ─────────────────────────────────────────────────────

@dataclass
class HeapVar:
    name: str
    span: A.Span


# ── Level checker ─────────────────────────────────────────────────────────────

class LevelChecker:
    """
    Runs all narrow-point checks on a program's functions and body.

    Usage:
        checker = LevelChecker()
        violations = checker.check_program(prog)
    """

    def __init__(self) -> None:
        self.violations: list[LevelViolation] = []
        # Deduplication: set of (kind, message) already reported
        self._seen: set[tuple[str, str]] = set()

    def check_program(self, prog: A.ProgramDef) -> list[LevelViolation]:
        self.violations = []
        self._seen = set()
        builder = CFGBuilder()
        for func in prog.functions:
            cfg = builder.build(func)
            self._check_function(func, cfg)
        if prog.body:
            cfg = builder.build_from_stmts(prog.body, prog.name)
            self._check_stmts_body(cfg, prog.body)
        return self.violations

    def check_module(self, mod: A.ModuleDef) -> list[LevelViolation]:
        self.violations = []
        self._seen = set()
        builder = CFGBuilder()
        for func in mod.functions:
            cfg = builder.build(func)
            self._check_function(func, cfg)
        if mod.body:
            cfg = builder.build_from_stmts(mod.body, mod.name)
            self._check_stmts_body(cfg, mod.body)
        return self.violations

    # ── Per-function entry point ──────────────────────────────────────────────

    def _check_function(self, func: A.FunctionDef, cfg: CFG) -> None:
        heap_vars = self._collect_heap_vars(func.body)
        ptr_vars  = self._collect_pointer_vars(func.body)

        for path in cfg.all_paths():
            stmts_on_path = self._stmts_on_path(path)
            for hv in heap_vars:
                self._check_release(hv, stmts_on_path, path)
            for pv in ptr_vars:
                self._check_null(pv, stmts_on_path)
            for hv in heap_vars:
                self._check_use_after_free(hv, stmts_on_path)

        # Lifetime check (scope-based, not path-based)
        self.violations.extend(
            v for v in _run_lifetime(func, is_func=True)
            if self._dedup(v)
        )

        # Use-after-destroy check
        self._check_use_after_destroy(func.body)

    def _check_stmts_body(self, cfg: CFG, stmts: list) -> None:
        """Check a program/module body (not a function)."""
        heap_vars = self._collect_heap_vars(stmts)
        ptr_vars  = self._collect_pointer_vars(stmts)

        for path in cfg.all_paths():
            stmts_on_path = self._stmts_on_path(path)
            for hv in heap_vars:
                self._check_release(hv, stmts_on_path, path)
            for pv in ptr_vars:
                self._check_null(pv, stmts_on_path)
            for hv in heap_vars:
                self._check_use_after_free(hv, stmts_on_path)

        self.violations.extend(
            v for v in _run_lifetime(stmts, is_func=False)
            if self._dedup(v)
        )
        self._check_use_after_destroy(stmts)

    # ── Deduplication ─────────────────────────────────────────────────────────

    def _dedup(self, v: LevelViolation) -> bool:
        """Return True (and record) if this violation is new; False if duplicate."""
        key = (v.kind, v.message)
        if key in self._seen:
            return False
        self._seen.add(key)
        return True

    def _add_violation(self, v: LevelViolation) -> None:
        if self._dedup(v):
            self.violations.append(v)

    # ── Narrow point 1: Release ───────────────────────────────────────────────

    def _check_release(
        self,
        hv: HeapVar,
        stmts: list,
        path: list[BasicBlock],
    ) -> None:
        """Every path to EXIT must release every heap variable declared on that path.

        Spec Section 2.3 / 6.2:
          • `declare … on heap` creates a heap variable → must be released.
          • `allocate … for name` also allocates → must be released.
          • Transfer `as owner` in a call counts as release.
          • If the pointer is null on this path (allocation failed),
            no release is needed.
        """
        # Only check paths that reach an EXIT block
        if not path or path[-1].kind != BlockKind.EXIT:
            return

        from ..parser.ast import OwnershipMode

        # Was this variable declared/allocated on this path?
        declared_on_path = any(
            (isinstance(s, A.DeclareStmt) and s.name == hv.name and s.location == "heap")
            or (isinstance(s, A.AllocateStmt) and s.name == hv.name)
            for s in stmts
        )
        if not declared_on_path:
            return  # not allocated on this path — nothing to release

        # If null is guaranteed on this path (allocation failure branch),
        # there is no heap memory to release.
        if self._is_null_guaranteed_on_path(hv.name, path):
            return

        # Check whether released or transferred as owner anywhere on this path
        released = self._is_released_or_transferred(hv.name, stmts)

        if not released:
            is_reject_path = any(isinstance(s, A.RejectStmt) for s in stmts)
            hint = (
                f"Add 'release {hv.name}' before the 'reject' statement"
                if is_reject_path
                else f"Add 'release {hv.name}' before the function exits"
            )
            self._add_violation(LevelViolation(
                kind="release",
                message=f"Missing release for heap variable '{hv.name}'",
                detail=(
                    f"'{hv.name}' is declared on heap but not released on "
                    f"{'the error path' if is_reject_path else 'all paths'}. "
                    f"Every heap variable must be released on every path through "
                    f"the function — including error paths."
                ),
                hint=hint,
                span=hv.span,
            ))

    def _is_released_or_transferred(self, name: str, stmts: list) -> bool:
        """Return True if stmts contain release or owner-transfer for *name*."""
        from ..parser.ast import OwnershipMode
        for stmt in stmts:
            if isinstance(stmt, A.ReleaseStmt) and stmt.name == name:
                return True
            if isinstance(stmt, A.CallStmt):
                for arg_name, arg_mode, arg_expr in stmt.args:
                    if (arg_mode == OwnershipMode.OWNER
                            and isinstance(arg_expr, A.Identifier)
                            and arg_expr.name == name):
                        return True
        return False

    # ── Narrow point 2: Null check ────────────────────────────────────────────

    def _check_null(self, ptr_name: str, stmts: list) -> None:
        """Every 'value at ptr' must be preceded by a null check on the same path.

        Spec Section 2.5 / 6.2 (null narrow point):
          Pointer [ptr_name] used without a preceding null check → violation.

        A null check is recognised as:
          • `if ptr is not null` (CompareOp with op "is not null")
          • `if ptr is null … end if` followed by reject/return — after
            which we know ptr is not null (not implemented here; the
            simpler check suffices for the spec's examples).
          • `and`-compound conditions that include a null check on ptr.

        The check is path-linear: scanning statements in order, we track
        whether a null check was seen.  A dereference before a check
        triggers the violation.  A dereference INSIDE the then-body of
        `if ptr is not null` is safe (the IfStmt is in the BRANCH block;
        the then-body statements are in a separate block that only appears
        on the true path).
        """
        null_checked = False
        for stmt in stmts:
            # Null check statement — sets the checked flag
            if self._is_null_check_for(stmt, ptr_name):
                null_checked = True
                continue
            # Dereference without prior null check
            if not null_checked and self._dereferences(stmt, ptr_name):
                self._add_violation(LevelViolation(
                    kind="null",
                    message=f"Missing null check before 'value at {ptr_name}'",
                    detail=(
                        f"Pointer '{ptr_name}' is dereferenced without a prior "
                        f"null check on this path. "
                        f"In C*, every pointer dereference must be preceded by "
                        f"'if {ptr_name} is not null' on all incoming paths."
                    ),
                    hint=(
                        f"Wrap the dereference:\n"
                        f"    if {ptr_name} is not null\n"
                        f"        ... use value at {ptr_name} ...\n"
                        f"    end if"
                    ),
                    span=A.Span(0, 0),
                ))
                return  # Report once per pointer per path

    # ── Narrow point 3: Use after free ────────────────────────────────────────

    def _check_use_after_free(self, hv: HeapVar, stmts: list) -> None:
        """After release, the variable must not be used (Spec Section 2.3)."""
        released = False
        for stmt in stmts:
            if isinstance(stmt, A.ReleaseStmt) and stmt.name == hv.name:
                released = True
                continue
            if released and self._uses_var(stmt, hv.name):
                self._add_violation(LevelViolation(
                    kind="owner",
                    message=f"Use of '{hv.name}' after release",
                    detail=(
                        f"'{hv.name}' is used after being released. "
                        f"After 'release {hv.name}' the variable no longer "
                        f"has an owner and cannot be accessed."
                    ),
                    hint=(
                        f"Move the use of '{hv.name}' before 'release {hv.name}', "
                        f"or remove the use entirely."
                    ),
                    span=hv.span,
                ))
                return  # Report once per variable per path

    # ── Narrow point 5: Use after destroy ────────────────────────────────────

    def _check_use_after_destroy(self, stmts: list) -> None:
        """After obj.destroy, any method call on obj is a use-after-destroy.

        Spec Section 2.3: once an object's internal heap memory is freed
        through its destructor, the object is logically dead.
        """
        self._check_destroy_in_block(stmts)

    def _check_destroy_in_block(self, stmts: list) -> None:
        """Linearly scan statements, tracking destroyed objects."""
        destroyed: dict[str, A.Span] = {}

        for stmt in stmts:
            obj_name: Optional[str] = None
            method_name: Optional[str] = None
            stmt_span: Optional[A.Span] = None

            if isinstance(stmt, A.SimpleCallStmt):
                parts = stmt.func_name.split(".")
                if len(parts) == 2:
                    obj_name, method_name = parts
                    stmt_span = stmt.span
            elif isinstance(stmt, A.CallStmt):
                parts = stmt.func_name.split(".")
                if len(parts) == 2:
                    obj_name, method_name = parts
                    stmt_span = stmt.span

            if obj_name is not None and method_name is not None:
                if method_name == "destroy":
                    destroyed[obj_name] = stmt_span
                elif obj_name in destroyed:
                    self._add_violation(LevelViolation(
                        kind="owner",
                        message=(
                            f"Method '{method_name}' called on destroyed object '{obj_name}'"
                        ),
                        detail=(
                            f"'{obj_name}.destroy' was called earlier, freeing its internal "
                            f"heap memory. After destruction, '{obj_name}' is logically dead "
                            f"and any method call on it accesses freed memory."
                        ),
                        hint=(
                            f"Remove the call to '{obj_name}.{method_name}' after "
                            f"'{obj_name}.destroy', or restructure the code so that "
                            f"'{obj_name}' is not destroyed before all uses are complete."
                        ),
                        span=stmt_span,
                    ))

            # Recurse into nested blocks
            if isinstance(stmt, A.IfStmt):
                self._check_destroy_in_block(stmt.then_body)
                for _, body in stmt.elseif_branches:
                    self._check_destroy_in_block(body)
                if stmt.else_body:
                    self._check_destroy_in_block(stmt.else_body)
            elif isinstance(stmt, A.RepeatStmt):
                self._check_destroy_in_block(stmt.body)
            elif isinstance(stmt, A.MatchStmt):
                for case in stmt.cases:
                    self._check_destroy_in_block(case.body)

    # ── Null-guarantee helper ─────────────────────────────────────────────────

    def _is_null_guaranteed_on_path(self, ptr_name: str, path: list[BasicBlock]) -> bool:
        """Return True if this path goes through the FALSE branch of
        `if ptr_name is not null` — meaning the pointer is null here.

        Used by the release check: if we're on the null-branch after an
        allocate, the allocation failed and there's nothing to release.
        """
        for i, block in enumerate(path[:-1]):
            if block.kind not in (BlockKind.BRANCH, BlockKind.LOOP_COND):
                continue
            next_block = path[i + 1]
            for stmt in block.stmts:
                if not isinstance(stmt, A.IfStmt):
                    continue
                cond = stmt.condition
                if (isinstance(cond, A.CompareOp)
                        and cond.op == "is not null"
                        and isinstance(cond.left, A.Identifier)
                        and cond.left.name == ptr_name):
                    # True branch is succ_true; if we went elsewhere, ptr is null
                    if block.succ_true is not None and next_block is not block.succ_true:
                        return True
        return False

    # ── Collection helpers ────────────────────────────────────────────────────

    def _collect_heap_vars(self, stmts) -> list[HeapVar]:
        """Find all variables that require explicit release.

        Two sources:
          • `declare <non-pointer> on heap is …` → DeclareStmt(location="heap")
            Value types stored directly in heap — require release.
          • `allocate N bytes for name`           → AllocateStmt
            Pointer targets allocated explicitly — require release.

        NOTE: `declare pointer[…] named ptr on heap is null` declares a pointer
        variable but does NOT allocate pointee memory on its own.  Memory is
        allocated separately via `allocate N bytes for ptr`.  So PointerType
        DeclareStmts are excluded; they are tracked via AllocateStmt instead.
        """
        seen_names: set[str] = set()
        heap_vars: list[HeapVar] = []

        for stmt in self._all_stmts_deep(stmts):
            name: Optional[str] = None
            span = getattr(stmt, "span", A.Span(0, 0))

            if isinstance(stmt, A.DeclareStmt) and stmt.location == "heap":
                # Only non-pointer value types are direct heap allocations
                ct = ast_type_to_ctype(stmt.type_node)
                if ct.kind != "pointer":
                    name = stmt.name
            elif isinstance(stmt, A.AllocateStmt):
                name = stmt.name

            if name is not None and name not in seen_names:
                seen_names.add(name)
                heap_vars.append(HeapVar(name=name, span=span))

        return heap_vars

    def _collect_pointer_vars(self, stmts) -> list[str]:
        """Find all pointer variable names declared in *stmts*."""
        ptrs: list[str] = []
        seen: set[str] = set()
        for stmt in self._all_stmts_deep(stmts):
            if isinstance(stmt, A.DeclareStmt) and stmt.name not in seen:
                ct = ast_type_to_ctype(stmt.type_node)
                if ct.kind == "pointer":
                    seen.add(stmt.name)
                    ptrs.append(stmt.name)
        return ptrs

    def _all_stmts_deep(self, stmts) -> list:
        """Flatten statements including inside if/repeat/call/match bodies."""
        result = []
        for stmt in stmts:
            result.append(stmt)
            if isinstance(stmt, A.IfStmt):
                result.extend(self._all_stmts_deep(stmt.then_body))
                for _, body in stmt.elseif_branches:
                    result.extend(self._all_stmts_deep(body))
                if stmt.else_body:
                    result.extend(self._all_stmts_deep(stmt.else_body))
            elif isinstance(stmt, A.RepeatStmt):
                result.extend(self._all_stmts_deep(stmt.body))
            elif isinstance(stmt, A.CallStmt):
                for h in stmt.handlers:
                    result.extend(self._all_stmts_deep(h.body))
            elif isinstance(stmt, A.MatchStmt):
                for case in stmt.cases:
                    result.extend(self._all_stmts_deep(case.body))
        return result

    def _stmts_on_path(self, path: list[BasicBlock]) -> list:
        """Collect statements along a CFG path (in block order).

        IMPORTANT: BRANCH blocks store the IfStmt/RepeatStmt as a "marker"
        so the checker can inspect conditions.  We include those markers here.
        The actual branch-body statements live in the NORMAL child blocks and
        are included when those blocks appear on the path.
        """
        stmts = []
        for block in path:
            stmts.extend(block.stmts)
        return stmts

    # ── AST pattern matchers ──────────────────────────────────────────────────

    def _is_null_check_for(self, stmt, ptr_name: str) -> bool:
        """Does this statement perform a null check for ptr_name?"""
        if isinstance(stmt, A.IfStmt):
            return self._condition_guards_null(stmt.condition, ptr_name)
        return False

    def _condition_guards_null(self, cond, ptr_name: str) -> bool:
        """Recursively check whether a condition establishes ptr is not null.

        • `ptr is not null`              → True
        • `ptr is not null and other …`  → True (both sides of `and` hold)
        • `ptr is not null or other`     → False (`or` doesn't guarantee it)
        """
        if isinstance(cond, A.CompareOp):
            if cond.op in ("is not null", "is null"):
                if isinstance(cond.left, A.Identifier):
                    return cond.left.name == ptr_name
        elif isinstance(cond, A.LogicOp) and cond.op == "and":
            return (
                self._condition_guards_null(cond.left, ptr_name)
                or self._condition_guards_null(cond.right, ptr_name)
            )
        return False

    def _dereferences(self, stmt, ptr_name: str) -> bool:
        """Does this statement dereference ptr_name via 'value at'?"""
        return self._expr_dereferences(self._stmt_exprs(stmt), ptr_name)

    def _expr_dereferences(self, exprs: list, ptr_name: str) -> bool:
        for expr in exprs:
            if isinstance(expr, A.ValueAt):
                if isinstance(expr.pointer, A.Identifier):
                    if expr.pointer.name == ptr_name:
                        return True
        return False

    def _uses_var(self, stmt, name: str) -> bool:
        """Does this statement read or write the named variable?"""
        for expr in self._stmt_exprs(stmt):
            if isinstance(expr, A.Identifier) and expr.name == name:
                return True
        if isinstance(stmt, A.AssignStmt):
            if isinstance(stmt.target, A.Identifier) and stmt.target.name == name:
                return True
        if isinstance(stmt, A.ReleaseStmt) and stmt.name == name:
            return True
        if isinstance(stmt, A.SimpleCallStmt):
            for arg in stmt.args:
                if isinstance(arg, A.Identifier) and arg.name == name:
                    return True
        return False

    def _stmt_exprs(self, stmt) -> list:
        """Extract top-level expressions from a statement (shallow)."""
        if isinstance(stmt, A.DeclareStmt):
            return [stmt.initial_value]
        if isinstance(stmt, A.AssignStmt):
            return [stmt.value, stmt.target]
        if isinstance(stmt, A.IfStmt):
            return [stmt.condition]
        if isinstance(stmt, A.RepeatStmt):
            return [stmt.condition]
        if isinstance(stmt, A.ReturnStmt) and stmt.value:
            return [stmt.value]
        if isinstance(stmt, A.CallStmt):
            return [v for _, __, v in stmt.args]
        if isinstance(stmt, A.SimpleCallStmt):
            return list(stmt.args)
        return []


# ── Integration point for LifetimeAnalyzer ───────────────────────────────────

def _run_lifetime(func_or_stmts, is_func: bool = True):
    from .lifetime import LifetimeAnalyzer
    la = LifetimeAnalyzer()
    if is_func:
        return la.analyze_function(func_or_stmts)
    return la.analyze_stmts(func_or_stmts)
