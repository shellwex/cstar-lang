"""
C* Compiler — Control Flow Graph (CFG)
Stage 4, Step 1: Build all execution paths through a function.

Spec reference: Section 6.2 — Level System
────────────────────────────────────────────────────────────────────────────
The CFG represents every possible execution path through a function.
Each path is a sequence of BasicBlocks from ENTRY to an EXIT block.
The Level Checker applies "narrow points" (ownership, null, lifetime, release)
to every path — if ANY path fails a narrow point, the level is rejected.

Block kinds
───────────
  ENTRY       — synthetic first block (no statements); single per function
  NORMAL      — regular linear sequence of statements (no branches inside)
  BRANCH      — ends with a conditional (if, repeat, call-with-handlers)
  LOOP_COND   — head of a while-loop; condition checked here
  LOOP_BODY   — body of a loop
  MERGE       — join point after a branch; no statements
  EXIT        — function exit (return, reject, or fall-off end of body)

Edges
─────
  succ_true   — taken branch / unconditional next / loop-true
  succ_false  — not-taken branch / loop-exit / else branch

Named loops (Section 3.2)
──────────────────────────
  RepeatStmt.loop_name stores the optional name.
  stop loop[name]  / skip loop[name] targets are resolved via _loop_stack.

  _loop_stack: list of (after_block, cond_block, loop_name | None)
  stop  → jumps to after_block of innermost (or named) loop
  skip  → jumps to cond_block of innermost (or named) loop

match statement (Section 3.1)
──────────────────────────────
  Each variant becomes a BRANCH block; all merge at match_merge.

call statement handlers (Section 3.3)
──────────────────────────────────────
  Each on-error / on-success handler is a separate block.
  All handler blocks that don't exit converge at call_merge.
  This models the fact that exactly one handler runs per call invocation.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from ..parser import ast as A


# ── Block kind ────────────────────────────────────────────────────────────────

class BlockKind(Enum):
    ENTRY     = auto()
    NORMAL    = auto()
    BRANCH    = auto()
    LOOP_COND = auto()
    LOOP_BODY = auto()
    MERGE     = auto()
    EXIT      = auto()


# ── CFG node ──────────────────────────────────────────────────────────────────

@dataclass
class BasicBlock:
    id: int
    kind: BlockKind
    stmts: list = field(default_factory=list)
    # Successors
    succ_true:  Optional["BasicBlock"] = None  # taken / unconditional / loop-body
    succ_false: Optional["BasicBlock"] = None  # not-taken / loop-exit / else
    # Predecessors (filled after full graph is built)
    preds: list["BasicBlock"] = field(default_factory=list)
    # Human-readable label (for dump/debugging)
    label: str = ""

    def __repr__(self) -> str:
        return f"BB{self.id}({self.label or self.kind.name})"

    def successors(self) -> list["BasicBlock"]:
        s: list[BasicBlock] = []
        if self.succ_true  is not None:
            s.append(self.succ_true)
        if self.succ_false is not None:
            s.append(self.succ_false)
        return s

    def add_stmt(self, stmt) -> None:
        self.stmts.append(stmt)


# ── CFG container ─────────────────────────────────────────────────────────────

@dataclass
class CFG:
    func_name: str
    entry: BasicBlock
    blocks: list[BasicBlock] = field(default_factory=list)

    @property
    def exits(self) -> list[BasicBlock]:
        return [b for b in self.blocks if b.kind == BlockKind.EXIT]

    def all_paths(self) -> list[list[BasicBlock]]:
        """Return every simple path from entry to any EXIT block.

        Back-edges (loop back-edges) are detected by the visited set
        and the loop path terminates at the back-edge target (treated
        as an implicit loop-exit for path enumeration purposes).
        This avoids infinite path enumeration while still exposing
        the loop body on at least one path.
        """
        results: list[list[BasicBlock]] = []
        self._dfs(self.entry, [self.entry], {self.entry.id}, results)
        return results

    def _dfs(
        self,
        block: BasicBlock,
        path: list[BasicBlock],
        visited: set[int],
        results: list[list[BasicBlock]],
    ) -> None:
        if block.kind == BlockKind.EXIT:
            results.append(list(path))
            return
        succs = block.successors()
        if not succs:
            # Dead-end that is not EXIT — still record as a terminated path
            results.append(list(path))
            return
        for succ in succs:
            if succ.id in visited:
                # Back-edge: record path up to here (loop path ends at header)
                results.append(list(path) + [succ])
                continue
            self._dfs(succ, path + [succ], visited | {succ.id}, results)

    def dump(self) -> str:
        """Human-readable graph dump for debugging."""
        lines = [
            f"CFG for function '{self.func_name}'",
            f"  Blocks : {len(self.blocks)}",
            f"  Exits  : {len(self.exits)}",
            "",
        ]
        for b in self.blocks:
            lines.append(f"  {b!r}")
            lines.append(f"    statements: {len(b.stmts)}")
            for s in b.stmts:
                lines.append(f"      {type(s).__name__}")
            if b.succ_true:
                arrow = "→T" if b.succ_false else "→"
                lines.append(f"    {arrow} {b.succ_true!r}")
            if b.succ_false:
                lines.append(f"    →F {b.succ_false!r}")
            lines.append("")
        return "\n".join(lines)


# ── CFG Builder ───────────────────────────────────────────────────────────────

# Internal sentinel returned when a statement sequence always exits
# (i.e. every path through it ends with return/reject/stop/skip).
_EXITS = None


class CFGBuilder:
    """
    Builds a CFG from a FunctionDef or a raw statement list.

    Public API
    ──────────
        builder = CFGBuilder()
        cfg = builder.build(func_def)            # FunctionDef
        cfg = builder.build_from_stmts(stmts)   # program body / module body
    """

    def __init__(self) -> None:
        self._counter: int = 0
        self._all_blocks: list[BasicBlock] = []
        # Stack of loop frames for stop/skip resolution:
        # each frame is (after_block, cond_block, loop_name_or_None)
        self._loop_stack: list[tuple[BasicBlock, BasicBlock, Optional[str]]] = []

    # ── Public builders ───────────────────────────────────────────────────────

    def build(self, func: A.FunctionDef) -> CFG:
        """Build CFG for a function definition."""
        self._reset()
        entry     = self._new_block(BlockKind.ENTRY,  "entry")
        exit_blk  = self._new_block(BlockKind.EXIT,   "exit")

        final = self._build_stmts(func.body, entry, exit_blk)
        if final is not None:
            self._link(final, exit_blk)

        self._fill_preds()
        return CFG(func_name=func.name, entry=entry, blocks=self._all_blocks)

    def build_from_stmts(self, stmts: list, name: str = "<body>") -> CFG:
        """Build CFG from a raw list of statements (program body, module init)."""
        self._reset()
        entry    = self._new_block(BlockKind.ENTRY, "entry")
        exit_blk = self._new_block(BlockKind.EXIT,  "exit")

        final = self._build_stmts(stmts, entry, exit_blk)
        if final is not None:
            self._link(final, exit_blk)

        self._fill_preds()
        return CFG(func_name=name, entry=entry, blocks=self._all_blocks)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _reset(self) -> None:
        self._counter    = 0
        self._all_blocks = []
        self._loop_stack = []

    # ── Statement sequence ────────────────────────────────────────────────────

    def _build_stmts(
        self,
        stmts: list,
        current: BasicBlock,
        exit_blk: BasicBlock,
    ) -> Optional[BasicBlock]:
        """Append *stmts* to *current*, creating new blocks as needed.

        Returns the last live block (where the next statement should be
        appended), or None if all paths through *stmts* terminate
        (return / reject / stop / skip that exits the function).
        """
        for stmt in stmts:
            if current is None:
                # Dead code after a terminator — skip
                break
            current = self._build_stmt(stmt, current, exit_blk)
        return current

    def _build_stmt(
        self,
        stmt,
        current: BasicBlock,
        exit_blk: BasicBlock,
    ) -> Optional[BasicBlock]:
        """Process a single statement; return continuation block or None."""

        # ── if / otherwise ────────────────────────────────────────────────────
        if isinstance(stmt, A.IfStmt):
            return self._build_if(stmt, current, exit_blk)

        # ── match ─────────────────────────────────────────────────────────────
        if isinstance(stmt, A.MatchStmt):
            return self._build_match(stmt, current, exit_blk)

        # ── repeat while / named loop ─────────────────────────────────────────
        if isinstance(stmt, A.RepeatStmt):
            return self._build_repeat(stmt, current, exit_blk)

        # ── call … on error / on success … end call ───────────────────────────
        if isinstance(stmt, A.CallStmt):
            return self._build_call(stmt, current, exit_blk)

        # ── return ────────────────────────────────────────────────────────────
        if isinstance(stmt, A.ReturnStmt):
            current.add_stmt(stmt)
            self._link(current, exit_blk)
            return None

        # ── reject ────────────────────────────────────────────────────────────
        if isinstance(stmt, A.RejectStmt):
            current.add_stmt(stmt)
            reject_exit = self._new_block(
                BlockKind.EXIT, f"reject_{stmt.error_name}"
            )
            self._link(current, reject_exit)
            return None

        # ── stop [loop[name]] — break ─────────────────────────────────────────
        if isinstance(stmt, A.StopStmt):
            current.add_stmt(stmt)
            after_blk = self._resolve_loop_after(stmt.loop_name)
            if after_blk is not None:
                self._link(current, after_blk)
            else:
                # stop outside a loop or unresolved name — link to exit
                self._link(current, exit_blk)
            return None

        # ── skip [loop[name]] — continue ──────────────────────────────────────
        if isinstance(stmt, A.SkipStmt):
            current.add_stmt(stmt)
            cond_blk = self._resolve_loop_cond(stmt.loop_name)
            if cond_blk is not None:
                self._link(current, cond_blk)
            else:
                self._link(current, exit_blk)
            return None

        # ── plain statement (declare, assign, release, allocate, …) ──────────
        current.add_stmt(stmt)
        return current

    # ── If / otherwise if / otherwise ────────────────────────────────────────

    def _build_if(
        self,
        stmt: A.IfStmt,
        current: BasicBlock,
        exit_blk: BasicBlock,
    ) -> Optional[BasicBlock]:
        """
        Structure produced:
            current  (BRANCH)  →T  then_blk
                               →F  [elif_blk | else_blk | merge]

            all live ends → merge (MERGE)
        """
        # The current block becomes the branch on the condition
        current.kind = BlockKind.BRANCH
        current.add_stmt(stmt)   # condition lives here for checker inspection

        merge = self._new_block(BlockKind.MERGE, "if_merge")

        # ── then branch ───────────────────────────────────────────────────────
        then_blk = self._new_block(BlockKind.NORMAL, "if_then")
        self._link_true(current, then_blk)
        then_end = self._build_stmts(stmt.then_body, then_blk, exit_blk)
        if then_end is not None:
            self._link(then_end, merge)

        # ── elif chain ────────────────────────────────────────────────────────
        prev_false_src = current
        for elif_cond, elif_body in stmt.elseif_branches:
            elif_blk = self._new_block(BlockKind.BRANCH, "elif")
            elif_blk.add_stmt(
                A.IfStmt(
                    span=elif_cond.span,
                    condition=elif_cond,
                    then_body=elif_body,
                    elseif_branches=[],
                    else_body=None,
                )
            )
            self._link_false(prev_false_src, elif_blk)

            elif_body_blk = self._new_block(BlockKind.NORMAL, "elif_body")
            self._link_true(elif_blk, elif_body_blk)
            elif_end = self._build_stmts(elif_body, elif_body_blk, exit_blk)
            if elif_end is not None:
                self._link(elif_end, merge)

            prev_false_src = elif_blk

        # ── else branch ───────────────────────────────────────────────────────
        if stmt.else_body is not None:
            else_blk = self._new_block(BlockKind.NORMAL, "if_else")
            self._link_false(prev_false_src, else_blk)
            else_end = self._build_stmts(stmt.else_body, else_blk, exit_blk)
            if else_end is not None:
                self._link(else_end, merge)
        else:
            # No else → false branch falls through to merge
            self._link_false(prev_false_src, merge)

        # If merge has no successors pointing to it, all paths exited.
        # We cannot use merge.preds here because _fill_preds hasn't run yet.
        # Instead, check whether any block was linked to merge.
        merge_has_pred = any(
            b.succ_true is merge or b.succ_false is merge
            for b in self._all_blocks
        )
        if not merge_has_pred:
            return None
        return merge

    # ── match statement ───────────────────────────────────────────────────────

    def _build_match(
        self,
        stmt: A.MatchStmt,
        current: BasicBlock,
        exit_blk: BasicBlock,
    ) -> Optional[BasicBlock]:
        """
        Each when-variant becomes a BRANCH+BODY pair.
        All live ends converge at match_merge.

        Structure:
            current → case0_blk →T case0_body
                                →F case1_blk →T case1_body
                                             →F ...
        All case bodies → match_merge
        """
        current.add_stmt(stmt)
        merge = self._new_block(BlockKind.MERGE, "match_merge")
        prev: BasicBlock = current

        for case in stmt.cases:
            case_blk = self._new_block(BlockKind.BRANCH, f"match_when_{case.variant_name}")
            if prev is current:
                # First case hangs off current (become BRANCH)
                current.kind = BlockKind.BRANCH
                self._link_true(prev, case_blk)
            else:
                self._link_false(prev, case_blk)

            body_blk = self._new_block(BlockKind.NORMAL, f"match_body_{case.variant_name}")
            self._link_true(case_blk, body_blk)
            body_end = self._build_stmts(case.body, body_blk, exit_blk)
            if body_end is not None:
                self._link(body_end, merge)

            prev = case_blk

        # Last case has no false branch — falls through to merge
        self._link_false(prev, merge)

        merge_has_pred = any(
            b.succ_true is merge or b.succ_false is merge
            for b in self._all_blocks
        )
        if not merge_has_pred:
            return None
        return merge

    # ── repeat while ─────────────────────────────────────────────────────────

    def _build_repeat(
        self,
        stmt: A.RepeatStmt,
        current: BasicBlock,
        exit_blk: BasicBlock,
    ) -> Optional[BasicBlock]:
        """
        Loop structure (Section 3.2):

            current → cond_blk (LOOP_COND)
                         →T  body_blk (LOOP_BODY)
                         →F  after_blk (NORMAL)

        Back-edge: body_end → cond_blk
        stop  → after_blk
        skip  → cond_blk

        For maximum iterations (Section 3.2):
            The limit check is an additional branch inside the body.
            Body checks `iteration count > max_iterations` →T limit_blk → exit_blk
                                                           →F rest of body
        """
        cond_blk  = self._new_block(BlockKind.LOOP_COND, "loop_cond")
        body_blk  = self._new_block(BlockKind.LOOP_BODY, "loop_body")
        after_blk = self._new_block(BlockKind.NORMAL,    "loop_after")

        # Entry into loop
        self._link(current, cond_blk)
        cond_blk.add_stmt(stmt)   # condition expression stored here

        self._link_true(cond_blk,  body_blk)
        self._link_false(cond_blk, after_blk)

        # Push loop frame so stop/skip can resolve to this loop
        self._loop_stack.append((after_blk, cond_blk, stmt.loop_name))

        # Build body — stop → after_blk, skip → cond_blk (via loop stack)
        body_end = self._build_stmts(stmt.body, body_blk, exit_blk)

        # Handle maximum iterations limit handler as extra exit path
        if stmt.max_iterations is not None and stmt.on_limit_body:
            limit_blk = self._new_block(BlockKind.EXIT, "loop_limit_reached")
            # Build limit handler stmts
            limit_end = self._build_stmts(stmt.on_limit_body, limit_blk, exit_blk)
            if limit_end is not None:
                self._link(limit_end, exit_blk)
            # The after_blk gets an extra predecessor to model the limit path
            # (Limit is modelled conservatively as an extra exit from body)

        # Pop loop frame
        self._loop_stack.pop()

        # Back-edge: end of body → condition
        if body_end is not None:
            self._link(body_end, cond_blk)

        return after_blk

    # ── call … on error / on success ─────────────────────────────────────────

    def _build_call(
        self,
        stmt: A.CallStmt,
        current: BasicBlock,
        exit_blk: BasicBlock,
    ) -> Optional[BasicBlock]:
        """
        Model a call-with-handlers block (Section 3.3):

            current (BRANCH) — holds the CallStmt
                 Each handler is an independent successor block.
                 All live handler ends → call_merge (MERGE).

        The handlers model that EXACTLY ONE handler executes per call.
        We model this conservatively: every handler is reachable from
        the call site.  This ensures the Level Checker sees that:
          • release must happen in EACH handler, not just one.
          • null checks must precede every dereference in every handler.

        Implementation: we create a linear false-chain for handlers,
        which means the CFG paths enumerate each handler independently.
        """
        current.add_stmt(stmt)
        current.kind = BlockKind.BRANCH

        merge = self._new_block(BlockKind.MERGE, f"call_{stmt.func_name}_merge")
        has_continuation = False

        # Build each handler as a separate block reachable from current.
        # We chain them: current →(true) h0; h0 →(false) h1; h1 →(false) h2 …
        # The DFS will enumerate: current→h0, current→h0→h1, …
        # — that correctly produces one path per handler combination.
        # For the Level checker purposes, each path visits exactly one
        # handler's statements (the last reachable one in the chain).
        #
        # Better model: all handlers directly reachable from current.
        # We use succ_true for first handler and a fan-out list of
        # direct connections stored as extra blocks chained as false-chain
        # from current.  Each chain step "bypasses" all previous handlers.

        prev_branch = current
        for i, handler in enumerate(stmt.handlers):
            h_blk = self._new_block(
                BlockKind.NORMAL,
                f"call_{stmt.func_name}_h{i}_"
                + handler.kind
                + (f"_{handler.error_name}" if handler.error_name else ""),
            )

            if i == 0:
                self._link_true(prev_branch, h_blk)
            else:
                # Create a bypass BRANCH block so this handler is reachable
                # independently.
                bypass = self._new_block(
                    BlockKind.BRANCH,
                    f"call_{stmt.func_name}_bypass{i}",
                )
                self._link_false(prev_branch, bypass)
                self._link_true(bypass, h_blk)
                prev_branch = bypass

            h_end = self._build_stmts(handler.body, h_blk, exit_blk)
            if h_end is not None:
                self._link(h_end, merge)
                has_continuation = True

        # If there's only one handler and it always exits, no merge needed
        if has_continuation:
            return merge
        return None

    # ── Loop name resolution ──────────────────────────────────────────────────

    def _resolve_loop_after(self, name: Optional[str]) -> Optional[BasicBlock]:
        """Resolve the after_block for stop [loop[name]]."""
        if not self._loop_stack:
            return None
        if name is None:
            # Innermost loop
            return self._loop_stack[-1][0]
        # Named loop — search from innermost outward
        for after_blk, _cond, loop_name in reversed(self._loop_stack):
            if loop_name == name:
                return after_blk
        return None

    def _resolve_loop_cond(self, name: Optional[str]) -> Optional[BasicBlock]:
        """Resolve the cond_block for skip [loop[name]]."""
        if not self._loop_stack:
            return None
        if name is None:
            return self._loop_stack[-1][1]
        for _after, cond_blk, loop_name in reversed(self._loop_stack):
            if loop_name == name:
                return cond_blk
        return None

    # ── Graph primitives ──────────────────────────────────────────────────────

    def _new_block(self, kind: BlockKind, label: str = "") -> BasicBlock:
        b = BasicBlock(id=self._counter, kind=kind, label=label)
        self._counter += 1
        self._all_blocks.append(b)
        return b

    def _link(self, src: BasicBlock, dst: BasicBlock) -> None:
        """Unconditional edge — only sets succ_true if not already set."""
        if src.succ_true is None:
            src.succ_true = dst
        # If already set, the edge is a duplicate (shouldn't happen in a
        # well-formed CFG, but guard against infinite linking loops).

    def _link_true(self, src: BasicBlock, dst: BasicBlock) -> None:
        """Set the taken / true-branch successor."""
        src.succ_true = dst

    def _link_false(self, src: BasicBlock, dst: BasicBlock) -> None:
        """Set the not-taken / false-branch / else successor."""
        src.succ_false = dst

    def _fill_preds(self) -> None:
        """Back-fill predecessor lists after all edges are established."""
        for b in self._all_blocks:
            for succ in b.successors():
                if b not in succ.preds:
                    succ.preds.append(b)
