"""
C* Compiler — Lifetime Analyzer (Stage 4, Step 4)
Based on Section 6.2 — Level System

Lifetime narrow point:
    "В этой точке кода — жива ли цель этого указателя?"

A pointer outlives its target when:
    1. A variable's address is taken inside a scope block (if/repeat)
    2. The pointer was declared in an OUTER scope
    3. → The pointer will outlive the target as soon as the block exits

Algorithm (ASSIGNMENT-TIME detection):
    - Track every variable's declaration scope depth in var_scopes
    - When `ptr is address of x` is encountered:
        - ptr_scope  = var_scopes.get(ptr_name)   (where ptr was declared)
        - x_scope    = var_scopes.get(x_name)     (where x was declared)
        - If x_scope > ptr_scope → VIOLATION (x lives shorter than ptr)
    - After any inner scope exits, also mark escaped dangling pointers
      so that `value at ptr` in the outer scope is caught too.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

from ..parser import ast as A
from .checker import LevelViolation


@dataclass
class TargetInfo:
    """Where a pointer's target was declared."""
    target_name: str
    target_scope: int    # scope depth where target was declared
    ptr_scope: int       # scope depth where the pointer itself lives
    dead: bool           # True once the target's scope has exited
    span: A.Span


@dataclass
class LifetimeAnalyzer:
    violations: list[LevelViolation] = field(default_factory=list)

    def analyze_function(self, func: A.FunctionDef) -> list[LevelViolation]:
        self.violations = []
        var_scopes: dict[str, int] = {}
        ptr_targets: dict[str, TargetInfo] = {}
        self._analyze_stmts(func.body, ptr_targets, var_scopes, scope_depth=0)

        # Bug #20 fix — Section 2.1 "a pointer must not outlive its target":
        # If the function returns a named pointer variable and that variable
        # was assigned `address of` a local variable declared inside the function
        # body, the returned pointer is a dangling pointer — the local variable
        # is destroyed when the function exits.
        if func.return_name and func.return_name in ptr_targets:
            info = ptr_targets[func.return_name]
            if info.target_name in var_scopes:
                # target_name is a local variable (declared in func.body)
                self.violations.append(LevelViolation(
                    kind="lifetime",
                    message=(
                        f"Function '{func.name}' returns a pointer to local "
                        f"variable '{info.target_name}'"
                    ),
                    detail=(
                        f"'{info.target_name}' is a local variable declared inside "
                        f"function '{func.name}'. When the function returns, "
                        f"'{info.target_name}' is destroyed and the returned pointer "
                        f"becomes a dangling pointer — it points to invalid stack memory. "
                        f"In C*, Section 2.1, a pointer must never outlive its target. "
                        f"A function may only return a pointer to heap-allocated memory "
                        f"or to a parameter declared 'as access'."
                    ),
                    hint=(
                        f"Allocate '{info.target_name}' on the heap instead of the stack, "
                        f"or return the value directly rather than a pointer to it."
                    ),
                    span=info.span,
                ))

        return self.violations

    def analyze_stmts(self, stmts: list) -> list[LevelViolation]:
        self.violations = []
        var_scopes: dict[str, int] = {}
        ptr_targets: dict[str, TargetInfo] = {}
        self._analyze_stmts(stmts, ptr_targets, var_scopes, scope_depth=0)
        return self.violations

    # ── Statement walker ──────────────────────────────────────────────────────

    def _analyze_stmts(
        self,
        stmts: list,
        ptr_targets: dict[str, TargetInfo],
        var_scopes: dict[str, int],
        scope_depth: int,
    ) -> None:
        for stmt in stmts:
            self._analyze_stmt(stmt, ptr_targets, var_scopes, scope_depth)

    def _analyze_stmt(
        self,
        stmt,
        ptr_targets: dict[str, TargetInfo],
        var_scopes: dict[str, int],
        scope_depth: int,
    ) -> None:

        if isinstance(stmt, A.DeclareStmt):
            # Record where this variable is declared
            var_scopes[stmt.name] = scope_depth
            self._check_declare(stmt, ptr_targets, var_scopes, scope_depth)

        elif isinstance(stmt, A.AssignStmt):
            self._check_assign(stmt, ptr_targets, var_scopes, scope_depth)

        elif isinstance(stmt, A.IfStmt):
            # Inner scope — copy of both dicts
            inner_ptrs  = dict(ptr_targets)
            inner_scopes = dict(var_scopes)
            self._analyze_stmts(stmt.then_body, inner_ptrs, inner_scopes, scope_depth + 1)
            # Propagate dangling pointers back to outer scope
            self._expire_scope(ptr_targets, inner_ptrs, scope_depth + 1)

            for _, elif_body in stmt.elseif_branches:
                inner_ptrs2  = dict(ptr_targets)
                inner_scopes2 = dict(var_scopes)
                self._analyze_stmts(elif_body, inner_ptrs2, inner_scopes2, scope_depth + 1)
                self._expire_scope(ptr_targets, inner_ptrs2, scope_depth + 1)

            if stmt.else_body:
                inner_ptrs3  = dict(ptr_targets)
                inner_scopes3 = dict(var_scopes)
                self._analyze_stmts(stmt.else_body, inner_ptrs3, inner_scopes3, scope_depth + 1)
                self._expire_scope(ptr_targets, inner_ptrs3, scope_depth + 1)

        elif isinstance(stmt, A.RepeatStmt):
            inner_ptrs  = dict(ptr_targets)
            inner_scopes = dict(var_scopes)
            self._analyze_stmts(stmt.body, inner_ptrs, inner_scopes, scope_depth + 1)
            self._expire_scope(ptr_targets, inner_ptrs, scope_depth + 1)

        elif isinstance(stmt, A.ReturnStmt):
            if stmt.value:
                self._check_expr_use(stmt.value, ptr_targets, scope_depth, stmt)

        elif isinstance(stmt, A.CallStmt):
            for _, __, arg_expr in stmt.args:
                self._check_expr_use(arg_expr, ptr_targets, scope_depth, stmt)
            for handler in stmt.handlers:
                inner_ptrs  = dict(ptr_targets)
                inner_scopes = dict(var_scopes)
                self._analyze_stmts(handler.body, inner_ptrs, inner_scopes, scope_depth + 1)

        elif isinstance(stmt, A.SimpleCallStmt):
            for arg in stmt.args:
                self._check_expr_use(arg, ptr_targets, scope_depth, stmt)

    # ── Check declare ─────────────────────────────────────────────────────────

    def _check_declare(
        self,
        stmt: A.DeclareStmt,
        ptr_targets: dict[str, TargetInfo],
        var_scopes: dict[str, int],
        scope_depth: int,
    ) -> None:
        if isinstance(stmt.initial_value, A.AddressOf):
            self._record_address_of(
                ptr_name=stmt.name,
                target_name=stmt.initial_value.name,
                ptr_decl_scope=scope_depth,   # ptr declared here
                var_scopes=var_scopes,
                ptr_targets=ptr_targets,
                span=stmt.span,
            )
        elif isinstance(stmt.initial_value, A.ValueAt):
            self._check_expr_use(stmt.initial_value, ptr_targets, scope_depth, stmt)

    # ── Check assign ──────────────────────────────────────────────────────────

    def _check_assign(
        self,
        stmt: A.AssignStmt,
        ptr_targets: dict[str, TargetInfo],
        var_scopes: dict[str, int],
        scope_depth: int,
    ) -> None:
        if isinstance(stmt.value, A.AddressOf):
            if isinstance(stmt.target, A.Identifier):
                ptr_name    = stmt.target.name
                target_name = stmt.value.name
                # ptr was declared earlier — find its scope
                ptr_decl_scope = var_scopes.get(ptr_name, scope_depth)
                self._record_address_of(
                    ptr_name=ptr_name,
                    target_name=target_name,
                    ptr_decl_scope=ptr_decl_scope,
                    var_scopes=var_scopes,
                    ptr_targets=ptr_targets,
                    span=stmt.span,
                )
        else:
            self._check_expr_use(stmt.value, ptr_targets, scope_depth, stmt)

    # ── Core: record address-of and check lifetime at assignment time ─────────

    def _record_address_of(
        self,
        ptr_name: str,
        target_name: str,
        ptr_decl_scope: int,
        var_scopes: dict[str, int],
        ptr_targets: dict[str, TargetInfo],
        span: A.Span,
    ) -> None:
        """
        Called when `ptr_name is address of target_name`.

        Key rule (Section 2.1):
            If target lives in a NARROWER scope than the pointer,
            the pointer will outlive its target → VIOLATION.

        Narrower = higher scope_depth number.
        """
        target_scope = var_scopes.get(target_name, ptr_decl_scope)

        if target_scope > ptr_decl_scope:
            # TARGET lives in a deeper (shorter-lived) scope than POINTER
            # → as soon as the inner block exits, pointer is dangling
            self.violations.append(LevelViolation(
                kind="lifetime",
                message=(
                    f"Pointer '{ptr_name}' will outlive its target '{target_name}'"
                ),
                detail=(
                    f"'{target_name}' is declared inside a block (scope depth {target_scope}). "
                    f"'{ptr_name}' is declared at scope depth {ptr_decl_scope} "
                    f"and will still exist when '{target_name}' dies at block exit. "
                    f"In C*, a pointer must never outlive the variable it points to. "
                    f"Stack variables cannot be pointed to beyond their block."
                ),
                hint=(
                    f"Move '{target_name}' to the same scope as '{ptr_name}', "
                    f"or declare it on the heap, "
                    f"or move all uses of 'value at {ptr_name}' "
                    f"inside the same block as '{target_name}'."
                ),
                span=span,
            ))
            # Record with dead=False for now — _expire_scope will mark it dead
            # when the inner block actually exits (avoiding false positives for
            # uses that are still inside the same block as the target).
            ptr_targets[ptr_name] = TargetInfo(
                target_name=target_name,
                target_scope=target_scope,
                ptr_scope=ptr_decl_scope,
                dead=False,
                span=span,
            )
        else:
            # Safe: target lives at least as long as the pointer
            ptr_targets[ptr_name] = TargetInfo(
                target_name=target_name,
                target_scope=target_scope,
                ptr_scope=ptr_decl_scope,
                dead=False,
                span=span,
            )

    # ── Check expr for value-at of dead pointer ───────────────────────────────

    def _check_expr_use(
        self,
        expr,
        ptr_targets: dict[str, TargetInfo],
        scope_depth: int,
        context_stmt,
    ) -> None:
        """Check if a ValueAt dereferences a pointer whose target is dead."""
        if isinstance(expr, A.ValueAt):
            if isinstance(expr.pointer, A.Identifier):
                ptr_name = expr.pointer.name
                if ptr_name in ptr_targets:
                    info = ptr_targets[ptr_name]
                    if info.dead:
                        self.violations.append(LevelViolation(
                            kind="lifetime",
                            message=(
                                f"Use of 'value at {ptr_name}' — "
                                f"target '{info.target_name}' is already dead"
                            ),
                            detail=(
                                f"'{info.target_name}' was declared inside a block "
                                f"that has already exited. "
                                f"'{ptr_name}' now points to invalid stack memory. "
                                f"In C*, dereferencing a dangling pointer is forbidden."
                            ),
                            hint=(
                                f"Move the use of 'value at {ptr_name}' inside "
                                f"the same block where '{info.target_name}' is declared, "
                                f"or declare '{info.target_name}' at a wider scope."
                            ),
                            span=info.span,
                        ))

        # Recurse into sub-expressions
        if isinstance(expr, A.BinaryOp):
            self._check_expr_use(expr.left,  ptr_targets, scope_depth, context_stmt)
            self._check_expr_use(expr.right, ptr_targets, scope_depth, context_stmt)
        elif isinstance(expr, A.CompareOp):
            self._check_expr_use(expr.left,  ptr_targets, scope_depth, context_stmt)
            self._check_expr_use(expr.right, ptr_targets, scope_depth, context_stmt)
        elif isinstance(expr, A.LogicOp):
            self._check_expr_use(expr.left,  ptr_targets, scope_depth, context_stmt)
            self._check_expr_use(expr.right, ptr_targets, scope_depth, context_stmt)
        elif isinstance(expr, A.NotOp):
            self._check_expr_use(expr.operand, ptr_targets, scope_depth, context_stmt)

    # ── Expire scope: propagate dangling pointers to outer ───────────────────

    def _expire_scope(
        self,
        outer: dict[str, TargetInfo],
        inner: dict[str, TargetInfo],
        inner_depth: int,
    ) -> None:
        """
        After an inner scope exits, propagate pointer assignments back.
        Any pointer whose target lived only in the inner scope is now dangling.
        """
        for ptr_name, info in inner.items():
            if info.target_scope >= inner_depth:
                # Target lived inside the inner scope — now dead
                outer[ptr_name] = TargetInfo(
                    target_name=info.target_name,
                    target_scope=info.target_scope,
                    ptr_scope=info.ptr_scope,
                    dead=True,
                    span=info.span,
                )
            else:
                # Target lives in outer scope or higher — still valid
                outer[ptr_name] = info
