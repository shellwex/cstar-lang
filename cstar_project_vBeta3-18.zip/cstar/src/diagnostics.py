"""
C* Compiler — Diagnostic System
Based on Section 6 — Compiler and Level

Exact format from spec:

    COMPILATION REJECTED
    Stage 3 — Type Checking

    ✗ [filename]  line [N]  col [N]
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    [source line]
        [spaces]^[~~~~~]
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    What happened:
        [message]

    Why this is a problem:
        [detail]

    How to fix:
        [hint]

    Rule: [section reference]

    Result:  REJECTED at Stage [N] — [stage name]
             [N] error(s) found.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


# ── Stage names (from spec) ───────────────────────────────────────────────────

class Stage(Enum):
    LEXICAL   = (1, "Lexical Analysis")
    SYNTAX    = (2, "Syntax Analysis")
    TYPE      = (3, "Type Checking")
    LEVEL     = (4, "Level Traversal")
    OPTIMIZE  = (5, "Optimization")
    CODEGEN   = (6, "Code Generation")
    LINKING   = (7, "Linking")

    def __init__(self, number: int, label: str) -> None:
        self.number = number
        self.label  = label

    def __str__(self) -> str:
        return f"Stage {self.number} — {self.label}"


# ── Severity ──────────────────────────────────────────────────────────────────

class Severity(Enum):
    ERROR   = "error"
    WARNING = "warning"
    NOTE    = "note"


# ── Diagnostic ────────────────────────────────────────────────────────────────

@dataclass
class Diagnostic:
    severity:  Severity
    stage:     Stage
    message:   str              # short one-line description
    filename:  str = "<input>"
    line:      int = 0
    col:       int = 0
    length:    int = 1          # how many chars to underline
    source_line: str = ""       # the actual source line text
    detail:    str = ""         # "Why this is a problem"
    hint:      str = ""         # "How to fix"
    rule:      str = ""         # spec section reference

    SEP = "━" * 56

    def format(self) -> str:
        lines = []

        # ── Header ───────────────────────────────────────────────
        icon = "✗" if self.severity == Severity.ERROR else "⚠" if self.severity == Severity.WARNING else "ℹ"
        loc  = f"line {self.line}  col {self.col}" if self.line else ""
        lines.append(f"\n{icon}  {self.filename}  {loc}")
        lines.append(self.SEP)

        # ── Source line + caret ───────────────────────────────────
        if self.source_line:
            # Show line number gutter
            gutter = f"  {self.line} │ "
            lines.append(f"{gutter}{self.source_line}")

            # Caret line
            pad    = " " * (len(gutter) + self.col - 1)
            squig  = "^" + "~" * max(0, self.length - 1)
            lines.append(f"{pad}{squig}")
            lines.append("")

        # ── Message ───────────────────────────────────────────────
        lines.append(f"    {self.message}")

        # ── Detail ────────────────────────────────────────────────
        if self.detail:
            lines.append("")
            lines.append("    Why this is a problem:")
            for part in self.detail.strip().splitlines():
                lines.append(f"        {part.strip()}")

        # ── Hint ──────────────────────────────────────────────────
        if self.hint:
            lines.append("")
            lines.append("    How to fix:")
            for part in self.hint.strip().splitlines():
                lines.append(f"        {part.strip()}")

        # ── Rule ──────────────────────────────────────────────────
        if self.rule:
            lines.append("")
            lines.append(f"    Rule: {self.rule}")

        lines.append(self.SEP)
        return "\n".join(lines)

    def __str__(self) -> str:
        return self.format()


# ── Diagnostic builder ────────────────────────────────────────────────────────

class DiagnosticBuilder:
    """
    Builds Diagnostic objects with source-line context.

    Usage:
        builder = DiagnosticBuilder(source_lines, filename)
        diag = builder.error(Stage.TYPE, span, "message", detail="...", hint="...")
    """

    def __init__(self, source: str, filename: str = "<input>") -> None:
        self._lines    = source.splitlines()
        self._filename = filename

    def error(
        self,
        stage: Stage,
        line: int,
        col: int,
        length: int,
        message: str,
        detail:  str = "",
        hint:    str = "",
        rule:    str = "",
    ) -> Diagnostic:
        return self._make(Severity.ERROR, stage, line, col, length,
                          message, detail, hint, rule)

    def warning(
        self,
        stage: Stage,
        line: int,
        col: int,
        length: int,
        message: str,
        detail:  str = "",
        hint:    str = "",
        rule:    str = "",
    ) -> Diagnostic:
        return self._make(Severity.WARNING, stage, line, col, length,
                          message, detail, hint, rule)

    def _make(
        self,
        severity: Severity,
        stage:    Stage,
        line:     int,
        col:      int,
        length:   int,
        message:  str,
        detail:   str,
        hint:     str,
        rule:     str,
    ) -> Diagnostic:
        src_line = ""
        if 1 <= line <= len(self._lines):
            src_line = self._lines[line - 1]
        return Diagnostic(
            severity    = severity,
            stage       = stage,
            message     = message,
            filename    = self._filename,
            line        = line,
            col         = col,
            length      = length,
            source_line = src_line,
            detail      = detail,
            hint        = hint,
            rule        = rule,
        )


# ── Compilation result ────────────────────────────────────────────────────────

@dataclass
class CompilationResult:
    success:     bool
    stage:       Optional[Stage]
    diagnostics: list[Diagnostic] = field(default_factory=list)
    ir:          str = ""

    SEP = "━" * 56

    @property
    def errors(self) -> list[Diagnostic]:
        return [d for d in self.diagnostics if d.severity == Severity.ERROR]

    @property
    def warnings(self) -> list[Diagnostic]:
        return [d for d in self.diagnostics if d.severity == Severity.WARNING]

    def print_all(self) -> None:
        """Print all diagnostics then the final result line."""
        for d in self.diagnostics:
            print(d.format())

        print(f"\n{self.SEP}")
        if self.success:
            print("Result:  SUCCESS")
        else:
            stage_str = str(self.stage) if self.stage else "Unknown Stage"
            print(f"Result:  REJECTED at {stage_str}")
            err_count = len(self.errors)
            warn_count = len(self.warnings)
            if err_count:
                print(f"         {err_count} error(s) found.")
            if warn_count:
                print(f"         {warn_count} warning(s).")
        print(self.SEP)


# ── Conversion helpers ────────────────────────────────────────────────────────
# Convert existing LexError / ParseError / sema Diagnostic / LevelViolation
# to the new Diagnostic format.

def from_lex_error(exc, source: str, filename: str) -> Diagnostic:
    from ..lexer.lexer import LexError
    builder = DiagnosticBuilder(source, filename)
    span    = getattr(exc, "span", None)
    line    = span.line if span else 1
    col     = span.col  if span else 1
    return builder.error(
        Stage.LEXICAL, line, col, 1,
        str(exc).split("] ", 1)[-1],   # strip [line:col] prefix
        detail="The lexer encountered a character that is not part of the C* alphabet.",
        hint="Check Section 1.1 — only ASCII letters, digits, and: [ ] ( ) \" _ . , : -- are allowed.",
        rule="Section 1.1 — Alphabet",
    )


def from_parse_error(exc, source: str, filename: str) -> Diagnostic:
    builder = DiagnosticBuilder(source, filename)
    span    = getattr(exc, "span", None)
    line    = span.line if span else 1
    col     = span.col  if span else 1
    msg     = str(exc).split("PARSE ERROR: ", 1)[-1]
    return builder.error(
        Stage.SYNTAX, line, col, 1,
        msg,
        detail="The parser expected a different token at this position.",
        hint="Check the structure of the surrounding block — every block must have an explicit open and close.",
        rule="Section 1.7 — Blocks and Boundaries",
    )


def from_sema_diagnostic(sema_diag, source: str, filename: str) -> Diagnostic:
    """Convert src.sema.analyzer.Diagnostic to new Diagnostic."""
    builder  = DiagnosticBuilder(source, filename)
    span     = getattr(sema_diag, "span", None)
    line     = span.line if span else 1
    col      = span.col  if span else 1
    severity = Severity.ERROR if sema_diag.kind == "error" else Severity.WARNING
    return builder._make(
        severity, Stage.TYPE, line, col, 1,
        sema_diag.message,
        detail="",
        hint="",
        rule="Section 1.4–1.6 — Variables, Types, Functions",
    )


def from_level_violation(viol, source: str, filename: str) -> Diagnostic:
    """Convert LevelViolation to new Diagnostic."""
    builder = DiagnosticBuilder(source, filename)
    span    = getattr(viol, "span", None)
    line    = span.line if span else 1
    col     = span.col  if span else 1
    rule_map = {
        "release":  "Section 2.1–2.2 — Memory Model, Heap Rules",
        "null":     "Section 2.5 — Working with Pointers",
        "owner":    "Section 2.3 — Ownership",
        "lifetime": "Section 2.1 — Stack Rules / Pointer Lifetime",
    }
    return builder.error(
        Stage.LEVEL, line, col, 1,
        f"LEVEL VIOLATION — {viol.message}",
        detail=viol.detail,
        hint=viol.hint,
        rule=rule_map.get(viol.kind, "Section 6.2 — Level System"),
    )
