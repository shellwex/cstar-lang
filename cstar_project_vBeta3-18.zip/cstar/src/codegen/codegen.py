"""
C* Compiler — LLVM IR Code Generator
Walks a semantically-verified AST and emits LLVM IR text.

Conventions
───────────
• Each C* function → one LLVM function.
• Variables live on the stack (alloca); SSA values used for temporaries.
• Strings are global constants (@str.N).
• Errors propagate via a hidden i8 return slot + out-parameter pattern:
    every function that can reject returns  { i8 error_code, <real_type> }
    via a sret pointer — kept simple for Phase 1.
• Phase 1 scope: integer, float, boolean, byte, text (pointer to i8),
  pointer types, basic arithmetic, comparisons, if/repeat, calls,
  bitwise operations, shifts, structure field access, method calls,
  range checking for narrow integer conversions, interrupt handlers,
  volatile hardware access, pattern matching (match),
  named loops for stop/skip, module‑qualified calls (mangled),
  generic type instantiation (via struct_metadata).
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Set, Dict, Tuple, List
import textwrap
import re

from ..parser import ast as A
from ..sema.analyzer import CType, ast_type_to_ctype, T_BOOL, T_NOTHING


# ── LLVM type mapping ─────────────────────────────────────────────────────────

def llvm_type(ct: CType, enum_names: set = None) -> str:
    if ct.kind == "integer":
        return f"i{ct.bits}"
    if ct.kind == "float":
        return "float" if ct.bits == 32 else "double"
    if ct.kind == "byte":
        return "i8"
    if ct.kind == "boolean":
        return "i1"
    if ct.kind == "text":
        return "ptr"          # pointer to i8 string constant
    if ct.kind == "pointer":
        return "ptr"          # opaque pointer (LLVM 15+)
    if ct.kind == "nothing":
        return "void"
    if ct.kind == "named":
        # Enum-типы представляются как i32 (нет struct в IR)
        if enum_names and ct.name in enum_names:
            return "i32"
        # Заменяем скобки и пробелы на подчёркивания для безопасного имени
        safe_name = ct.name.replace("[", "_").replace("]", "").replace(" ", "")
        return f"%struct.{safe_name}"
    if ct.kind == "array":
        if getattr(ct, 'heap', False):
            return "ptr"
        return f"[{ct.bits} x i32]"
    return "i64"              # fallback


def llvm_zero(ct: CType) -> str:
    if ct.kind in ("integer", "byte", "boolean"):
        return "0"
    if ct.kind == "float":
        return "0.0"
    if ct.kind in ("pointer", "text"):
        return "null"
    return "0"


# ── Code generator ────────────────────────────────────────────────────────────

class CodegenError(Exception):
    pass


@dataclass
class Codegen:
    _lines: list[str]          = field(default_factory=list)
    _globals: list[str]        = field(default_factory=list)
    _tmp: int                  = 0
    _lbl: int                  = 0
    _str_count: int            = 0
    _str_cache: dict[str, str] = field(default_factory=dict)
    _vars: dict[str, tuple[str, CType]] = field(default_factory=dict)
    _scope_stack: list[dict[str, tuple[str, CType]]] = field(default_factory=list)
    _func_types: dict[str, tuple[list[CType], CType]] = field(default_factory=dict)
    _current_func_ret: Optional[CType] = None
    _current_func_name: str = ""
    _loop_end_labels: list[str] = field(default_factory=list)
    _loop_cond_labels: list[str] = field(default_factory=list)
    _heap_vars: Set[str]       = field(default_factory=set)
    _struct_types: dict[str, list[tuple[str, CType]]] = field(default_factory=dict)
    _struct_fields: dict[str, list[str]] = field(default_factory=dict)
    _hw_registers: Dict[str, object] = field(default_factory=dict)
    _loop_labels: Dict[str, Tuple[str, str]] = field(default_factory=dict)
    _enum_names: set = field(default_factory=set)  # enum type names → use i32
    _enum_variants: dict = field(default_factory=dict)  # variant_name → int index
    _alias_types: dict = field(default_factory=dict)  # alias name → underlying CType

    # ── Public ────────────────────────────────────────────────────────────────

    def generate_program(self, prog: A.Node, struct_metadata: dict = None, modules: list = None, enum_names: set = None, alias_types: dict = None) -> str:
        # Полный сброс состояния генератора
        self._globals = []
        self._lines = []
        self._tmp = 0
        self._lbl = 0
        self._struct_fields = {}
        self._struct_types = {}
        self._heap_vars = set()
        self._func_types = {}
        self._enum_names = set(enum_names) if enum_names else set()
        # alias_types: dict[name -> CType] — type aliases like "Percent" = integer[signed,32bit]
        # They must be treated as their underlying primitive type, NOT as structs.
        self._alias_types: dict = dict(alias_types) if alias_types else {}
        # Строим таблицу вариант → индекс из type_defs программы
        self._enum_variants = {}
        for td in getattr(prog, 'type_defs', []):
            if isinstance(td, A.EnumDef):
                for idx, variant in enumerate(td.variants):
                    self._enum_variants[variant.name] = idx

        # 1. Сначала заголовок
        self._emit_header()

        # 2. Регистрация структур из Анализатора
        if struct_metadata:
            for s_name, fields in struct_metadata.items():
                self._struct_fields[s_name] = list(fields.keys())
                self._struct_types[s_name] = list(fields.items())  # [(name, CType), ...]
                f_llvm_types = [self._llvm_type(t) for t in fields.values()]
                struct_line = f"%struct.{s_name} = type {{ {', '.join(f_llvm_types)} }}"
                if struct_line not in self._globals:
                    self._globals.append(struct_line)

        # 3. Поиск оригинальных определений операций в модулях (шаблоны)
        templates = {}
        if modules:
            for mod in modules:
                # Проверим наличие type_defs у модуля (может быть списком определений типов)
                for td in getattr(mod, 'type_defs', []):
                    if isinstance(td, A.StructDef):
                        templates[td.name] = td

        # 4. Генерируем методы для каждой инстанцированной структуры
        if struct_metadata:
            for s_name in struct_metadata.keys():
                if "_" in s_name:  # признак инстанцированного шаблона (например, List_i32)
                    base_template_name = s_name.split("_")[0]
                    if base_template_name in templates:
                        template_def = templates[base_template_name]
                        concrete_fields = struct_metadata[s_name]
                        type_subst = {}
                        if template_def.generic_params:
                            for gp_name in template_def.generic_params:
                                for tfield in template_def.fields:
                                    if (isinstance(tfield.type_node, A.NamedType)
                                            and tfield.type_node.name == gp_name):
                                        type_subst[gp_name] = concrete_fields.get(tfield.name)
                                        break
                                    if (isinstance(tfield.type_node, A.PointerType)
                                            and isinstance(tfield.type_node.inner, A.NamedType)
                                            and tfield.type_node.inner.name == gp_name):
                                        inner = concrete_fields.get(tfield.name)
                                        if inner and inner.kind == "pointer":
                                            type_subst[gp_name] = inner.inner
                                        break
                        for op in template_def.operations:
                            op_llvm_name = f"{s_name}_{op.name}"
                            ret_ct = self._resolve_op_type(op.return_type, type_subst)
                            p_types = [CType("named", name=s_name)]
                            for p in op.params:
                                p_types.append(self._resolve_op_type(p.type_node, type_subst))
                            self._func_types[op_llvm_name] = (p_types, ret_ct)
                            self._gen_operation(op, s_name, type_subst=type_subst)

        # 4b. Регистрируем и генерируем методы (operations) из StructDef в самой программе
        for td in getattr(prog, 'type_defs', []):
            if isinstance(td, A.StructDef) and td.operations:
                s_name = td.name
                # Убеждаемся, что структура зарегистрирована в _struct_types
                if s_name not in self._struct_types and struct_metadata and s_name in struct_metadata:
                    fields = struct_metadata[s_name]
                    self._struct_fields[s_name] = list(fields.keys())
                    self._struct_types[s_name] = list(fields.items())
                for op in td.operations:
                    op_llvm_name = f"{s_name}_{op.name}"
                    ret_ct = self._resolve_op_type(op.return_type, None)
                    p_types = [CType("named", name=s_name)]
                    for p in op.params:
                        p_types.append(self._resolve_op_type(p.type_node, None))
                    self._func_types[op_llvm_name] = (p_types, ret_ct)
                    self._gen_operation(op, s_name)

        # 5. Аппаратные регистры
        if hasattr(prog, 'hardware_registers'):
            self._hw_registers = {reg.name: reg for reg in prog.hardware_registers}

        # 6. Генерируем функции из ВСЕХ загруженных модулей
        if modules:
            for mod in modules:
                for f in mod.functions:
                    # Регистрируем сигнатуру (Module.Function)
                    p_types = [ast_type_to_ctype(p.type_node) for p in f.params]
                    r_type  = ast_type_to_ctype(f.return_type)
                    mangled_name = f"{mod.name}_{f.name}"
                    self._func_types[mangled_name] = (p_types, r_type)
                    # Генерируем тело функции модуля
                    self._gen_module_function(f, mod.name)

        # 7. Регистрируем и генерируем функции основной программы
        for f in prog.functions:
            p_types = [ast_type_to_ctype(p.type_node) for p in f.params]
            r_type  = ast_type_to_ctype(f.return_type)
            self._func_types[f.name] = (p_types, r_type)
            self._gen_function(f)

        # 8. Генерируем обработчики прерываний
        for handler in getattr(prog, 'interrupt_handlers', []):
            self._gen_interrupt_handler(handler)

        # 9. Генерируем main
        if isinstance(prog, A.ProgramDef):
            self._gen_main(prog.body)

        return "\n".join(self._globals + [""] + self._lines)

    # ── Header ────────────────────────────────────────────────────────────────

    def _emit_header(self) -> None:
        self._globals.extend([
            "; C* compiled output",
            f'target triple = "aarch64-unknown-linux-android24"',
            "",
            "; External declarations",
            "declare i32 @printf(ptr, ...)",
            "declare ptr @malloc(i64)",
            "declare void @free(ptr)",
            "declare void @abort()",
            "declare i32 @fflush(ptr)",
            "declare i32 @putchar(i32)",
            "",
            "; Format strings for builtins",
            '@fmt.int  = private unnamed_addr constant [4 x i8] c"%d\\0A\\00"',
            '@fmt.uint = private unnamed_addr constant [4 x i8] c"%u\\0A\\00"',
            '@fmt.flt  = private unnamed_addr constant [4 x i8] c"%f\\0A\\00"',
            '@fmt.str  = private unnamed_addr constant [4 x i8] c"%s\\0A\\00"',
            '@fmt.true = private unnamed_addr constant [6 x i8] c"true\\0A\\00"',
            '@fmt.fals = private unnamed_addr constant [7 x i8] c"false\\0A\\00"',
            "",
        ])
        T_INT32  = CType("integer", signed=True,  bits=32)
        T_UINT32 = CType("integer", signed=False, bits=32)
        T_FLOAT  = CType("float",   bits=64)
        T_TEXT   = CType("text")
        T_BOOL   = CType("boolean")
        T_NOTHING = CType("nothing")
        self._func_types.update({
            "print_integer":  ([T_INT32],   T_NOTHING),
            "print_unsigned": ([T_UINT32],  T_NOTHING),
            "print_float":    ([T_FLOAT],   T_NOTHING),
            "print_text":     ([T_TEXT],    T_NOTHING),
            "print_boolean":  ([T_BOOL],    T_NOTHING),
            "print_line":     ([],          T_NOTHING),
        })

    # ── Name mangling ──────────────────────────────────────────────────────

    @staticmethod
    def _mangle_name(name: str) -> str:
        return name.replace(".", "_")

    # ── Operation (method) generation ──────────────────────────────────────

    def _resolve_op_type(self, type_node, type_subst) -> CType:
        """Применяет подстановку generic-параметров, затем вызывает ast_type_to_ctype."""
        if type_node is None:
            return T_NOTHING
        if type_subst:
            if isinstance(type_node, A.NamedType) and type_node.name in type_subst:
                concrete = type_subst[type_node.name]
                if concrete is not None:
                    return concrete
            if isinstance(type_node, A.PointerType):
                inner = self._resolve_op_type(type_node.inner, type_subst)
                return CType("pointer", inner=inner)
        return ast_type_to_ctype(type_node)

    def _gen_operation(self, op: A.OperationDef, struct_name: str,
                       type_subst: dict = None) -> None:
        llvm_name = f"{struct_name}_{op.name}"
        ret_ct = self._resolve_op_type(op.return_type, type_subst)

        param_list = ["ptr %self"]
        param_cts = [CType("named", name=struct_name)]
        for p in op.params:
            ct = self._resolve_op_type(p.type_node, type_subst)
            param_list.append(f"{self._llvm_type(ct)} %arg_{p.name}")
            param_cts.append(ct)

        self._emit(f"define {self._llvm_type(ret_ct)} @{llvm_name}({', '.join(param_list)}) {{")
        self._emit("entry:")
        self._push_scope()
        self._current_func_ret = ret_ct
        self._current_func_name = llvm_name

        if op.return_name:
            ret_alloca = self._alloca(self._llvm_type(ret_ct), op.return_name)
            self._scope()[op.return_name] = (ret_alloca, ret_ct)

        for p in op.params:
            ct = self._resolve_op_type(p.type_node, type_subst)
            lt = self._llvm_type(ct)
            alloca = self._alloca(lt, p.name)
            self._store(f"%arg_{p.name}", lt, alloca)
            self._scope()[p.name] = (alloca, ct)

        field_types = self._struct_types.get(struct_name, [])
        field_names = self._struct_fields.get(struct_name, [])
        # Если _struct_types заполнен — используем реальные типы полей
        if field_types:
            for i, (f_name, f_ct) in enumerate(field_types):
                tmp_ptr = self._new_tmp()
                self._emit(f"  {tmp_ptr} = getelementptr %struct.{struct_name}, ptr %self, i32 0, i32 {i}")
                self._scope()[f_name] = (tmp_ptr, f_ct)
        else:
            for i, f_name in enumerate(field_names):
                tmp_ptr = self._new_tmp()
                self._emit(f"  {tmp_ptr} = getelementptr %struct.{struct_name}, ptr %self, i32 0, i32 {i}")
                self._scope()[f_name] = (tmp_ptr, CType("integer", bits=32))

        self._gen_stmts(op.body)

        if ret_ct.kind == "nothing":
            self._emit("  ret void")
        elif op.return_name:
            ret_val = self._load(self._llvm_type(ret_ct), ret_alloca)
            self._emit(f"  ret {self._llvm_type(ret_ct)} {ret_val}")
        else:
            self._emit(f"  ret {self._llvm_type(ret_ct)} {llvm_zero(ret_ct)}")

        self._pop_scope()
        self._emit("}\n")

    # ── Function ─────────────────────────────────────────────────────────────

    def _gen_function(self, func: A.FunctionDef) -> None:
        ret_ct   = ast_type_to_ctype(func.return_type)
        llvm_ret = self._llvm_type(ret_ct)

        params = []
        for p in func.params:
            ct = ast_type_to_ctype(p.type_node)
            params.append(f"{self._llvm_type(ct)} %arg_{p.name}")

        params_str = ", ".join(params)
        self._emit(f"define {llvm_ret} @{func.name}({params_str}) {{")
        self._emit("entry:")

        self._push_scope()
        self._current_func_ret  = ret_ct
        self._current_func_name = func.name

        if func.return_name and ret_ct.kind != "nothing":
            ret_alloca = self._alloca(llvm_ret, func.return_name)
            self._store(llvm_zero(ret_ct), llvm_ret, ret_alloca)
            self._scope()[func.return_name] = (ret_alloca, ret_ct)

        for p in func.params:
            ct     = ast_type_to_ctype(p.type_node)
            lt     = self._llvm_type(ct)
            alloca = self._alloca(lt, p.name)
            self._store(f"%arg_{p.name}", lt, alloca)
            self._scope()[p.name] = (alloca, ct)

        self._gen_stmts(func.body)

        if ret_ct.kind == "nothing":
            self._emit("  ret void")
        else:
            ret_val = self._load(llvm_ret, self._scope().get(func.return_name, ("%undef", ret_ct))[0])
            self._emit(f"  ret {llvm_ret} {ret_val}")

        self._pop_scope()
        self._emit("}\n")

    def _gen_main(self, body: list) -> None:
        self._emit("define i32 @main() {")
        self._emit("entry:")
        self._push_scope()
        self._current_func_ret  = CType("integer", signed=True, bits=32)
        self._current_func_name = "main"
        self._gen_stmts(body)
        self._emit("  ret i32 0")
        self._pop_scope()
        self._emit("}\n")

    # ── Module function generation ────────────────────────────────────────

    def _gen_module_function(self, func: A.FunctionDef, mod_name: str) -> None:
        """Вспомогательный метод для генерации функций из внешних модулей."""
        old_name = func.name
        func.name = f"{mod_name}_{func.name}"   # временно меняем имя для LLVM
        self._gen_function(func)
        func.name = old_name                     # восстанавливаем исходное имя

    # ── Interrupt handler generation ───────────────────────────────────────

    def _gen_interrupt_handler(self, handler: A.InterruptHandlerDef) -> None:
        self._emit(f"; Interrupt Vector: {handler.vector}")
        self._emit(f"define void @handler_{handler.name}() {{")
        self._emit("entry:")
        self._push_scope()
        self._gen_stmts(handler.body)
        self._emit("  ret void")
        self._pop_scope()
        self._emit("}\n")

    # ── Statements ────────────────────────────────────────────────────────────

    def _gen_stmts(self, stmts: list) -> None:
        for s in stmts:
            self._gen_stmt(s)

    def _gen_stmt(self, stmt) -> None:
        if isinstance(stmt, A.DeclareStmt):
            self._gen_declare(stmt)
        elif isinstance(stmt, A.AssignStmt):
            self._gen_assign(stmt)
        elif isinstance(stmt, A.IfStmt):
            self._gen_if(stmt)
        elif isinstance(stmt, A.RepeatStmt):
            self._gen_repeat(stmt)
        elif isinstance(stmt, A.ReturnStmt):
            self._gen_return(stmt)
        elif isinstance(stmt, A.RejectStmt):
            self._gen_reject(stmt)
        elif isinstance(stmt, A.StopStmt):
            self._gen_stop(stmt)
        elif isinstance(stmt, A.SkipStmt):
            self._gen_skip(stmt)
        elif isinstance(stmt, A.CallStmt):
            self._gen_call(stmt)
        elif isinstance(stmt, A.SimpleCallStmt):
            self._gen_simple_call(stmt)
        elif isinstance(stmt, A.AllocateStmt):
            self._gen_allocate(stmt)
        elif isinstance(stmt, A.ReleaseStmt):
            self._gen_release(stmt)
        elif isinstance(stmt, A.HardwareWriteStmt):
            self._gen_hw_write(stmt)
        elif isinstance(stmt, A.HardwareReadStmt):
            self._gen_hw_read(stmt)
        elif isinstance(stmt, A.MatchStmt):
            self._gen_match(stmt)

    # ── Match statement ─────────────────────────────────────────────────────

    def _gen_match(self, stmt: A.MatchStmt) -> None:
        val = self._gen_expr(stmt.expr, CType("integer", signed=True, bits=32))
        end_lbl = self._new_label("match_end")

        for case in stmt.cases:
            match_lbl = self._new_label(f"case_{case.variant_name}")
            next_lbl = self._new_label("match_next")

            # Используем реальный индекс варианта из таблицы enum
            variant_idx = self._enum_variants.get(case.variant_name, 0)
            is_equal = self._new_tmp()
            self._emit(f"  {is_equal} = icmp eq i32 {val}, {variant_idx}")
            self._emit(f"  br i1 {is_equal}, label %{match_lbl}, label %{next_lbl}")

            self._emit(f"{match_lbl}:")
            self._push_scope()
            self._gen_stmts(case.body)
            self._pop_scope()
            self._emit(f"  br label %{end_lbl}")

            self._emit(f"{next_lbl}:")

        self._emit(f"{end_lbl}:")

    # ── Declare ──────────────────────────────────────────────────────────────

    def _gen_declare(self, stmt: A.DeclareStmt) -> None:
        ct = ast_type_to_ctype(stmt.type_node)
        # Resolve type aliases (e.g. Percent → integer[signed,32bit]) so we
        # do NOT emit an alloca for a non-existent %struct.Percent.
        if ct.kind == "named" and ct.name in self._alias_types:
            alias_ct = self._alias_types[ct.name]
            ct = alias_ct.inner if alias_ct.inner is not None else alias_ct
        lt = self._llvm_type(ct)

        if ct.kind == "named" and ct.name not in self._enum_names:
            # Struct/generic named type — alloca без initial value
            alloca = self._alloca(lt, stmt.name)
            self._scope()[stmt.name] = (alloca, ct)
        elif ct.kind == "named" and ct.name in self._enum_names:
            # Enum type — alloca + store initial value (variant index или 0)
            alloca = self._alloca("i32", stmt.name)
            val = self._gen_expr(stmt.initial_value, CType("integer", signed=True, bits=32))
            self._store(val, "i32", alloca)
            self._scope()[stmt.name] = (alloca, ct)
        elif ct.kind == "array":
            size = ct.bits
            if stmt.location == "heap":
                # Compute element size correctly:
                # - struct element: use getelementptr trick (sizeof = GEP offset 1)
                # - scalar element: 4 bytes (i32)
                if ct.inner and ct.inner.kind == "named" and ct.inner.name not in self._enum_names and ct.inner.name not in self._alias_types:
                    elem_lt = f"%struct.{ct.inner.name}"
                    # sizeof(struct) via GEP: byte_size = N * (field_count * 4) — use N * sizeof heuristic
                    # We use the known struct field count to compute sizeof correctly
                    field_count = len(self._struct_fields.get(ct.inner.name, [])) or 1
                    byte_size = size * field_count * 4
                else:
                    byte_size = size * 4
                tmp_ptr = self._new_tmp()
                self._emit(f"  {tmp_ptr} = call ptr @malloc(i64 {byte_size})")
                alloca = self._alloca("ptr", stmt.name)
                self._store(tmp_ptr, "ptr", alloca)
                self._heap_vars.add(stmt.name)
            else:
                # Use correct element type (struct or i32)
                if ct.inner and ct.inner.kind == "named":
                    elem_lt = f"%struct.{ct.inner.name}"
                else:
                    elem_lt = "i32"
                alloca = self._alloca(f"[{size} x {elem_lt}]", stmt.name)
            self._scope()[stmt.name] = (alloca, ct)
        else:
            alloca = self._alloca(lt, stmt.name)
            if stmt.location == "heap":
                self._heap_vars.add(stmt.name)
            if ct.kind != "array":
                val = self._gen_expr(stmt.initial_value, ct)
                self._store(val, lt, alloca)
            self._scope()[stmt.name] = (alloca, ct)

    def _gen_assign(self, stmt: A.AssignStmt) -> None:
        if isinstance(stmt.target, A.ArrayIndex):
            ptr = self._get_element_ptr(stmt.target)
            val = self._gen_expr(stmt.value, CType("integer"))
            self._emit(f"  store i32 {val}, ptr {ptr}")
            return

        if isinstance(stmt.target, A.FieldAccess):
            # Case: points at index 0 field x is 10.0  →  FieldAccess(obj=ArrayIndex, field="x")
            if isinstance(stmt.target.obj, A.ArrayIndex):
                ptr = self._get_struct_field_via_array_index(stmt.target.obj, stmt.target.field)
                # Determine field type from array element struct type
                field_lt = self._get_array_struct_field_llvm_type(stmt.target.obj, stmt.target.field)
                field_ct = self._get_array_struct_field_ctype(stmt.target.obj, stmt.target.field)
                val = self._gen_expr(stmt.value, field_ct)
                val = self._maybe_trunc(val, field_lt)
                self._emit(f"  store {field_lt} {val}, ptr {ptr}")
                return
            # Normal case: FieldAccess(obj=Identifier)
            ptr = self._get_field_ptr(stmt.target.obj.name, stmt.target.field)
            field_lt = self._get_field_llvm_type(stmt.target.obj.name, stmt.target.field)
            field_ct = self._get_field_ctype(stmt.target.obj.name, stmt.target.field)
            val = self._gen_expr(stmt.value, field_ct)
            # Truncate if storing narrower type (e.g. i32 result into i8 field)
            val = self._maybe_trunc(val, field_lt)
            self._emit(f"  store {field_lt} {val}, ptr {ptr}")
            return

        if isinstance(stmt.target, A.Identifier):
            alloca, ct = self._lookup(stmt.target.name)
            val = self._gen_expr(stmt.value, ct)
            self._store(val, self._llvm_type(ct), alloca)
        elif isinstance(stmt.target, A.ValueAt):
            ptr = self._gen_expr(stmt.target.pointer, None)
            val = self._gen_expr(stmt.value, None)
            self._emit(f"  store i64 {val}, ptr {ptr}")

    def _gen_if(self, stmt: A.IfStmt) -> None:
        cond      = self._gen_expr(stmt.condition, T_BOOL)
        then_lbl  = self._new_label("if_then")
        else_lbl  = self._new_label("if_else")
        end_lbl   = self._new_label("if_end")

        has_else = stmt.else_body is not None or stmt.elseif_branches

        self._emit(f"  br i1 {cond}, label %{then_lbl}, label %{else_lbl if has_else else end_lbl}")
        self._emit(f"{then_lbl}:")
        self._push_scope()
        self._gen_stmts(stmt.then_body)
        self._pop_scope()
        self._emit(f"  br label %{end_lbl}")

        if has_else:
            self._emit(f"{else_lbl}:")
            self._push_scope()
            if stmt.else_body:
                self._gen_stmts(stmt.else_body)
            self._pop_scope()
            self._emit(f"  br label %{end_lbl}")

        self._emit(f"{end_lbl}:")

    def _gen_repeat(self, stmt: A.RepeatStmt) -> None:
        cond_lbl = self._new_label("loop_cond")
        body_lbl = self._new_label("loop_body")
        end_lbl  = self._new_label("loop_end")

        self._loop_cond_labels.append(cond_lbl)
        self._loop_end_labels.append(end_lbl)

        if stmt.loop_name:
            self._loop_labels[stmt.loop_name] = (cond_lbl, end_lbl)

        self._emit(f"  br label %{cond_lbl}")
        self._emit(f"{cond_lbl}:")
        cond = self._gen_expr(stmt.condition, T_BOOL)
        self._emit(f"  br i1 {cond}, label %{body_lbl}, label %{end_lbl}")
        self._emit(f"{body_lbl}:")
        self._push_scope()
        self._gen_stmts(stmt.body)
        self._pop_scope()
        self._emit(f"  br label %{cond_lbl}")
        self._emit(f"{end_lbl}:")

        self._loop_cond_labels.pop()
        self._loop_end_labels.pop()

    def _gen_return(self, stmt: A.ReturnStmt) -> None:
        if stmt.value is None or self._current_func_ret.kind == "nothing":
            self._emit("  ret void")
        else:
            lt  = self._llvm_type(self._current_func_ret)
            val = self._gen_expr(stmt.value, self._current_func_ret)
            self._emit(f"  ret {lt} {val}")
        dead = self._new_label("dead")
        self._emit(f"{dead}:")

    def _gen_reject(self, stmt: A.RejectStmt) -> None:
        msg = self._str_const(f"ERROR: {stmt.error_name}\\n")
        self._emit(f"  call i32 (ptr, ...) @printf(ptr {msg})")
        if self._current_func_ret.kind == "nothing":
            self._emit("  ret void")
        else:
            lt = self._llvm_type(self._current_func_ret)
            self._emit(f"  ret {lt} {llvm_zero(self._current_func_ret)}")
        dead = self._new_label("dead")
        self._emit(f"{dead}:")

    def _gen_stop(self, stmt: A.StopStmt) -> None:
        if stmt.loop_name:
            if stmt.loop_name in self._loop_labels:
                _, end_lbl = self._loop_labels[stmt.loop_name]
                self._emit(f"  br label %{end_lbl}")
            else:
                raise CodegenError(f"Loop '{stmt.loop_name}' not found")
        else:
            if self._loop_end_labels:
                self._emit(f"  br label %{self._loop_end_labels[-1]}")
        dead = self._new_label("dead")
        self._emit(f"{dead}:")

    def _gen_skip(self, stmt: A.SkipStmt) -> None:
        if stmt.loop_name:
            if stmt.loop_name in self._loop_labels:
                cond_lbl, _ = self._loop_labels[stmt.loop_name]
                self._emit(f"  br label %{cond_lbl}")
            else:
                raise CodegenError(f"Loop '{stmt.loop_name}' not found")
        else:
            if self._loop_cond_labels:
                self._emit(f"  br label %{self._loop_cond_labels[-1]}")
        dead = self._new_label("dead")
        self._emit(f"{dead}:")

    # ── Call statement (call block) ────────────────────────────────────────

    def _gen_call(self, stmt: A.CallStmt) -> None:
        if stmt.func_name == "StdIO.print_msg":
            arg_expr = next(val for name, mode, val in stmt.args if name == "message")
            val = self._gen_expr(arg_expr, CType("text"))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr {val})")
            for h in stmt.handlers:
                if h.kind == "success":
                    self._gen_stmts(h.body)
            return

        if stmt.func_name == "StdIO.print_int":
            arg_expr = next(val for name, mode, val in stmt.args if name == "value")
            val = self._gen_expr(arg_expr, CType("integer", signed=True, bits=32))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 {val})")
            for h in stmt.handlers:
                if h.kind == "success":
                    self._gen_stmts(h.body)
            return

        if "." in stmt.func_name:
            obj_name, method_name = stmt.func_name.split(".")
            alloca, ct = self._lookup(obj_name)
            llvm_func_name = f"{ct.name}_{method_name}"

            sig = self._func_types.get(llvm_func_name)
            ret_ct = sig[1] if sig else CType("nothing")

            args = [f"ptr {alloca}"]
            for i, (arg_name, arg_mode, arg_expr) in enumerate(stmt.args):
                if sig and (i + 1) < len(sig[0]):
                    arg_ct = sig[0][i + 1]
                else:
                    arg_ct = CType("integer", signed=True, bits=32)
                val = self._gen_expr(arg_expr, arg_ct)
                lt = self._llvm_type(arg_ct)
                args.append(f"{lt} {val}")

            if ret_ct.kind == "nothing":
                self._emit(f"  call void @{llvm_func_name}({', '.join(args)})")
            else:
                tmp = self._new_tmp()
                self._emit(f"  {tmp} = call {self._llvm_type(ret_ct)} @{llvm_func_name}({', '.join(args)})")

            for h in stmt.handlers:
                if h.kind == "success":
                    self._push_scope()
                    self._gen_stmts(h.body)
                    self._pop_scope()
            return

        llvm_func_name = stmt.func_name
        obj_ptr = None
        if hasattr(stmt, 'object') and stmt.object is not None:
            _, obj_ct = self._lookup(stmt.object.name)
            llvm_func_name = f"{obj_ct.name}_{stmt.func_name}"
            obj_ptr = self._get_object_ptr(stmt.object)

        llvm_func_name = self._mangle_name(llvm_func_name)

        sig = self._func_types.get(llvm_func_name)
        args = []

        if obj_ptr is not None:
            args.append(f"ptr {obj_ptr}")

        for arg_name, arg_mode, arg_expr in stmt.args:
            if sig:
                param_map = {}
                for (an, am, ae), pct in zip(stmt.args, sig[0]):
                    param_map[an] = pct
                arg_ct = param_map.get(arg_name, CType("unknown"))
            else:
                arg_ct = CType("unknown")
            val = self._gen_expr(arg_expr, arg_ct)
            lt  = self._llvm_type(arg_ct)
            args.append(f"{lt} {val}")

        args_str = ", ".join(args)
        ret_ct   = sig[1] if sig else CType("nothing")
        lt       = self._llvm_type(ret_ct)

        if ret_ct.kind == "nothing":
            self._emit(f"  call void @{llvm_func_name}({args_str})")
        else:
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = call {lt} @{llvm_func_name}({args_str})")

        for h in stmt.handlers:
            if h.kind == "success":
                self._push_scope()
                self._gen_stmts(h.body)
                self._pop_scope()

    # ── Simple call statement (expression call) ────────────────────────────

    def _gen_simple_call(self, stmt: A.SimpleCallStmt) -> None:
        if stmt.func_name == "StdIO.print_int":
            val = self._gen_expr(stmt.args[0], CType("integer", signed=True, bits=32))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 {val})")
            return
        if stmt.func_name == "StdIO.print_msg":
            val = self._gen_expr(stmt.args[0], CType("text"))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr {val})")
            return

        if self._gen_builtin_call(stmt):
            return

        if "." in stmt.func_name:
            obj_name, method_name = stmt.func_name.split(".")
            alloca, ct = self._lookup(obj_name)
            llvm_func_name = f"{ct.name}_{method_name}"

            sig = self._func_types.get(llvm_func_name)
            ret_ct = sig[1] if sig else CType("nothing")

            args = [f"ptr {alloca}"]
            for i, arg_expr in enumerate(stmt.args):
                if sig and (i + 1) < len(sig[0]):
                    arg_ct = sig[0][i + 1]
                else:
                    arg_ct = CType("integer", signed=True, bits=32)
                val = self._gen_expr(arg_expr, arg_ct)
                lt = self._llvm_type(arg_ct)
                args.append(f"{lt} {val}")

            if ret_ct.kind == "nothing":
                self._emit(f"  call void @{llvm_func_name}({', '.join(args)})")
            else:
                tmp = self._new_tmp()
                self._emit(f"  {tmp} = call {self._llvm_type(ret_ct)} @{llvm_func_name}({', '.join(args)})")
            return

        llvm_func_name = stmt.func_name
        obj_ptr = None
        if hasattr(stmt, 'object') and stmt.object is not None:
            _, obj_ct = self._lookup(stmt.object.name)
            llvm_func_name = f"{obj_ct.name}_{stmt.func_name}"
            obj_ptr = self._get_object_ptr(stmt.object)

        llvm_func_name = self._mangle_name(llvm_func_name)

        sig = self._func_types.get(llvm_func_name)

        if sig is None:
            proto = f"declare void @{llvm_func_name}("
            if obj_ptr is not None:
                proto += "ptr"
                if stmt.args:
                    proto += ", "
            if stmt.args:
                proto += ", ".join(["i32"] * len(stmt.args))
            proto += ")"
            if proto not in self._globals:
                self._globals.append(proto)

            args = []
            if obj_ptr is not None:
                args.append(f"ptr {obj_ptr}")
            for arg_expr in stmt.args:
                val = self._gen_expr(arg_expr, CType("integer", signed=True, bits=32))
                args.append(f"i32 {val}")
            self._emit(f"  call void @{llvm_func_name}({', '.join(args)})")
            return

        args = []
        if obj_ptr is not None:
            self_ct = sig[0][0] if sig[0] else CType("named", name="unknown")
            args.append(f"{self._llvm_type(self_ct)} {obj_ptr}")

        for i, arg_expr in enumerate(stmt.args):
            param_idx = i + (1 if obj_ptr is not None else 0)
            arg_ct = sig[0][param_idx] if param_idx < len(sig[0]) else CType("integer")
            val    = self._gen_expr(arg_expr, arg_ct)
            lt     = self._llvm_type(arg_ct)
            args.append(f"{lt} {val}")

        args_str = ", ".join(args)
        ret_ct   = sig[1] if sig else CType("nothing")
        lt       = self._llvm_type(ret_ct)
        if ret_ct.kind == "nothing":
            self._emit(f"  call void @{llvm_func_name}({args_str})")
        else:
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = call {lt} @{llvm_func_name}({args_str})")

    # ── Hardware Access (volatile) ──────────────────────────────────────────

    def _gen_hw_write(self, stmt: A.HardwareWriteStmt) -> None:
        reg = self._hw_registers.get(stmt.reg_name)
        if reg is None:
            raise CodegenError(f"Register '{stmt.reg_name}' not found in codegen map")
        val = self._gen_expr(stmt.value, CType("integer"))
        ptr = self._new_tmp()
        self._emit(f"  {ptr} = inttoptr i64 {reg.address} to ptr")
        self._emit(f"  store volatile i32 {val}, ptr {ptr}")

    def _gen_hw_read(self, stmt: A.HardwareReadStmt) -> None:
        reg = self._hw_registers.get(stmt.reg_name)
        if reg is None:
            raise CodegenError(f"Register '{stmt.reg_name}' not found in codegen map")
        dest_ptr, _ = self._lookup(stmt.dest_name)
        ptr = self._new_tmp()
        self._emit(f"  {ptr} = inttoptr i64 {reg.address} to ptr")
        tmp_val = self._new_tmp()
        self._emit(f"  {tmp_val} = load volatile i32, ptr {ptr}")
        self._emit(f"  store i32 {tmp_val}, ptr {dest_ptr}")

    # ── Helpers for method calls ─────────────────────────────────────────────

    def _get_object_ptr(self, obj) -> str:
        if isinstance(obj, A.Identifier):
            alloca, ct = self._lookup(obj.name)
            return alloca
        elif isinstance(obj, A.FieldAccess):
            return self._get_field_ptr(obj.obj.name, obj.field)
        else:
            raise CodegenError(f"Unsupported object expression for method call: {type(obj)}")

    def _gen_builtin_call(self, stmt: A.SimpleCallStmt) -> bool:
        name = stmt.func_name

        if name == "print_integer":
            val = self._gen_expr(stmt.args[0], CType("integer", signed=True, bits=32))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 {val})")
            return True

        if name == "print_unsigned":
            val = self._gen_expr(stmt.args[0], CType("integer", signed=False, bits=32))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.uint, i32 {val})")
            return True

        if name == "print_float":
            val = self._gen_expr(stmt.args[0], CType("float", bits=64))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.flt, double {val})")
            return True

        if name == "print_text":
            val = self._gen_expr(stmt.args[0], CType("text"))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr {val})")
            return True

        if name == "print_boolean":
            val  = self._gen_expr(stmt.args[0], CType("boolean"))
            t_lbl = self._new_label("bool_true")
            f_lbl = self._new_label("bool_false")
            e_lbl = self._new_label("bool_end")
            self._emit(f"  br i1 {val}, label %{t_lbl}, label %{f_lbl}")
            self._emit(f"{t_lbl}:")
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.true)")
            self._emit(f"  br label %{e_lbl}")
            self._emit(f"{f_lbl}:")
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.fals)")
            self._emit(f"  br label %{e_lbl}")
            self._emit(f"{e_lbl}:")
            return True

        if name == "print_line":
            self._emit(f"  call i32 @putchar(i32 10)")
            return True

        if name == "abort_program":
            self._emit(f"  call i32 @fflush(ptr null)")
            self._emit(f"  call void @abort()")
            self._emit(f"  unreachable")
            return True

        return False

    def _gen_allocate(self, stmt: A.AllocateStmt) -> None:
        size_val = self._gen_expr(stmt.size, CType("integer", bits=64))
        tmp      = self._new_tmp()
        self._emit(f"  {tmp} = call ptr @malloc(i64 {size_val})")
        if stmt.name in self._scope():
            alloca, ct = self._scope()[stmt.name]
            self._store(tmp, "ptr", alloca)
        else:
            alloca = self._alloca("ptr", stmt.name)
            self._store(tmp, "ptr", alloca)
            self._scope()[stmt.name] = (alloca, CType("pointer"))

    def _gen_release(self, stmt: A.ReleaseStmt) -> None:
        alloca, ct = self._lookup(stmt.name)
        ptr = self._load("ptr", alloca)
        self._emit(f"  call void @free(ptr {ptr})")
        # Section 2.3: after release, zero the pointer so subsequent
        # `is not null` checks correctly see it as dead.
        self._store("null", "ptr", alloca)

    # ── Structure field access (with pointer handling) ─────────────────────

    def _get_field_ptr(self, obj_name: str, field_name: str) -> str:
        alloca, ct = self._lookup(obj_name)

        # Если это указатель на структуру (например, внутри метода через %self)
        if ct.kind == "pointer":
            # Нужно сначала загрузить сам адрес из переменной-указателя
            ptr_to_struct = self._load("ptr", alloca)
            struct_type_name = ct.inner.name
        else:
            ptr_to_struct = alloca
            struct_type_name = ct.name

        field_list = self._struct_fields.get(struct_type_name)
        if field_list is None:
            raise CodegenError(
                f"Metadata for struct '{struct_type_name}' not found. "
                f"Known: {list(self._struct_fields.keys())}"
            )

        if field_name not in field_list:
            raise CodegenError(
                f"Field '{field_name}' not found in struct '{struct_type_name}' "
                f"(Available: {field_list})"
            )

        field_idx = field_list.index(field_name)
        tmp = self._new_tmp()
        self._emit(
            f"  {tmp} = getelementptr %struct.{struct_type_name}, "
            f"ptr {ptr_to_struct}, i32 0, i32 {field_idx}"
        )
        return tmp

    # ── Helper for array element access ─────────────────────────────────────

    def _get_element_ptr(self, expr: A.ArrayIndex) -> str:
        if isinstance(expr.target, A.FieldAccess):
            base_ptr = self._gen_expr(expr.target, None)
        else:
            base_ptr, ct = self._lookup(expr.target.name)
            if expr.target.name in self._heap_vars or ct.kind == "pointer":
                base_ptr = self._load("ptr", base_ptr)
            elif ct.kind == "array":
                idx_val = self._gen_expr(expr.index_expr, CType("integer", bits=32))
                tmp = self._new_tmp()
                N = ct.bits
                self._emit(f"  {tmp} = getelementptr [{N} x i32], ptr {base_ptr}, i32 0, i32 {idx_val}")
                return tmp

        idx_val = self._gen_expr(expr.index_expr, CType("integer", bits=32))
        tmp = self._new_tmp()
        self._emit(f"  {tmp} = getelementptr i32, ptr {base_ptr}, i32 {idx_val}")
        return tmp

    # ── Helpers for array-of-structs field access ─────────────────────────────

    def _get_array_element_struct_type(self, array_index_expr):
        """Returns (struct_type_name, alloca, ct, N) for array[index] where element is struct."""
        alloca, ct = self._lookup(array_index_expr.target.name)
        struct_type_name = None
        N = None
        if ct.kind == "array" and ct.inner and ct.inner.kind == "named":
            struct_type_name = ct.inner.name
            N = ct.bits
        return struct_type_name, alloca, ct, N

    def _get_struct_field_via_array_index(self, array_index_expr, field_name):
        """GEP into array[index].field — for points at index 0 field x."""
        struct_type_name, alloca, ct, N = self._get_array_element_struct_type(array_index_expr)
        if struct_type_name is None:
            raise CodegenError(f"Cannot determine struct type for array element field access")
        field_list = self._struct_fields.get(struct_type_name, [])
        if field_name not in field_list:
            raise CodegenError(f"Field {field_name!r} not in {struct_type_name!r}")
        field_idx = field_list.index(field_name)
        idx_val = self._gen_expr(array_index_expr.index_expr, CType("integer", bits=32))
        # BUG FIX: for heap arrays, alloca holds a ptr-to-ptr.
        # We must load the actual heap address first before computing GEP.
        arr_var_name = array_index_expr.target.name
        if arr_var_name in self._heap_vars:
            base_ptr = self._load("ptr", alloca)
        else:
            base_ptr = alloca
        elem_tmp = self._new_tmp()
        self._emit(f"  {elem_tmp} = getelementptr [{N} x %struct.{struct_type_name}], ptr {base_ptr}, i32 0, i32 {idx_val}")
        field_tmp = self._new_tmp()
        self._emit(f"  {field_tmp} = getelementptr %struct.{struct_type_name}, ptr {elem_tmp}, i32 0, i32 {field_idx}")
        return field_tmp

    def _get_array_struct_field_llvm_type(self, array_index_expr, field_name):
        """Get LLVM type of field in struct array element."""
        struct_type_name, _, _, _ = self._get_array_element_struct_type(array_index_expr)
        if struct_type_name is None:
            return "double"
        for fname, ftype in self._struct_types.get(struct_type_name, []):
            if fname == field_name:
                return self._llvm_type(ftype)
        return "double"

    def _get_array_struct_field_ctype(self, array_index_expr, field_name):
        """Get CType of field in struct array element."""
        struct_type_name, _, _, _ = self._get_array_element_struct_type(array_index_expr)
        if struct_type_name is None:
            return CType("float", bits=64)
        for fname, ftype in self._struct_types.get(struct_type_name, []):
            if fname == field_name:
                return ftype
        return CType("float", bits=64)

    # ── Helper: получить LLVM-тип поля структуры ─────────────────────────────

    def _get_field_llvm_type(self, obj_name: str, field_name: str) -> str:
        """Возвращает LLVM-тип поля field_name структуры obj_name."""
        try:
            _, ct = self._lookup(obj_name)
        except Exception:
            return "i32"
        # Получаем имя типа структуры
        if ct.kind == "pointer":
            struct_type_name = ct.inner.name if ct.inner else None
        elif ct.kind == "named":
            struct_type_name = ct.name
        else:
            return "i32"
        if not struct_type_name:
            return "i32"
        field_types = self._struct_types.get(struct_type_name, [])
        for fname, ftype in field_types:
            if fname == field_name:
                return self._llvm_type(ftype)
        return "i32"  # fallback

    # ── Expressions ───────────────────────────────────────────────────────────

    def _gen_expr(self, expr, hint_ct: Optional[CType]) -> str:
        if isinstance(expr, A.IntLiteral):
            return str(expr.value)

        if isinstance(expr, A.FloatLiteral):
            return f"{expr.value:.17g}"

        if isinstance(expr, A.BoolLiteral):
            return "1" if expr.value else "0"

        if isinstance(expr, A.TextLiteral):
            return self._str_const(expr.value)

        if isinstance(expr, A.NullLiteral):
            return "null"

        if isinstance(expr, A.Identifier):
            # Enum-вариант — возвращаем числовой индекс напрямую
            if expr.name in self._enum_variants:
                return str(self._enum_variants[expr.name])
            alloca, ct = self._lookup(expr.name)
            return self._load(self._llvm_type(ct), alloca)

        if isinstance(expr, A.FieldAccess):
            # Case: points at index 0 field x  →  FieldAccess(obj=ArrayIndex, field="x")
            if isinstance(expr.obj, A.ArrayIndex):
                ptr = self._get_struct_field_via_array_index(expr.obj, expr.field)
                field_lt = self._get_array_struct_field_llvm_type(expr.obj, expr.field)
                tmp = self._new_tmp()
                self._emit(f"  {tmp} = load {field_lt}, ptr {ptr}")
                return tmp
            # Normal: FieldAccess(obj=Identifier)
            ptr = self._get_field_ptr(expr.obj.name, expr.field)
            tmp = self._new_tmp()
            field_lt = self._get_field_llvm_type(expr.obj.name, expr.field)
            self._emit(f"  {tmp} = load {field_lt}, ptr {ptr}")

            return tmp

        if isinstance(expr, A.BinaryOp):
            return self._gen_binop(expr, hint_ct)

        if isinstance(expr, A.CompareOp):
            return self._gen_compare(expr)

        if isinstance(expr, A.LogicOp):
            return self._gen_logic(expr)

        if isinstance(expr, A.NotOp):
            val = self._gen_expr(expr.operand, T_BOOL)
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = xor i1 {val}, 1")
            return tmp

        if isinstance(expr, A.AddressOf):
            alloca, ct = self._lookup(expr.name)
            return alloca

        if isinstance(expr, A.ValueAt):
            ptr_val = self._gen_expr(expr.pointer, None)
            tmp     = self._new_tmp()
            lt      = self._llvm_type(hint_ct) if hint_ct else "i64"
            self._emit(f"  {tmp} = load {lt}, ptr {ptr_val}")
            return tmp

        if isinstance(expr, A.SizeOf):
            ct  = ast_type_to_ctype(expr.target)
            bits = ct.bits if hasattr(ct, "bits") else 64
            return str(bits // 8)

        if isinstance(expr, A.ConvertExpr):
            return self._gen_convert(expr, hint_ct)

        if isinstance(expr, A.MethodCallExpr):
            if isinstance(expr.obj, A.Identifier):
                obj_ptr, obj_ct = self._lookup(expr.obj.name)
                struct_name = obj_ct.name
            else:
                raise CodegenError("Method call target must be a struct variable")

            llvm_func_name = f"{struct_name}_{expr.method}"

            args = [f"ptr {obj_ptr}"]
            for arg_expr in expr.args:
                val = self._gen_expr(arg_expr, CType("integer", bits=32))
                args.append(f"i32 {val}")

            tmp = self._new_tmp()
            self._emit(f"  {tmp} = call i32 @{llvm_func_name}({', '.join(args)})")
            return tmp

        if isinstance(expr, A.CallExpr):
            llvm_func_name = expr.func_name
            obj_ptr = None
            if hasattr(expr, 'object') and expr.object is not None:
                _, obj_ct = self._lookup(expr.object.name)
                llvm_func_name = f"{obj_ct.name}_{expr.func_name}"
                obj_ptr = self._get_object_ptr(expr.object)

            llvm_func_name = self._mangle_name(llvm_func_name)

            sig = self._func_types.get(llvm_func_name)
            args = []
            if obj_ptr is not None:
                args.append(f"ptr {obj_ptr}")
            for i, arg_expr in enumerate(expr.args):
                arg_ct = sig[0][i] if sig and i < len(sig[0]) else CType("integer")
                val = self._gen_expr(arg_expr, arg_ct)
                args.append(f"{self._llvm_type(arg_ct)} {val}")
            ret_ct = sig[1] if sig else CType("integer")
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = call {self._llvm_type(ret_ct)} @{llvm_func_name}({', '.join(args)})")
            return tmp

        if isinstance(expr, A.ArrayIndex):
            ptr = self._get_element_ptr(expr)
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = load i32, ptr {ptr}")
            return tmp

        if isinstance(expr, A.BitwiseOp):
            lt = self._llvm_type(hint_ct) if hint_ct and hint_ct.kind != "unknown" else "i32"
            # Зачитываем операнды расширяя до рабочего типа если нужно
            left = self._gen_expr(expr.left, hint_ct)
            right = self._gen_expr(expr.right, hint_ct)
            # Если операнды i8 а операция i32 — расширяем
            if lt == "i32":
                left = self._maybe_zext(left, "i32")
                right = self._maybe_zext(right, "i32")
            tmp = self._new_tmp()
            op_map = {"and": "and", "or": "or", "xor": "xor"}
            self._emit(f"  {tmp} = {op_map[expr.op]} {lt} {left}, {right}")
            return tmp

        if isinstance(expr, A.ShiftOp):
            lt = self._llvm_type(hint_ct) if hint_ct and hint_ct.kind != "unknown" else "i32"
            val = self._gen_expr(expr.value, hint_ct)
            amt = self._gen_expr(expr.amount, hint_ct)
            tmp = self._new_tmp()
            llvm_op = "shl" if expr.direction == "left" else "lshr"
            self._emit(f"  {tmp} = {llvm_op} {lt} {val}, {amt}")
            return tmp

        return "0"

    def _gen_binop(self, expr: A.BinaryOp, hint_ct: Optional[CType]) -> str:
        left  = self._gen_expr(expr.left,  hint_ct)
        right = self._gen_expr(expr.right, hint_ct)
        tmp   = self._new_tmp()

        is_float = (hint_ct and hint_ct.kind == "float")
        lt = self._llvm_type(hint_ct) if hint_ct else "i32"

        op_map_int   = {"plus": "add",  "minus": "sub",
                        "multiply": "mul", "divide": "sdiv", "remainder": "srem"}
        op_map_float = {"plus": "fadd", "minus": "fsub",
                        "multiply": "fmul", "divide": "fdiv", "remainder": "frem"}
        op_map = op_map_float if is_float else op_map_int
        op     = op_map.get(expr.op, "add")

        self._emit(f"  {tmp} = {op} {lt} {left}, {right}")
        return tmp

    def _gen_compare(self, expr: A.CompareOp) -> str:
        if isinstance(expr.left, A.Identifier):
            try:
                _, ct = self._lookup(expr.left.name)
            except CodegenError:
                ct = CType("integer", bits=32)
        else:
            ct = CType("integer", bits=32)

        left  = self._gen_expr(expr.left,  ct)
        right = self._gen_expr(expr.right, ct)
        tmp   = self._new_tmp()
        lt    = self._llvm_type(ct)

        is_float = ct.kind == "float"
        unsigned = (ct.kind == "integer" and not ct.signed)

        cmp_map = {
            "is equal to":          ("fcmp oeq" if is_float else "icmp eq"),
            "is not equal to":      ("fcmp one" if is_float else "icmp ne"),
            "is greater than":      ("fcmp ogt" if is_float else
                                     "icmp ugt" if unsigned else "icmp sgt"),
            "is less than":         ("fcmp olt" if is_float else
                                     "icmp ult" if unsigned else "icmp slt"),
            "is greater or equal":  ("fcmp oge" if is_float else
                                     "icmp uge" if unsigned else "icmp sge"),
            "is less or equal":     ("fcmp ole" if is_float else
                                     "icmp ule" if unsigned else "icmp sle"),
            "is not null":          "icmp ne",
            "is null":              "icmp eq",
        }
        op = cmp_map.get(expr.op, "icmp eq")

        if expr.op in ("is not null", "is null"):
            self._emit(f"  {tmp} = {op} ptr {left}, null")
        else:
            self._emit(f"  {tmp} = {op} {lt} {left}, {right}")
        return tmp

    def _gen_logic(self, expr: A.LogicOp) -> str:
        left  = self._gen_expr(expr.left,  T_BOOL)
        right = self._gen_expr(expr.right, T_BOOL)
        tmp   = self._new_tmp()
        op    = "and" if expr.op == "and" else "or"
        self._emit(f"  {tmp} = {op} i1 {left}, {right}")
        return tmp

    def _gen_convert(self, expr: A.ConvertExpr, hint_ct: Optional[CType]) -> str:
        val = self._gen_expr(expr.value, None)
        target_ct = ast_type_to_ctype(expr.target_type)
        
        if target_ct.kind == "integer" and target_ct.bits == 8:
            overflow_lbl = self._new_label("conv_overflow")
            ok_lbl = self._new_label("conv_ok")
            
            is_too_big = self._new_tmp()
            self._emit(f"  {is_too_big} = icmp sgt i32 {val}, 127")
            self._emit(f"  br i1 {is_too_big}, label %{overflow_lbl}, label %{ok_lbl}")
            
            self._emit(f"{overflow_lbl}:")
            self._push_scope()
            self._gen_stmts(expr.on_overflow)
            self._pop_scope()
            self._emit(f"  br label %{ok_lbl}")
            
            self._emit(f"{ok_lbl}:")
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = trunc i32 {val} to i8")
            return tmp
        elif target_ct.kind == "integer":
            dst_lt = self._llvm_type(target_ct)
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = trunc i32 {val} to {dst_lt}")
            return tmp
        elif target_ct.kind == "float":
            dst_lt = self._llvm_type(target_ct)
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = sitofp i32 {val} to {dst_lt}")
            return tmp
        else:
            return val

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _llvm_type(self, ct: CType) -> str:
        """Instance wrapper for llvm_type that injects enum and alias awareness."""
        # Resolve type aliases (e.g. Percent -> CType(named, inner=integer[signed,32bit]))
        # by extracting the inner (underlying) CType.
        if ct.kind == "named" and ct.name in self._alias_types:
            alias_ct = self._alias_types[ct.name]
            # The stored alias CType has kind="named" with inner=<real type>
            if alias_ct.inner is not None:
                ct = alias_ct.inner
            else:
                ct = alias_ct
        return llvm_type(ct, self._enum_names)

    def _maybe_zext(self, val: str, target_type: str) -> str:
        """Если val выглядит как i8-результат — расширяем до target_type через zext."""
        if val.startswith("%") and target_type == "i32":
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = zext i8 {val} to i32")
            return tmp
        return val

    def _maybe_trunc(self, val: str, target_lt: str) -> str:
        """Усекаем i32 значение до нужного типа если поле уже. Не трогаем i8/i1."""
        if target_lt == "i8" and val.startswith("%"):
            # Проверяем последнюю эмитированную инструкцию — если она уже i8, не truncate
            last = self._lines[-1] if self._lines else ""
            if "i8" in last and val in last:
                return val  # уже нужный тип
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = trunc i32 {val} to i8")
            return tmp
        return val

    def _get_field_ctype(self, obj_name: str, field_name: str) -> CType:
        """Возвращает CType поля структуры."""
        alloca, ct = self._lookup(obj_name)
        if ct.kind == "named":
            fields = self._struct_types.get(ct.name, [])
            for fname, fct in fields:
                if fname == field_name:
                    return fct
        return CType("integer", signed=True, bits=32)

    def _alloca(self, llvm_t: str, name: str = "") -> str:
        if name:
            tmp = f"%alloca_{name}_{self._tmp}"
            self._tmp += 1
        else:
            # _new_tmp уже инкрементирует _tmp — не нужно инкрементировать ещё раз
            tmp = self._new_tmp()
        self._emit(f"  {tmp} = alloca {llvm_t}")
        return tmp

    def _store(self, val: str, llvm_t: str, ptr: str) -> None:
        self._emit(f"  store {llvm_t} {val}, ptr {ptr}")

    def _load(self, llvm_t: str, ptr: str) -> str:
        tmp = self._new_tmp()
        self._emit(f"  {tmp} = load {llvm_t}, ptr {ptr}")
        return tmp

    def _new_tmp(self) -> str:
        self._tmp += 1
        return f"%t{self._tmp}"

    def _new_label(self, prefix: str) -> str:
        self._lbl += 1
        return f"{prefix}_{self._lbl}"

    def _str_const(self, text: str) -> str:
        if text in self._str_cache:
            return self._str_cache[text]
        name    = f"@str.{self._str_count}"
        self._str_count += 1
        escaped = text.replace("\\n", "\\0A")
        
        utf8_bytes = text.replace("\\n", "\n").encode('utf-8')
        length = len(utf8_bytes) + 1 
        
        self._globals.append(
            f'{name} = private unnamed_addr constant [{length} x i8] '
            f'c"{escaped}\\00"'
        )
        self._str_cache[text] = name
        return name

    def _push_scope(self) -> None:
        self._scope_stack.append({})

    def _pop_scope(self) -> None:
        self._scope_stack.pop()

    def _scope(self) -> dict:
        return self._scope_stack[-1]

    def _lookup(self, name: str) -> tuple[str, CType]:
        for scope in reversed(self._scope_stack):
            if name in scope:
                return scope[name]
        raise CodegenError(f"Undefined variable '{name}' during codegen")

    def _emit(self, line: str) -> None:
        self._lines.append(line)
