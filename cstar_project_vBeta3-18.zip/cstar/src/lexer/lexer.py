"""
C* Compiler — Lexer
Based on C* Language Reference, Section 1.1–1.2

Design notes
────────────
• The lexer is a single-pass character scanner.
• Multi-word compound tokens (e.g. "is equal to", "address of",
  "value at", "size of", "can be") are resolved via greedy lookahead
  over the already-scanned word buffer.
• Comments are emitted as tokens (useful for IDEs / formatters).
• NEWLINEs are emitted; the parser uses them to enforce
  "one statement per line".
• Bit-size suffixes (8bit, 16bit, 32bit, 64bit) are tokenised as
  keyword tokens when they appear inside [...] brackets; outside
  brackets they are a lexer error (helps catch misplaced qualifiers).
"""

from __future__ import annotations

import re
from typing import Iterator

from .token import (
    KEYWORDS, BIT_SIZES, Span, Token, TokenKind,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _is_ident_start(ch: str) -> bool:
    return ch.isalpha() and ch.isascii()

def _is_ident_continue(ch: str) -> bool:
    return (ch.isalpha() or ch.isdigit() or ch == "_") and ch.isascii()

def _is_digit(ch: str) -> bool:
    return ch.isdigit()


# ---------------------------------------------------------------------------
# LexError
# ---------------------------------------------------------------------------

class LexError(Exception):
    def __init__(self, message: str, span: Span) -> None:
        super().__init__(f"[{span}] {message}")
        self.span = span


# ---------------------------------------------------------------------------
# Compound-token resolution table
# ────────────────────────────────
# Each entry is (tuple-of-words, TokenKind).
# Tried longest-first so "is not equal to" beats "is not".
# ---------------------------------------------------------------------------

COMPOUND_TOKENS: list[tuple[tuple[str, ...], TokenKind]] = sorted(
    [
        (("is", "equal", "to"),           TokenKind.KW_IS_EQUAL_TO),
        (("is", "not", "equal", "to"),    TokenKind.KW_IS_NOT_EQUAL_TO),
        (("is", "greater", "than"),       TokenKind.KW_IS_GREATER_THAN),
        (("is", "less", "than"),          TokenKind.KW_IS_LESS_THAN),
        (("is", "greater", "or", "equal"),TokenKind.KW_IS_GREATER_OR_EQUAL),
        (("is", "less", "or", "equal"),   TokenKind.KW_IS_LESS_OR_EQUAL),
        (("is", "not", "null"),           TokenKind.KW_IS_NOT_NULL),
        (("is", "null"),                  TokenKind.KW_IS_NULL),
        (("address", "of"),               TokenKind.KW_ADDRESS_OF),
        (("value", "at"),                 TokenKind.KW_VALUE_AT),
        (("size", "of"),                  TokenKind.KW_SIZE_OF),
        (("can", "be"),                   TokenKind.KW_CAN_BE),
        (("multiply", "by"),              TokenKind.KW_MULTIPLY),  # "multiply by" → single MULTIPLY token
    ],
    key=lambda e: -len(e[0]),   # longest first
)

# Words that *start* a compound token (for fast early exit).
COMPOUND_STARTERS = {entry[0][0] for entry in COMPOUND_TOKENS}


# ---------------------------------------------------------------------------
# Lexer
# ---------------------------------------------------------------------------

class Lexer:
    """
    Tokenise a C* source string.

    Usage::

        lexer = Lexer(source, filename="example.cstar")
        tokens = list(lexer.tokenise())
    """

    def __init__(self, source: str, filename: str = "<input>") -> None:
        self._src = source
        self._filename = filename
        self._pos = 0
        self._line = 1
        self._col = 1

    # ── Public ────────────────────────────────────────────────────────────

    def tokenise(self) -> Iterator[Token]:
        """Yield all tokens including NEWLINEs, COMMENTs, and EOF."""
        # We collect into a buffer so we can do multi-word lookahead.
        buf: list[Token] = []

        for tok in self._raw_tokens():
            if tok.kind == TokenKind.IDENTIFIER:
                # might be a keyword or part of a compound token
                buf.append(self._keyword_or_ident(tok))
            else:
                buf.append(tok)

            # flush compound-token candidates eagerly
            yield from self._flush_compounds(buf, final=False)

        # flush remainder
        yield from self._flush_compounds(buf, final=True)

        yield Token(TokenKind.EOF, "", self._current_span(0))

    # ── Compound-token resolution ─────────────────────────────────────────

    def _flush_compounds(
        self, buf: list[Token], *, final: bool
    ) -> Iterator[Token]:
        """
        Inspect the front of *buf*; if a compound token can be formed,
        collapse it and yield the result.  Otherwise yield anything that
        can never be part of a compound (safe to emit early).
        """
        while buf:
            first = buf[0]

            # Only word-like tokens can start a compound.
            if first.kind not in (TokenKind.IDENTIFIER,) and \
               first.value not in COMPOUND_STARTERS:
                yield buf.pop(0)
                continue

            # Try to match a compound starting here.
            words = [t.value for t in buf if t.kind != TokenKind.NEWLINE
                     and t.kind != TokenKind.COMMENT_LINE
                     and t.kind != TokenKind.COMMENT_BLOCK]
            matched = None
            consumed = 0
            for pattern, kind in COMPOUND_TOKENS:
                if len(words) >= len(pattern) and \
                   tuple(words[:len(pattern)]) == pattern:
                    matched = kind
                    consumed = len(pattern)
                    break

            if matched is not None:
                # Consume *consumed* non-comment, non-newline tokens from buf
                span = buf[0].span
                raw_parts: list[str] = []
                count = 0
                indices_to_remove: list[int] = []
                for idx, t in enumerate(buf):
                    if t.kind in (TokenKind.NEWLINE,
                                  TokenKind.COMMENT_LINE,
                                  TokenKind.COMMENT_BLOCK):
                        continue
                    raw_parts.append(t.value)
                    indices_to_remove.append(idx)
                    count += 1
                    if count == consumed:
                        break
                for idx in reversed(indices_to_remove):
                    buf.pop(idx)
                yield Token(matched, " ".join(raw_parts), span)
                continue

            # No compound matched.  If this is the first word of a
            # *possible* future compound AND we still have more input
            # arriving, hold it.
            if not final and first.value in COMPOUND_STARTERS:
                break   # wait for more tokens

            # Safe to emit.
            yield buf.pop(0)

    # ── Raw scanner ───────────────────────────────────────────────────────

    def _raw_tokens(self) -> Iterator[Token]:
        while self._pos < len(self._src):
            ch = self._peek()

            # ── Whitespace (non-newline) ────────────────────────────────
            if ch in (" ", "\t", "\r"):
                self._advance()
                continue

            # ── Newline ─────────────────────────────────────────────────
            if ch == "\n":
                span = self._current_span(1)
                self._advance()
                yield Token(TokenKind.NEWLINE, "\\n", span)
                continue

            # ── Comment: -- or --[ ──────────────────────────────────────
            if ch == "-" and self._peek(1) == "-":
                yield from self._scan_comment()
                continue

            # ── String literal ──────────────────────────────────────────
            if ch == '"':
                yield self._scan_string()
                continue

            # ── Number (integer / float / hex) ──────────────────────────
            if _is_digit(ch) or (ch == "0" and self._peek(1) in ("x", "X")):
                yield self._scan_number()
                continue

            # ── Identifier or keyword ────────────────────────────────────
            if _is_ident_start(ch):
                yield self._scan_word()
                continue

            # ── Single-character punctuation ────────────────────────────
            punc = {
                "[": TokenKind.LBRACKET,
                "]": TokenKind.RBRACKET,
                "(": TokenKind.LPAREN,
                ")": TokenKind.RPAREN,
                ",": TokenKind.COMMA,
                ":": TokenKind.COLON,
                ".": TokenKind.DOT,
            }
            if ch in punc:
                span = self._current_span(1)
                self._advance()
                yield Token(punc[ch], ch, span)
                continue

            # ── Unknown character ────────────────────────────────────────
            span = self._current_span(1)
            raise LexError(
                f"Unexpected character {ch!r} — C* only allows ASCII letters, "
                f"digits, and the punctuation: [ ] ( ) \" _ . , : --",
                span,
            )

    # ── Scanners ──────────────────────────────────────────────────────────

    def _scan_comment(self) -> Iterator[Token]:
        span = self._current_span(2)
        self._advance(); self._advance()   # consume '--'

        if self._peek() == "[":
            # Block comment  --[ ... ]--
            self._advance()   # consume '['
            text_start = self._pos
            while self._pos < len(self._src):
                if self._peek() == "]" and self._peek(1) == "-" and self._peek(2) == "-":
                    raw = self._src[text_start:self._pos]
                    self._advance(); self._advance(); self._advance()  # ']--'
                    yield Token(TokenKind.COMMENT_BLOCK, raw.strip(), span)
                    return
                self._advance()
            raise LexError("Unterminated block comment — expected ']--'", span)
        else:
            # Line comment  -- ...
            text_start = self._pos
            while self._pos < len(self._src) and self._peek() != "\n":
                self._advance()
            raw = self._src[text_start:self._pos].strip()
            yield Token(TokenKind.COMMENT_LINE, raw, span)

    def _scan_string(self) -> Token:
        span = self._current_span(1)
        self._advance()   # opening "
        parts: list[str] = []
        while self._pos < len(self._src):
            ch = self._peek()
            if ch == '"':
                self._advance()
                return Token(TokenKind.STRING_LIT, "".join(parts), span)
            if ch == "\n":
                raise LexError("Unterminated string literal", span)
            if ch == "\\":
                self._advance()
                esc = self._peek()
                escape_map = {"n": "\n", "t": "\t", '"': '"', "\\": "\\"}
                if esc in escape_map:
                    parts.append(escape_map[esc])
                    self._advance()
                else:
                    raise LexError(f"Unknown escape sequence \\{esc}", span)
            else:
                parts.append(ch)
                self._advance()
        raise LexError("Unterminated string literal", span)

    def _scan_number(self) -> Token:
        span = self._current_span(1)
        start = self._pos

        # Hex literal
        if self._peek() == "0" and self._peek(1) in ("x", "X"):
            self._advance(); self._advance()  # 0x
            hex_start = self._pos
            while self._pos < len(self._src) and \
                  self._src[self._pos] in "0123456789abcdefABCDEF":
                self._advance()
            if self._pos == hex_start:
                raise LexError("Empty hex literal — expected digits after 0x", span)
            return Token(TokenKind.HEX_LIT, self._src[start:self._pos], span)

        # Decimal / float
        while self._pos < len(self._src) and _is_digit(self._peek()):
            self._advance()

        if self._pos < len(self._src) and self._peek() == ".":
            # Check it's not a dot-access (next char must be digit)
            if self._pos + 1 < len(self._src) and _is_digit(self._src[self._pos + 1]):
                self._advance()  # '.'
                while self._pos < len(self._src) and _is_digit(self._peek()):
                    self._advance()
                return Token(TokenKind.FLOAT_LIT, self._src[start:self._pos], span)

        # Check for bit-size suffix glued to a number: 8bit, 16bit, …
        # These only appear inside [...] type brackets, but we tokenise them
        # here and let the parser enforce the constraint.
        num_str = self._src[start:self._pos]
        suffix_start = self._pos
        if self._pos < len(self._src) and _is_ident_start(self._peek()):
            while self._pos < len(self._src) and _is_ident_continue(self._peek()):
                self._advance()
            candidate = self._src[start:self._pos]
            if candidate in BIT_SIZES:
                kind = KEYWORDS[candidate]
                return Token(kind, candidate, span)
            # Not a recognised suffix — put back and emit number only
            self._pos = suffix_start
            self._update_col_from_pos(suffix_start)

        return Token(TokenKind.INTEGER_LIT, num_str, span)

    def _scan_word(self) -> Token:
        span = self._current_span(1)
        start = self._pos
        while self._pos < len(self._src) and _is_ident_continue(self._peek()):
            self._advance()
        return Token(TokenKind.IDENTIFIER, self._src[start:self._pos], span)

    # ── Keyword / identifier disambiguation ───────────────────────────────

    def _keyword_or_ident(self, tok: Token) -> Token:
        word = tok.value
        if word in KEYWORDS:
            return Token(KEYWORDS[word], word, tok.span)
        return tok   # remains IDENTIFIER

    # ── Character-level helpers ───────────────────────────────────────────

    def _peek(self, offset: int = 0) -> str:
        idx = self._pos + offset
        return self._src[idx] if idx < len(self._src) else "\0"

    def _advance(self) -> str:
        ch = self._src[self._pos]
        self._pos += 1
        if ch == "\n":
            self._line += 1
            self._col = 1
        else:
            self._col += 1
        return ch

    def _current_span(self, length: int) -> Span:
        return Span(self._line, self._col, length)

    def _update_col_from_pos(self, target_pos: int) -> None:
        """Rewind col counter when we backtrack (only within same line)."""
        # Recalculate col by scanning backwards to last newline.
        src = self._src
        newline_pos = src.rfind("\n", 0, target_pos)
        self._col = target_pos - newline_pos
        self._pos = target_pos
