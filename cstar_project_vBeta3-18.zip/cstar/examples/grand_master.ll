; C* compiled output
target triple = "aarch64-unknown-linux-android24"

; External declarations
declare i32 @printf(ptr, ...)
declare ptr @malloc(i64)
declare void @free(ptr)
declare i32 @putchar(i32)

; Format strings for builtins
@fmt.int  = private unnamed_addr constant [4 x i8] c"%d\0A\00"
@fmt.uint = private unnamed_addr constant [4 x i8] c"%u\0A\00"
@fmt.flt  = private unnamed_addr constant [4 x i8] c"%f\0A\00"
@fmt.str  = private unnamed_addr constant [4 x i8] c"%s\0A\00"
@fmt.true = private unnamed_addr constant [6 x i8] c"true\0A\00"
@fmt.fals = private unnamed_addr constant [7 x i8] c"false\0A\00"

%struct.ResultContainer = type { i32, i1 }
@str.0 = private unnamed_addr constant [46 x i8] c"--- ЗАПУСК ГРАНД-ТЕСТА C* ---\00"
@str.1 = private unnamed_addr constant [50 x i8] c"Факториал 5 (должен быть 120):\00"
@str.2 = private unnamed_addr constant [59 x i8] c"Работа с динамической памятью...\00"
@str.3 = private unnamed_addr constant [32 x i8] c"Сумма массива (60):\00"
@str.4 = private unnamed_addr constant [68 x i8] c"Структура [ResultContainer] создана успешно.\00"
@str.5 = private unnamed_addr constant [73 x i8] c"Защита Раздела 2.5: указатель null опознан.\00"
@str.6 = private unnamed_addr constant [49 x i8] c"--- ТЕСТ ЗАВЕРШЕН УСПЕШНО ---\00"

define i32 @calculate_factorial(i32 %arg_n) {
entry:
  %alloca_result_0 = alloca i32
  store i32 0, ptr %alloca_result_0
  %alloca_n_1 = alloca i32
  store i32 %arg_n, ptr %alloca_n_1
  %t3 = load i32, ptr %alloca_n_1
  %t4 = icmp sle i32 %t3, 1
  br i1 %t4, label %if_then_1, label %if_else_2
if_then_1:
  store i32 1, ptr %alloca_result_0
  br label %if_end_3
if_else_2:
  %t5 = load i32, ptr %alloca_n_1
  %t6 = load i32, ptr %alloca_n_1
  %t7 = sub i32 %t6, 1
  %t8 = call i32 @calculate_factorial(i32 %t7)
  %t9 = mul i32 %t5, %t8
  store i32 %t9, ptr %alloca_result_0
  br label %if_end_3
if_end_3:
  %t10 = load i32, ptr %alloca_result_0
  ret i32 %t10
}

define i32 @main() {
entry:
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.0)
  %alloca_fact_five_10 = alloca i32
  store i32 0, ptr %alloca_fact_five_10
  %t12 = call i32 @calculate_factorial(i32 5)
  store i32 %t12, ptr %alloca_fact_five_10
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.1)
  %t13 = load i32, ptr %alloca_fact_five_10
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t13)
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.2)
  %t14 = call ptr @malloc(i64 12)
  %alloca_scores_14 = alloca ptr
  store ptr %t14, ptr %alloca_scores_14
  %t17 = load ptr, ptr %alloca_scores_14
  %t16 = getelementptr i32, ptr %t17, i32 0
  store i32 10, ptr %t16
  %t19 = load ptr, ptr %alloca_scores_14
  %t18 = getelementptr i32, ptr %t19, i32 1
  store i32 20, ptr %t18
  %t21 = load ptr, ptr %alloca_scores_14
  %t20 = getelementptr i32, ptr %t21, i32 2
  store i32 30, ptr %t20
  %alloca_total_21 = alloca i32
  store i32 0, ptr %alloca_total_21
  %alloca_i_22 = alloca i32
  store i32 0, ptr %alloca_i_22
  br label %loop_cond_4
loop_cond_4:
  %t24 = load i32, ptr %alloca_i_22
  %t25 = icmp slt i32 %t24, 3
  br i1 %t25, label %loop_body_5, label %loop_end_6
loop_body_5:
  %t26 = load i32, ptr %alloca_total_21
  %t27 = load i32, ptr %alloca_i_22
  %t29 = load ptr, ptr %alloca_scores_14
  %t28 = getelementptr i32, ptr %t29, i32 %t27
  %t30 = load i32, ptr %t28
  %t31 = add i32 %t26, %t30
  store i32 %t31, ptr %alloca_total_21
  %t32 = load i32, ptr %alloca_i_22
  %t33 = add i32 %t32, 1
  store i32 %t33, ptr %alloca_i_22
  br label %loop_cond_4
loop_end_6:
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.3)
  %t34 = load i32, ptr %alloca_total_21
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t34)
  %t35 = load ptr, ptr %alloca_scores_14
  call void @free(ptr %t35)
  %alloca_container_35 = alloca %struct.ResultContainer
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.4)
  %alloca_p_36 = alloca ptr
  store ptr null, ptr %alloca_p_36
  %t38 = load ptr, ptr %alloca_p_36
  %t39 = icmp eq ptr %t38, null
  br i1 %t39, label %if_then_7, label %if_end_9
if_then_7:
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.5)
  br label %if_end_9
if_end_9:
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.6)
  ret i32 0
}
