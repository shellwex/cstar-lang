"""
C* Compiler — Semantic Analyzer
Walks the AST and enforces the language's static rules.

Checks performed (Phase 1 — core):
  ✓ Variables declared before use
  ✓ No re-declaration in the same scope
  ✓ Constants not reassigned
  ✓ Type compatibility in assignments and arithmetic
  ✓ call blocks have at least one on error + one on success
  ✓ reject only inside functions that declare the error
  ✓ stop/skip only inside repeat blocks
  ✓ Empty blocks must contain a comment (warned, not errored here)
  ✓ Function return variable assigned on all paths (basic)
  ✓ Undeclared function calls flagged
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

from ..parser import ast as A
from ..lexer.token import Span


# ── Diagnostic ────────────────────────────────────────────────────────────────

@dataclass
class Diagnostic:
    kind: str          # "error" | "warning"
    message: str
    span: A.Span

    def __str__(self) -> str:
        return f"[{self.span}] {self.kind.upper()}: {self.message}"


# ── Type representation ───────────────────────────────────────────────────────

@dataclass(frozen=True)
class CType:
    """Canonical type used during semantic analysis."""
    kind: str          # "integer"|"float"|"byte"|"boolean"|"text"|
                       # "pointer"|"nothing"|"named"|"array"|"unknown"
    signed: bool = True
    bits: int = 32
    inner: Optional["CType"] = None   # for pointer
    name: str = ""                     # for named types

    def __str__(self) -> str:
        if self.kind == "integer":
            s = "signed" if self.signed else "unsigned"
            return f"integer[{s}, {self.bits}bit]"
        if self.kind == "float":
            return f"float[{self.bits}bit]"
        if self.kind == "pointer":
            return f"pointer[to {self.inner}]"
        if self.kind == "named":
            return self.name
        if self.kind == "array":
            return f"array[{self.bits}]"   # bits хранит размер
        return self.kind

    def is_numeric(self) -> bool:
        return self.kind in ("integer", "float", "byte")

    def is_comparable(self, other: "CType") -> bool:
        """Can self be compared with other?"""
        if self.kind == "unknown" or other.kind == "unknown":
            return True   # suppress cascading errors
        if self.kind == other.kind == "integer":
            return True
        if self.kind == other.kind == "float":
            return True
        if self.kind == other.kind == "boolean":
            return True
        if self.kind == other.kind == "text":
            return True
        if self.kind == other.kind == "byte":
            return True
        if "pointer" in (self.kind, other.kind):
            return True   # allow pointer null-checks
        if self.kind == other.kind == "named":
            return self.name == other.name
        # numeric cross-comparisons allowed
        if self.is_numeric() and other.is_numeric():
            return True
        return False

    def is_assignable_from(self, other: "CType") -> bool:
        if self.kind == "unknown" or other.kind == "unknown":
            return True
        if self == other:
            return True
        # ДОБАВЛЕНО: Разрешаем инициализировать массив числом (Раздел 4.2)
        if self.kind == "array" and other.is_numeric():
            return True
        # null → any pointer
        if self.kind == "pointer" and other.kind == "nothing":
            return True
        # numeric widening (relaxed — full check needs value-range analysis)
        if self.is_numeric() and other.is_numeric():
            return True
        return False


# Singletons for common types
T_UNKNOWN  = CType("unknown")
T_NOTHING  = CType("nothing")
T_BOOL     = CType("boolean")
T_BYTE     = CType("byte")
T_TEXT     = CType("text")
T_INT32    = CType("integer", signed=True,  bits=32)
T_UINT32   = CType("integer", signed=False, bits=32)
T_INT64    = CType("integer", signed=True,  bits=64)
T_FLOAT64  = CType("float",   bits=64)


def ast_type_to_ctype(node: A.TypeNode) -> CType:
    if isinstance(node, A.IntegerType):
        return CType("integer", signed=node.signed, bits=node.bits)
    if isinstance(node, A.ArrayType):
        # Официально регистрируем тип массива. 
        # Используем bits для хранения размера (количества элементов)
        return CType("array", bits=node.size)
    if isinstance(node, A.FloatType):
        return CType("float", bits=node.bits)
    if isinstance(node, A.ByteType):
        return T_BYTE
    if isinstance(node, A.BooleanType):
        return T_BOOL
    if isinstance(node, A.TextType):
        return T_TEXT
    if isinstance(node, A.NothingType):
        return T_NOTHING
    if isinstance(node, A.PointerType):
        return CType("pointer", inner=ast_type_to_ctype(node.inner))
    if isinstance(node, A.NamedType):
        return CType("named", name=node.name)
    return T_UNKNOWN


# ── Symbol table ──────────────────────────────────────────────────────────────

@dataclass
class Symbol:
    name: str
    ctype: CType
    is_constant: bool
    span: A.Span
    assigned: bool = False
    is_dead: bool = False      # True after transferred as owner
    owner_transferred_at: Optional[A.Span] = None  # where ownership was lost


class Scope:
    def __init__(self, parent: Optional["Scope"] = None) -> None:
        self._symbols: dict[str, Symbol] = {}
        self.parent = parent

    def declare(self, sym: Symbol) -> bool:
        """Returns False if name already declared in THIS scope."""
        if sym.name in self._symbols:
            return False
        self._symbols[sym.name] = sym
        return True

    def lookup(self, name: str) -> Optional[Symbol]:
        if name in self._symbols:
            return self._symbols[name]
        if self.parent:
            return self.parent.lookup(name)
        return None

    def child(self) -> "Scope":
        return Scope(parent=self)


# ── Function registry ─────────────────────────────────────────────────────────

@dataclass
class FuncSignature:
    name: str
    params: list[tuple[str, CType]]    # [(param_name, type)]
    return_type: CType
    declared_errors: set[str]          # error names from guards
    span: A.Span


# ── Analyzer ──────────────────────────────────────────────────────────────────

class SemanticError(Exception):
    pass


class Analyzer:
    def __init__(self) -> None:
        self.diagnostics: list[Diagnostic] = []
        self._funcs: dict[str, FuncSignature] = {}
        self._loop_depth: int = 0
        self._current_func: Optional[FuncSignature] = None

    # ── Public API ────────────────────────────────────────────────────────────

    def analyze_program(self, program: A.ProgramDef) -> list[Diagnostic]:
        self.diagnostics = []
        global_scope = Scope()

        # Register built-in functions
        self._register_builtins()

        # ДОБАВЛЕНО: Регистрация пользовательских типов
        for type_def in program.type_defs:
            if isinstance(type_def, A.StructDef):
                # Просто запоминаем, что такой тип теперь есть
                pass 

        # First pass — register all functions (allows forward references)
        for func in program.functions:
            self._register_function(func)

        # Second pass — analyze function bodies
        for func in program.functions:
            self._analyze_function(func, global_scope)

        # Analyze top-level body
        self._analyze_stmts(program.body, global_scope)

        return self.diagnostics

    def analyze_module(self, module: A.ModuleDef) -> list[Diagnostic]:
        self.diagnostics = []
        global_scope = Scope()
        for func in module.functions:
            self._register_function(func)
        for func in module.functions:
            self._analyze_function(func, global_scope)
        self._analyze_stmts(module.body, global_scope)
        return self.diagnostics

    @property
    def has_errors(self) -> bool:
        return any(d.kind == "error" for d in self.diagnostics)

    # ── Registration ──────────────────────────────────────────────────────────

    def _register_builtins(self) -> None:
        """Register built-in C* functions so semantic analysis accepts them."""
        nothing  = CType("nothing")
        int32    = CType("integer", signed=True,  bits=32)
        uint32   = CType("integer", signed=False, bits=32)
        float64  = CType("float",   bits=64)
        text     = CType("text")
        boolean  = CType("boolean")
        dummy    = A.Span(0, 0)
        builtins = {
            "print_integer":  ([("value", int32)],   nothing),
            "print_unsigned": ([("value", uint32)],  nothing),
            "print_float":    ([("value", float64)], nothing),
            "print_text":     ([("value", text)],    nothing),
            "print_boolean":  ([("value", boolean)], nothing),
            "print_line":     ([],                   nothing),
        }
        for name, (params, ret) in builtins.items():
            sig = FuncSignature(
                name=name,
                params=params,
                return_type=ret,
                declared_errors=set(),
                span=dummy,
            )
            self._funcs[name] = sig

    def _register_function(self, func: A.FunctionDef) -> None:
        params = [(p.name, ast_type_to_ctype(p.type_node)) for p in func.params]
        errors = {g.error_name for g in func.guards}
        sig = FuncSignature(
            name=func.name,
            params=params,
            return_type=ast_type_to_ctype(func.return_type),
            declared_errors=errors,
            span=func.span,
        )
        if func.name in self._funcs:
            self._error(f"Function '{func.name}' defined more than once", func.span)
        self._funcs[func.name] = sig

    # ── Function body ─────────────────────────────────────────────────────────

    def _analyze_function(self, func: A.FunctionDef, outer: Scope) -> None:
        prev = self._current_func
        self._current_func = self._funcs.get(func.name)

        scope = outer.child()

        # Inject parameters into scope
        for p in func.params:
            sym = Symbol(
                name=p.name,
                ctype=ast_type_to_ctype(p.type_node),
                is_constant=False,
                span=p.span,
                assigned=True,
            )
            scope.declare(sym)

        # Inject named return variable
        if func.return_name:
            ret_sym = Symbol(
                name=func.return_name,
                ctype=ast_type_to_ctype(func.return_type),
                is_constant=False,
                span=func.span,
                assigned=False,
            )
            scope.declare(ret_sym)

        self._analyze_stmts(func.body, scope)

        self._current_func = prev

    # ── Statement dispatch ────────────────────────────────────────────────────

    def _analyze_stmts(self, stmts: list, scope: Scope) -> None:
        for stmt in stmts:
            self._analyze_stmt(stmt, scope)

    def _analyze_stmt(self, stmt, scope: Scope) -> None:
        if isinstance(stmt, A.DeclareStmt):
            self._chk_declare(stmt, scope)
        elif isinstance(stmt, A.AssignStmt):
            self._chk_assign(stmt, scope)
        elif isinstance(stmt, A.IfStmt):
            self._chk_if(stmt, scope)
        elif isinstance(stmt, A.RepeatStmt):
            self._chk_repeat(stmt, scope)
        elif isinstance(stmt, A.CallStmt):
            self._chk_call(stmt, scope)
        elif isinstance(stmt, A.SimpleCallStmt):
            self._chk_simple_call(stmt, scope)
        elif isinstance(stmt, A.RejectStmt):
            self._chk_reject(stmt, scope)
        elif isinstance(stmt, A.StopStmt):
            self._chk_stop(stmt)
        elif isinstance(stmt, A.SkipStmt):
            self._chk_skip(stmt)
        elif isinstance(stmt, A.ReturnStmt):
            self._chk_return(stmt, scope)
        elif isinstance(stmt, A.AllocateStmt):
            self._chk_allocate(stmt, scope)
        elif isinstance(stmt, A.ReleaseStmt):
            self._chk_release(stmt, scope)

    # ── Declare ───────────────────────────────────────────────────────────────

    def _chk_declare(self, stmt: A.DeclareStmt, scope: Scope) -> None:
        ctype = ast_type_to_ctype(stmt.type_node)
        val_type = self._infer_expr(stmt.initial_value, scope)

        if not ctype.is_assignable_from(val_type):
            self._error(
                f"Cannot initialise '{stmt.name}' of type {ctype} "
                f"with value of type {val_type}",
                stmt.span,
            )

        sym = Symbol(
            name=stmt.name,
            ctype=ctype,
            is_constant=stmt.is_constant,
            span=stmt.span,
            assigned=True,
        )
        if not scope.declare(sym):
            self._error(
                f"'{stmt.name}' is already declared in this scope",
                stmt.span,
            )

    # ── Assign ────────────────────────────────────────────────────────────────

    def _chk_assign(self, stmt: A.AssignStmt, scope: Scope) -> None:
        val_type = self._infer_expr(stmt.value, scope)

        if isinstance(stmt.target, A.Identifier):
            sym = scope.lookup(stmt.target.name)
            if sym is None:
                self._error(
                    f"'{stmt.target.name}' is not declared",
                    stmt.target.span,
                )
                return
            if sym.is_dead:
                self._error(
                    f"'{sym.name}' was transferred as owner and no longer exists",
                    stmt.span,
                )
                return
            if sym.is_constant:
                self._error(
                    f"'{sym.name}' is constant and cannot be reassigned",
                    stmt.span,
                )
                return
            if not sym.ctype.is_assignable_from(val_type):
                self._error(
                    f"Cannot assign {val_type} to '{sym.name}' of type {sym.ctype}",
                    stmt.span,
                )
            sym.assigned = True

        elif isinstance(stmt.target, A.FieldAccess):
            self._infer_expr(stmt.target, scope)   # checks obj exists

        elif isinstance(stmt.target, A.ValueAt):
            self._infer_expr(stmt.target.pointer, scope)

    # ── If ────────────────────────────────────────────────────────────────────

    def _chk_if(self, stmt: A.IfStmt, scope: Scope) -> None:
        cond_type = self._infer_expr(stmt.condition, scope)
        if cond_type.kind not in ("boolean", "unknown"):
            # Allow comparison results (CompareOp returns boolean implicitly)
            pass   # condition type is always boolean after comparison

        self._analyze_stmts(stmt.then_body, scope.child())

        for cond, body in stmt.elseif_branches:
            self._infer_expr(cond, scope)
            self._analyze_stmts(body, scope.child())

        if stmt.else_body is not None:
            self._analyze_stmts(stmt.else_body, scope.child())

    # ── Repeat ────────────────────────────────────────────────────────────────

    def _chk_repeat(self, stmt: A.RepeatStmt, scope: Scope) -> None:
        self._infer_expr(stmt.condition, scope)
        self._loop_depth += 1
        self._analyze_stmts(stmt.body, scope.child())
        self._loop_depth -= 1

    # ── Call (block) ──────────────────────────────────────────────────────────

    def _chk_call(self, stmt: A.CallStmt, scope: Scope) -> None:
        sig = self._funcs.get(stmt.func_name)
        if sig is None:
            self._error(
                f"Unknown function '{stmt.func_name}'",
                stmt.span,
            )
        else:
            # Check named args match declared params
            provided = {name for name, _, __ in stmt.args}
            expected = {name for name, _ in sig.params}
            for missing in expected - provided:
                self._error(
                    f"Call to '{stmt.func_name}' missing argument '{missing}'",
                    stmt.span,
                )
            for extra in provided - expected:
                self._error(
                    f"Call to '{stmt.func_name}' has unexpected argument '{extra}'",
                    stmt.span,
                )
            # Type-check provided args
            param_map = dict(sig.params)
            for arg_name, arg_mode, arg_expr in stmt.args:
                if arg_name in param_map:
                    arg_type = self._infer_expr(arg_expr, scope)
                    expected_type = param_map[arg_name]
                    if not expected_type.is_assignable_from(arg_type):
                        self._error(
                            f"Argument '{arg_name}' expects {expected_type} "
                            f"but got {arg_type}",
                            arg_expr.span,
                        )

        # Validate handlers
        handler_kinds = [h.kind for h in stmt.handlers]
        if "success" not in handler_kinds:
            self._error(
                f"Call to '{stmt.func_name}' is missing 'on success' handler",
                stmt.span,
            )
        error_handlers = [h for h in stmt.handlers if h.kind == "error"]
        if sig and sig.declared_errors and not error_handlers:
            self._error(
                f"Call to '{stmt.func_name}' is missing 'on error' handler(s) "
                f"— function can raise: {', '.join(sig.declared_errors)}",
                stmt.span,
            )

        # Analyze handler bodies
        for handler in stmt.handlers:
            self._analyze_stmts(handler.body, scope.child())

    # ── Simple call ───────────────────────────────────────────────────────────

    def _chk_simple_call(self, stmt: A.SimpleCallStmt, scope: Scope) -> None:
        sig = self._funcs.get(stmt.func_name)
        if sig is None:
            # Not all functions are defined in the same file — warn, don't error
            self._warning(
                f"Function '{stmt.func_name}' not found in current scope "
                f"(may be defined in another module)",
                stmt.span,
            )
            return
        # Simple call only valid for nothing-returning functions
        if sig.return_type.kind != "nothing":
            self._error(
                f"'{stmt.func_name}' returns {sig.return_type} — "
                f"use 'call ... on success' syntax to capture the return value",
                stmt.span,
            )
        # Positional args — check count
        if len(stmt.args) != len(sig.params):
            self._error(
                f"'{stmt.func_name}' expects {len(sig.params)} argument(s), "
                f"got {len(stmt.args)}",
                stmt.span,
            )
        for expr in stmt.args:
            self._infer_expr(expr, scope)

    # ── Reject ────────────────────────────────────────────────────────────────

    def _chk_reject(self, stmt: A.RejectStmt, scope: Scope) -> None:
        if self._current_func is None:
            self._error("'reject' used outside a function", stmt.span)
            return
        if stmt.error_name not in self._current_func.declared_errors:
            self._error(
                f"Error '{stmt.error_name}' not declared in function "
                f"'{self._current_func.name}' — add 'on {stmt.error_name} "
                f"reject with error[{stmt.error_name}]' to the function header",
                stmt.span,
            )

    # ── Stop / Skip ───────────────────────────────────────────────────────────

    def _chk_stop(self, stmt: A.StopStmt) -> None:
        if self._loop_depth == 0:
            self._error("'stop' used outside a 'repeat while' block", stmt.span)

    def _chk_skip(self, stmt: A.SkipStmt) -> None:
        if self._loop_depth == 0:
            self._error("'skip' used outside a 'repeat while' block", stmt.span)

    # ── Return ────────────────────────────────────────────────────────────────

    def _chk_return(self, stmt: A.ReturnStmt, scope: Scope) -> None:
        if stmt.value is not None:
            self._infer_expr(stmt.value, scope)

    # ── Allocate / Release ────────────────────────────────────────────────────

    def _chk_allocate(self, stmt: A.AllocateStmt, scope: Scope) -> None:
        self._infer_expr(stmt.size, scope)
        # Variable should already be declared as a pointer
        sym = scope.lookup(stmt.name)
        if sym is None:
            self._error(f"'{stmt.name}' is not declared", stmt.span)
        elif sym.ctype.kind != "pointer":
            self._error(
                f"'allocate' target '{stmt.name}' must be a pointer type, "
                f"got {sym.ctype}",
                stmt.span,
            )

    def _chk_release(self, stmt: A.ReleaseStmt, scope: Scope) -> None:
        sym = scope.lookup(stmt.name)
        if sym is None:
            self._error(f"'{stmt.name}' is not declared", stmt.span)
        # ИСПРАВЛЕНО: добавляем "array" в список разрешенных типов для release
        elif sym.ctype.kind not in ("pointer", "array"):
            self._error(
                f"'release' target '{stmt.name}' must be a pointer or array type, "
                f"got {sym.ctype}",
                stmt.span,
            )

    # ── Expression inference ──────────────────────────────────────────────────

    def _infer_expr(self, expr, scope: Scope) -> CType:
        if isinstance(expr, A.IntLiteral):
            return T_INT32

        if isinstance(expr, A.FloatLiteral):
            return T_FLOAT64

        if isinstance(expr, A.BoolLiteral):
            return T_BOOL

        if isinstance(expr, A.TextLiteral):
            return T_TEXT

        if isinstance(expr, A.NullLiteral):
            return T_NOTHING   # null is assignable to any pointer

        if isinstance(expr, A.Identifier):
            sym = scope.lookup(expr.name)
            if sym is None:
                self._error(f"'{expr.name}' is not declared", expr.span)
                return T_UNKNOWN
            return sym.ctype

        if isinstance(expr, A.FieldAccess):
            obj_type = self._infer_expr(expr.obj, scope)
            if obj_type.kind not in ("named", "unknown"):
                self._warning(
                    f"Field access on non-struct type {obj_type}",
                    expr.span,
                )
            return T_UNKNOWN   # field types resolved later (needs type registry)

        if isinstance(expr, A.BinaryOp):
            left  = self._infer_expr(expr.left,  scope)
            right = self._infer_expr(expr.right, scope)
            if not (left.is_numeric() or left.kind == "unknown") or \
               not (right.is_numeric() or right.kind == "unknown"):
                self._error(
                    f"Arithmetic '{expr.op}' requires numeric operands, "
                    f"got {left} and {right}",
                    expr.span,
                )
            # Result type: prefer left type
            return left if left.kind != "unknown" else right

        if isinstance(expr, A.CompareOp):
            left  = self._infer_expr(expr.left,  scope)
            right = self._infer_expr(expr.right, scope)
            if not left.is_comparable(right):
                self._error(
                    f"Cannot compare {left} with {right}",
                    expr.span,
                )
            return T_BOOL

        if isinstance(expr, A.LogicOp):
            left  = self._infer_expr(expr.left,  scope)
            right = self._infer_expr(expr.right, scope)
            for t, side in ((left, "left"), (right, "right")):
                if t.kind not in ("boolean", "unknown"):
                    self._error(
                        f"'{expr.op}' requires boolean operands, "
                        f"{side} side is {t}",
                        expr.span,
                    )
            return T_BOOL

        if isinstance(expr, A.NotOp):
            t = self._infer_expr(expr.operand, scope)
            if t.kind not in ("boolean", "unknown"):
                self._error(f"'not' requires a boolean operand, got {t}", expr.span)
            return T_BOOL

        if isinstance(expr, A.AddressOf):
            from ..parser.ast import OwnershipMode
            sym = scope.lookup(expr.name)
            if sym is None:
                self._error(f"'{expr.name}' is not declared", expr.span)
                return T_UNKNOWN
            # Check if already dead (transferred as owner)
            if sym.is_dead:
                self._error(
                    f"'{expr.name}' was already transferred as owner at "
                    f"{sym.owner_transferred_at} — it no longer exists",
                    expr.span,
                )
                return T_UNKNOWN
            # If transferring ownership, mark original as dead
            if hasattr(expr, 'mode') and expr.mode == OwnershipMode.OWNER:
                sym.is_dead = True
                sym.owner_transferred_at = expr.span
            return CType("pointer", inner=sym.ctype)

        if isinstance(expr, A.ValueAt):
            ptr_type = self._infer_expr(expr.pointer, scope)
            if ptr_type.kind == "pointer" and ptr_type.inner:
                return ptr_type.inner
            if ptr_type.kind != "unknown":
                self._error(
                    f"'value at' requires a pointer, got {ptr_type}",
                    expr.span,
                )
            return T_UNKNOWN

        if isinstance(expr, A.SizeOf):
            return T_UINT32

        if isinstance(expr, A.ConvertExpr):
            self._infer_expr(expr.value, scope)
            return ast_type_to_ctype(expr.target_type)

        if isinstance(expr, A.CallExpr):
            sig = self._funcs.get(expr.func_name)
            if sig is None:
                self._error(f"Function '{expr.func_name}' is not declared", expr.span)
                return T_UNKNOWN
            # Проверяем аргументы
            if len(expr.args) != len(sig.params):
                self._error(f"'{expr.func_name}' expects {len(sig.params)} args, got {len(expr.args)}", expr.span)
            return sig.return_type

        return T_UNKNOWN

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _error(self, message: str, span: A.Span) -> None:
        self.diagnostics.append(Diagnostic("error", message, span))

    def _warning(self, message: str, span: A.Span) -> None:
        self.diagnostics.append(Diagnostic("warning", message, span))
