; C* compiled output
target triple = "aarch64-unknown-linux-android24"

; External declarations
declare i32 @printf(ptr, ...)
declare ptr @malloc(i64)
declare void @free(ptr)
declare i32 @putchar(i32)

; Format strings for builtins
@fmt.int  = private unnamed_addr constant [4 x i8] c"%d\0A\00"
@fmt.uint = private unnamed_addr constant [4 x i8] c"%u\0A\00"
@fmt.flt  = private unnamed_addr constant [4 x i8] c"%f\0A\00"
@fmt.str  = private unnamed_addr constant [4 x i8] c"%s\0A\00"
@fmt.true = private unnamed_addr constant [6 x i8] c"true\0A\00"
@fmt.fals = private unnamed_addr constant [7 x i8] c"false\0A\00"

@str.0 = private unnamed_addr constant [49 x i8] c"--- ТЕСТ БИТОВЫХ ОПЕРАЦИЙ ---\00"
@str.1 = private unnamed_addr constant [84 x i8] c"Флаги после установки 3-го бита (должно быть 5):\00"
@str.2 = private unnamed_addr constant [57 x i8] c"Сдвиг влево на 2 (должно быть 20):\00"
@str.3 = private unnamed_addr constant [58 x i8] c"XOR самого на себя (должно быть 0):\00"
@str.4 = private unnamed_addr constant [34 x i8] c"--- ТЕСТ ЗАВЕРШЕН ---\00"

define i32 @main() {
entry:
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.0)
  %alloca_flags_0 = alloca i32
  store i32 1, ptr %alloca_flags_0
  %t2 = load i32, ptr %alloca_flags_0
  %t3 = or i32 %t2, 4
  store i32 %t3, ptr %alloca_flags_0
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.1)
  %t4 = load i32, ptr %alloca_flags_0
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t4)
  %alloca_shifted_val_4 = alloca i32
  store i32 0, ptr %alloca_shifted_val_4
  %t6 = load i32, ptr %alloca_flags_0
  %t7 = shl i32 %t6, 2
  store i32 %t7, ptr %alloca_shifted_val_4
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.2)
  %t8 = load i32, ptr %alloca_shifted_val_4
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t8)
  %alloca_xor_test_8 = alloca i32
  store i32 0, ptr %alloca_xor_test_8
  %t10 = load i32, ptr %alloca_shifted_val_4
  %t11 = load i32, ptr %alloca_shifted_val_4
  %t12 = xor i32 %t10, %t11
  store i32 %t12, ptr %alloca_xor_test_8
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.3)
  %t13 = load i32, ptr %alloca_xor_test_8
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t13)
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.4)
  ret i32 0
}
