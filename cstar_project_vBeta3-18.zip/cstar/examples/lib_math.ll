; C* compiled output
target triple = "aarch64-unknown-linux-android24"

; External declarations
declare i32 @printf(ptr, ...)
declare ptr @malloc(i64)
declare void @free(ptr)
declare i32 @putchar(i32)

; Format strings for builtins
@fmt.int  = private unnamed_addr constant [4 x i8] c"%d\0A\00"
@fmt.uint = private unnamed_addr constant [4 x i8] c"%u\0A\00"
@fmt.flt  = private unnamed_addr constant [4 x i8] c"%f\0A\00"
@fmt.str  = private unnamed_addr constant [4 x i8] c"%s\0A\00"
@fmt.true = private unnamed_addr constant [6 x i8] c"true\0A\00"
@fmt.fals = private unnamed_addr constant [7 x i8] c"false\0A\00"

@str.0 = private unnamed_addr constant [54 x i8] c"Результат работы модуля LibMath:\00"

define void @secret_algorithm(i32 %arg_input) {
entry:
  %alloca_input_0 = alloca i32
  store i32 %arg_input, ptr %alloca_input_0
  %alloca_result_1 = alloca i32
  store i32 0, ptr %alloca_result_1
  %t3 = load i32, ptr %alloca_input_0
  %t4 = shl i32 %t3, 3
  store i32 %t4, ptr %alloca_result_1
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.0)
  %t5 = load i32, ptr %alloca_result_1
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t5)
  ret void
}
