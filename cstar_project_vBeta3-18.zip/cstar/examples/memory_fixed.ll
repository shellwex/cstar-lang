; C* compiled output
target triple = "aarch64-unknown-linux-android24"

; External declarations
declare i32 @printf(ptr, ...)
declare ptr @malloc(i64)
declare void @free(ptr)
declare i32 @putchar(i32)

; Format strings for builtins
@fmt.int  = private unnamed_addr constant [4 x i8] c"%d\0A\00"
@fmt.uint = private unnamed_addr constant [4 x i8] c"%u\0A\00"
@fmt.flt  = private unnamed_addr constant [4 x i8] c"%f\0A\00"
@fmt.str  = private unnamed_addr constant [4 x i8] c"%s\0A\00"
@fmt.true = private unnamed_addr constant [6 x i8] c"true\0A\00"
@fmt.fals = private unnamed_addr constant [7 x i8] c"false\0A\00"

@str.0 = private unnamed_addr constant [62 x i8] c"Тест исправленной безопасности...\00"
@str.1 = private unnamed_addr constant [96 x i8] c"Память освобождена, компилятор должен быть доволен!\00"

define i32 @main() {
entry:
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.0)
  %t1 = call ptr @malloc(i64 40)
  %alloca_buffer_1 = alloca ptr
  store ptr %t1, ptr %alloca_buffer_1
  %t4 = load ptr, ptr %alloca_buffer_1
  %t3 = getelementptr i32, ptr %t4, i32 0
  store i32 777, ptr %t3
  %t5 = load ptr, ptr %alloca_buffer_1
  call void @free(ptr %t5)
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.1)
  ret i32 0
}
