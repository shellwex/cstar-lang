; C* compiled output
target triple = "aarch64-unknown-linux-android24"

; External declarations
declare i32 @printf(ptr, ...)
declare ptr @malloc(i64)
declare void @free(ptr)
declare i32 @putchar(i32)

; Format strings for builtins
@fmt.int  = private unnamed_addr constant [4 x i8] c"%d\0A\00"
@fmt.uint = private unnamed_addr constant [4 x i8] c"%u\0A\00"
@fmt.flt  = private unnamed_addr constant [4 x i8] c"%f\0A\00"
@fmt.str  = private unnamed_addr constant [4 x i8] c"%s\0A\00"
@fmt.true = private unnamed_addr constant [6 x i8] c"true\0A\00"
@fmt.fals = private unnamed_addr constant [7 x i8] c"false\0A\00"

@str.0 = private unnamed_addr constant [50 x i8] c"Запуск главной программы...\00"
declare void @secret_algorithm(i32)
@str.1 = private unnamed_addr constant [25 x i8] c"Конец работы.\00"

define i32 @main() {
entry:
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.0)
  call void @secret_algorithm(i32 10)
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.1)
  ret i32 0
}
