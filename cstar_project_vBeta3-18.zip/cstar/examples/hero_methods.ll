; C* compiled output
target triple = "aarch64-unknown-linux-android24"

; External declarations
declare i32 @printf(ptr, ...)
declare ptr @malloc(i64)
declare void @free(ptr)
declare i32 @putchar(i32)

; Format strings for builtins
@fmt.int  = private unnamed_addr constant [4 x i8] c"%d\0A\00"
@fmt.uint = private unnamed_addr constant [4 x i8] c"%u\0A\00"
@fmt.flt  = private unnamed_addr constant [4 x i8] c"%f\0A\00"
@fmt.str  = private unnamed_addr constant [4 x i8] c"%s\0A\00"
@fmt.true = private unnamed_addr constant [6 x i8] c"true\0A\00"
@fmt.fals = private unnamed_addr constant [7 x i8] c"false\0A\00"

%struct.Hero = type { i32 }
@str.0 = private unnamed_addr constant [69 x i8] c"--- ТЕСТ: ОБЪЕКТНО-ОРИЕНТИРОВАННЫЙ C* ---\00"
@str.1 = private unnamed_addr constant [24 x i8] c"HP до лечения:\00"
@str.2 = private unnamed_addr constant [35 x i8] c"HP после лечения (75):\00"
@str.3 = private unnamed_addr constant [34 x i8] c"--- ТЕСТ ЗАВЕРШЕН ---\00"

define i32 @Hero_heal(ptr %self, i32 %arg_amount) {
entry:
  %alloca_new_hp_0 = alloca i32
  %alloca_amount_1 = alloca i32
  store i32 %arg_amount, ptr %alloca_amount_1
  %t3 = getelementptr %struct.Hero, ptr %self, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = load i32, ptr %alloca_amount_1
  %t6 = add i32 %t4, %t5
  store i32 %t6, ptr %t3
  %t7 = load i32, ptr %t3
  store i32 %t7, ptr %alloca_new_hp_0
  %t8 = load i32, ptr %alloca_new_hp_0
  ret i32 %t8
}

define i32 @main() {
entry:
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.0)
  %alloca_player_8 = alloca %struct.Hero
  %t10 = getelementptr %struct.Hero, ptr %alloca_player_8, i32 0, i32 0
  store i32 50, ptr %t10
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.1)
  %t11 = getelementptr %struct.Hero, ptr %alloca_player_8, i32 0, i32 0
  %t12 = load i32, ptr %t11
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t12)
  %alloca_dummy_12 = alloca i32
  store i32 0, ptr %alloca_dummy_12
  %t14 = call i32 @Hero_heal(ptr %alloca_player_8, i32 25)
  store i32 %t14, ptr %alloca_dummy_12
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.2)
  %t15 = getelementptr %struct.Hero, ptr %alloca_player_8, i32 0, i32 0
  %t16 = load i32, ptr %t15
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t16)
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.3)
  ret i32 0
}
