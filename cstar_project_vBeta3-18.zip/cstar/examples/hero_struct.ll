; C* compiled output
target triple = "aarch64-unknown-linux-android24"

; External declarations
declare i32 @printf(ptr, ...)
declare ptr @malloc(i64)
declare void @free(ptr)
declare i32 @putchar(i32)

; Format strings for builtins
@fmt.int  = private unnamed_addr constant [4 x i8] c"%d\0A\00"
@fmt.uint = private unnamed_addr constant [4 x i8] c"%u\0A\00"
@fmt.flt  = private unnamed_addr constant [4 x i8] c"%f\0A\00"
@fmt.str  = private unnamed_addr constant [4 x i8] c"%s\0A\00"
@fmt.true = private unnamed_addr constant [6 x i8] c"true\0A\00"
@fmt.fals = private unnamed_addr constant [7 x i8] c"false\0A\00"

%struct.Hero = type { i32, i32 }
@str.0 = private unnamed_addr constant [34 x i8] c"--- ТЕСТ СТРУКТУР ---\00"
@str.1 = private unnamed_addr constant [31 x i8] c"Здоровье игрока:\00"
@str.2 = private unnamed_addr constant [27 x i8] c"Золото игрока:\00"
@str.3 = private unnamed_addr constant [56 x i8] c"Золото после находки клада (75):\00"
@str.4 = private unnamed_addr constant [34 x i8] c"--- ТЕСТ ЗАВЕРШЕН ---\00"

define i32 @main() {
entry:
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.0)
  %alloca_player_0 = alloca %struct.Hero
  %t2 = getelementptr %struct.Hero, ptr %alloca_player_0, i32 0, i32 0
  store i32 100, ptr %t2
  %t3 = getelementptr %struct.Hero, ptr %alloca_player_0, i32 0, i32 1
  store i32 50, ptr %t3
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.1)
  %t4 = getelementptr %struct.Hero, ptr %alloca_player_0, i32 0, i32 0
  %t5 = load i32, ptr %t4
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t5)
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.2)
  %t6 = getelementptr %struct.Hero, ptr %alloca_player_0, i32 0, i32 1
  %t7 = load i32, ptr %t6
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t7)
  %t8 = getelementptr %struct.Hero, ptr %alloca_player_0, i32 0, i32 1
  %t9 = getelementptr %struct.Hero, ptr %alloca_player_0, i32 0, i32 1
  %t10 = load i32, ptr %t9
  %t11 = add i32 %t10, 25
  store i32 %t11, ptr %t8
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.3)
  %t12 = getelementptr %struct.Hero, ptr %alloca_player_0, i32 0, i32 1
  %t13 = load i32, ptr %t12
  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 %t13)
  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr @str.4)
  ret i32 0
}
