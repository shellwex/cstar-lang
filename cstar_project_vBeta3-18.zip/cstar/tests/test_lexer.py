"""
C* Lexer tests — pytest
Run:  pytest tests/test_lexer.py -v
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from src.lexer import Lexer, LexError, TokenKind


def lex(src: str) -> list:
    """Return non-NEWLINE, non-EOF, non-COMMENT tokens."""
    return [
        t for t in Lexer(src).tokenise()
        if t.kind not in (
            TokenKind.NEWLINE,
            TokenKind.EOF,
            TokenKind.COMMENT_LINE,
            TokenKind.COMMENT_BLOCK,
        )
    ]

def lex_kinds(src: str) -> list[TokenKind]:
    return [t.kind for t in lex(src)]

def lex_all_kinds(src: str) -> list[TokenKind]:
    """Include NEWLINEs, exclude EOF."""
    return [
        t.kind for t in Lexer(src).tokenise()
        if t.kind != TokenKind.EOF
    ]


# ── Keywords ────────────────────────────────────────────────────────────────

class TestKeywords:
    def test_declare(self):
        assert lex_kinds("declare") == [TokenKind.KW_DECLARE]

    def test_function(self):
        assert lex_kinds("function") == [TokenKind.KW_FUNCTION]

    def test_end(self):
        assert lex_kinds("end") == [TokenKind.KW_END]

    def test_is_alone(self):
        # "is" by itself → KW_IS
        assert lex_kinds("is") == [TokenKind.KW_IS]

    def test_true_false(self):
        kinds = lex_kinds("true false")
        assert kinds == [TokenKind.BOOL_LIT, TokenKind.BOOL_LIT]

    def test_null(self):
        assert lex_kinds("null") == [TokenKind.NULL_LIT]

    def test_nothing(self):
        assert lex_kinds("nothing") == [TokenKind.KW_NOTHING]


# ── Compound tokens ──────────────────────────────────────────────────────────

class TestCompoundTokens:
    def test_is_equal_to(self):
        assert lex_kinds("is equal to") == [TokenKind.KW_IS_EQUAL_TO]

    def test_is_not_equal_to(self):
        assert lex_kinds("is not equal to") == [TokenKind.KW_IS_NOT_EQUAL_TO]

    def test_is_greater_than(self):
        assert lex_kinds("is greater than") == [TokenKind.KW_IS_GREATER_THAN]

    def test_is_less_than(self):
        assert lex_kinds("is less than") == [TokenKind.KW_IS_LESS_THAN]

    def test_is_greater_or_equal(self):
        assert lex_kinds("is greater or equal") == [TokenKind.KW_IS_GREATER_OR_EQUAL]

    def test_is_less_or_equal(self):
        assert lex_kinds("is less or equal") == [TokenKind.KW_IS_LESS_OR_EQUAL]

    def test_is_not_null(self):
        assert lex_kinds("is not null") == [TokenKind.KW_IS_NOT_NULL]

    def test_address_of(self):
        assert lex_kinds("address of") == [TokenKind.KW_ADDRESS_OF]

    def test_value_at(self):
        assert lex_kinds("value at") == [TokenKind.KW_VALUE_AT]

    def test_size_of(self):
        assert lex_kinds("size of") == [TokenKind.KW_SIZE_OF]

    def test_can_be(self):
        assert lex_kinds("can be") == [TokenKind.KW_CAN_BE]

    def test_multiply_by(self):
        assert lex_kinds("multiply by") == [TokenKind.KW_MULTIPLY]

    def test_is_in_expression(self):
        # "score is 100" — 'is' is not followed by equal/not/greater/less
        kinds = lex_kinds("score is 100")
        assert kinds == [TokenKind.IDENTIFIER, TokenKind.KW_IS, TokenKind.INTEGER_LIT]

    def test_compound_raw_value(self):
        tokens = lex("is equal to")
        assert tokens[0].value == "is equal to"


# ── Literals ────────────────────────────────────────────────────────────────

class TestLiterals:
    def test_integer(self):
        t = lex("42")[0]
        assert t.kind == TokenKind.INTEGER_LIT
        assert t.value == "42"

    def test_zero(self):
        assert lex_kinds("0") == [TokenKind.INTEGER_LIT]

    def test_float(self):
        t = lex("3.14")[0]
        assert t.kind == TokenKind.FLOAT_LIT
        assert t.value == "3.14"

    def test_float_zero(self):
        assert lex_kinds("0.0") == [TokenKind.FLOAT_LIT]

    def test_hex(self):
        t = lex("0xB8000")[0]
        assert t.kind == TokenKind.HEX_LIT
        assert t.value == "0xB8000"

    def test_hex_lowercase(self):
        assert lex_kinds("0xff") == [TokenKind.HEX_LIT]

    def test_string(self):
        t = lex('"hello"')[0]
        assert t.kind == TokenKind.STRING_LIT
        assert t.value == "hello"

    def test_empty_string(self):
        t = lex('""')[0]
        assert t.kind == TokenKind.STRING_LIT
        assert t.value == ""

    def test_string_escape_newline(self):
        t = lex('"line1\\nline2"')[0]
        assert "\n" in t.value

    def test_string_with_spaces(self):
        t = lex('"hello world"')[0]
        assert t.value == "hello world"


# ── Type qualifiers ──────────────────────────────────────────────────────────

class TestTypeQualifiers:
    def test_bit_sizes(self):
        for src, kind in [
            ("8bit",  TokenKind.KW_8BIT),
            ("16bit", TokenKind.KW_16BIT),
            ("32bit", TokenKind.KW_32BIT),
            ("64bit", TokenKind.KW_64BIT),
        ]:
            assert lex_kinds(src) == [kind], f"Failed for {src}"

    def test_signed_unsigned(self):
        assert lex_kinds("signed") == [TokenKind.KW_SIGNED]
        assert lex_kinds("unsigned") == [TokenKind.KW_UNSIGNED]

    def test_type_bracket(self):
        # integer[signed, 32bit]
        kinds = lex_kinds("integer[signed, 32bit]")
        assert kinds == [
            TokenKind.KW_INTEGER,
            TokenKind.LBRACKET,
            TokenKind.KW_SIGNED,
            TokenKind.COMMA,
            TokenKind.KW_32BIT,
            TokenKind.RBRACKET,
        ]


# ── Punctuation ──────────────────────────────────────────────────────────────

class TestPunctuation:
    def test_brackets(self):
        kinds = lex_kinds("[]")
        assert kinds == [TokenKind.LBRACKET, TokenKind.RBRACKET]

    def test_parens(self):
        kinds = lex_kinds("()")
        assert kinds == [TokenKind.LPAREN, TokenKind.RPAREN]

    def test_comma(self):
        assert lex_kinds(",") == [TokenKind.COMMA]

    def test_colon(self):
        assert lex_kinds(":") == [TokenKind.COLON]

    def test_dot(self):
        assert lex_kinds(".") == [TokenKind.DOT]

    def test_field_access(self):
        # current_sample.left_channel
        kinds = lex_kinds("current_sample.left_channel")
        assert kinds == [TokenKind.IDENTIFIER, TokenKind.DOT, TokenKind.IDENTIFIER]


# ── Comments ─────────────────────────────────────────────────────────────────

class TestComments:
    def _lex_comments(self, src):
        return [
            t for t in Lexer(src).tokenise()
            if t.kind in (TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK)
        ]

    def test_line_comment(self):
        toks = self._lex_comments("-- hello world")
        assert len(toks) == 1
        assert toks[0].kind == TokenKind.COMMENT_LINE
        assert "hello world" in toks[0].value

    def test_block_comment(self):
        toks = self._lex_comments("--[\n  block comment\n]--")
        assert len(toks) == 1
        assert toks[0].kind == TokenKind.COMMENT_BLOCK

    def test_comment_does_not_affect_tokens(self):
        kinds = lex_kinds("declare -- comment\ninteger")
        assert TokenKind.KW_DECLARE in kinds
        assert TokenKind.KW_INTEGER in kinds

    def test_unterminated_block_comment(self):
        with pytest.raises(LexError):
            list(Lexer("--[ not closed").tokenise())


# ── Identifiers ───────────────────────────────────────────────────────────────

class TestIdentifiers:
    def test_simple(self):
        t = lex("audio_buffer")[0]
        assert t.kind == TokenKind.IDENTIFIER
        assert t.value == "audio_buffer"

    def test_single_word(self):
        # words that are NOT keywords remain identifiers
        t = lex("my_variable")[0]
        assert t.kind == TokenKind.IDENTIFIER

    def test_underscore_in_name(self):
        t = lex("first_number")[0]
        assert t.kind == TokenKind.IDENTIFIER


# ── Newlines ──────────────────────────────────────────────────────────────────

class TestNewlines:
    def test_newline_emitted(self):
        kinds = lex_all_kinds("declare\ninteger")
        assert TokenKind.NEWLINE in kinds

    def test_multiple_newlines(self):
        kinds = lex_all_kinds("a\n\nb")
        assert kinds.count(TokenKind.NEWLINE) == 2


# ── Span / source location ────────────────────────────────────────────────────

class TestSpans:
    def test_first_token_on_line1(self):
        t = lex("declare")[0]
        assert t.span.line == 1
        assert t.span.col == 1

    def test_second_line(self):
        tokens = [
            t for t in Lexer("declare\ninteger").tokenise()
            if t.kind not in (TokenKind.NEWLINE, TokenKind.EOF)
        ]
        assert tokens[1].span.line == 2

    def test_column_offset(self):
        tokens = lex("  integer")
        assert tokens[0].span.col == 3


# ── Real code snippets ────────────────────────────────────────────────────────

class TestRealCode:
    def test_declare_statement(self):
        src = 'declare integer[signed, 32bit] named counter is 0'
        kinds = lex_kinds(src)
        assert kinds == [
            TokenKind.KW_DECLARE,
            TokenKind.KW_INTEGER,
            TokenKind.LBRACKET,
            TokenKind.KW_SIGNED,
            TokenKind.COMMA,
            TokenKind.KW_32BIT,
            TokenKind.RBRACKET,
            TokenKind.KW_NAMED,
            TokenKind.IDENTIFIER,   # counter
            TokenKind.KW_IS,
            TokenKind.INTEGER_LIT,  # 0
        ]

    def test_if_condition(self):
        src = "if score is greater than 100"
        kinds = lex_kinds(src)
        assert kinds == [
            TokenKind.KW_IF,
            TokenKind.IDENTIFIER,
            TokenKind.KW_IS_GREATER_THAN,
            TokenKind.INTEGER_LIT,
        ]

    def test_null_check(self):
        src = "if ptr is not null"
        kinds = lex_kinds(src)
        assert kinds == [
            TokenKind.KW_IF,
            TokenKind.IDENTIFIER,
            TokenKind.KW_IS_NOT_NULL,
        ]

    def test_arithmetic(self):
        src = "result is total multiply by factor"
        kinds = lex_kinds(src)
        assert kinds == [
            TokenKind.IDENTIFIER,
            TokenKind.KW_IS,
            TokenKind.IDENTIFIER,
            TokenKind.KW_MULTIPLY,
            TokenKind.IDENTIFIER,
        ]

    def test_pointer_type(self):
        src = "pointer[to integer[signed, 32bit]]"
        kinds = lex_kinds(src)
        assert kinds == [
            TokenKind.KW_POINTER,
            TokenKind.LBRACKET,
            TokenKind.KW_TO,
            TokenKind.KW_INTEGER,
            TokenKind.LBRACKET,
            TokenKind.KW_SIGNED,
            TokenKind.COMMA,
            TokenKind.KW_32BIT,
            TokenKind.RBRACKET,
            TokenKind.RBRACKET,
        ]

    def test_hardware_address(self):
        src = "at address 0xB8000"
        kinds = lex_kinds(src)
        assert kinds == [
            TokenKind.KW_AT,
            TokenKind.KW_ADDRESS,
            TokenKind.HEX_LIT,
        ]

    def test_reject_with_error(self):
        src = "reject with error[NullPointerAccess]"
        kinds = lex_kinds(src)
        assert kinds == [
            TokenKind.KW_REJECT,
            TokenKind.KW_WITH,
            TokenKind.KW_ERROR,
            TokenKind.LBRACKET,
            TokenKind.IDENTIFIER,
            TokenKind.RBRACKET,
        ]


# ── Error cases ───────────────────────────────────────────────────────────────

class TestErrors:
    def test_semicolon_forbidden(self):
        with pytest.raises(LexError):
            list(Lexer("declare integer;").tokenise())

    def test_star_forbidden(self):
        with pytest.raises(LexError):
            list(Lexer("a * b").tokenise())

    def test_ampersand_forbidden(self):
        with pytest.raises(LexError):
            list(Lexer("a & b").tokenise())

    def test_hash_forbidden(self):
        with pytest.raises(LexError):
            list(Lexer("#include").tokenise())

    def test_unterminated_string(self):
        with pytest.raises(LexError):
            list(Lexer('"not closed').tokenise())

    def test_empty_hex(self):
        with pytest.raises(LexError):
            list(Lexer("0x").tokenise())
