"""
C* Parser tests
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from src.parser import Parser, ParseError
from src.parser import ast as A


def parse_program(src):
    return Parser(src).parse_program()

def parse_stmts(src):
    """Wrap source in a minimal program and return body statements."""
    full = f"program Test\nbody\n{src}\nend body\nend program"
    return parse_program(full).body


# ── Program structure ─────────────────────────────────────────────────────────

class TestProgram:
    def test_empty_program(self):
        p = parse_program("program Hello\nbody\nend body\nend program")
        assert isinstance(p, A.ProgramDef)
        assert p.name == "Hello"
        assert p.body == []

    def test_program_name(self):
        p = parse_program("program DataProcessor\nbody\nend body\nend program")
        assert p.name == "DataProcessor"


# ── Types ─────────────────────────────────────────────────────────────────────

class TestTypes:
    def test_integer_signed_32(self):
        stmts = parse_stmts("declare integer[signed, 32bit] named counter is 0")
        t = stmts[0].type_node
        assert isinstance(t, A.IntegerType)
        assert t.signed is True
        assert t.bits == 32

    def test_integer_unsigned_8(self):
        stmts = parse_stmts("declare integer[unsigned, 8bit] named byte_val is 0")
        t = stmts[0].type_node
        assert isinstance(t, A.IntegerType)
        assert t.signed is False
        assert t.bits == 8

    def test_float_64(self):
        stmts = parse_stmts("declare float[64bit] named temperature is 0.0")
        t = stmts[0].type_node
        assert isinstance(t, A.FloatType)
        assert t.bits == 64

    def test_boolean(self):
        stmts = parse_stmts("declare boolean named is_active is true")
        assert isinstance(stmts[0].type_node, A.BooleanType)

    def test_byte(self):
        stmts = parse_stmts("declare byte named raw_data is 0")
        assert isinstance(stmts[0].type_node, A.ByteType)

    def test_text(self):
        stmts = parse_stmts('declare text named greeting is "Hello"')
        assert isinstance(stmts[0].type_node, A.TextType)

    def test_pointer(self):
        stmts = parse_stmts(
            "declare pointer[to integer[signed, 32bit]] named ptr is null")
        t = stmts[0].type_node
        assert isinstance(t, A.PointerType)
        assert isinstance(t.inner, A.IntegerType)

    def test_named_type(self):
        stmts = parse_stmts("declare AudioSample named sample is null")
        assert isinstance(stmts[0].type_node, A.NamedType)
        assert stmts[0].type_node.name == "AudioSample"


# ── Declarations ──────────────────────────────────────────────────────────────

class TestDeclare:
    def test_basic_declare(self):
        stmts = parse_stmts("declare integer[signed, 32bit] named score is 0")
        s = stmts[0]
        assert isinstance(s, A.DeclareStmt)
        assert s.name == "score"
        assert s.is_constant is False

    def test_constant_declare(self):
        stmts = parse_stmts(
            "declare constant integer[unsigned, 32bit] named max_size is 1024")
        s = stmts[0]
        assert s.is_constant is True
        assert s.name == "max_size"

    def test_initial_int_value(self):
        stmts = parse_stmts("declare integer[signed, 32bit] named x is 42")
        assert isinstance(stmts[0].initial_value, A.IntLiteral)
        assert stmts[0].initial_value.value == 42

    def test_initial_bool_value(self):
        stmts = parse_stmts("declare boolean named flag is true")
        assert isinstance(stmts[0].initial_value, A.BoolLiteral)
        assert stmts[0].initial_value.value is True

    def test_initial_text_value(self):
        stmts = parse_stmts('declare text named msg is "hello"')
        assert isinstance(stmts[0].initial_value, A.TextLiteral)
        assert stmts[0].initial_value.value == "hello"

    def test_initial_null_value(self):
        stmts = parse_stmts(
            "declare pointer[to byte] named ptr is null")
        assert isinstance(stmts[0].initial_value, A.NullLiteral)

    def test_on_stack(self):
        stmts = parse_stmts(
            "declare integer[signed, 32bit] named x on stack is 0")
        assert stmts[0].location == "stack"

    def test_on_heap(self):
        stmts = parse_stmts(
            "declare integer[signed, 32bit] named x on heap is 0")
        assert stmts[0].location == "heap"


# ── Assignment ────────────────────────────────────────────────────────────────

class TestAssign:
    def test_simple_assign(self):
        stmts = parse_stmts("score is 100")
        s = stmts[0]
        assert isinstance(s, A.AssignStmt)
        assert isinstance(s.target, A.Identifier)
        assert s.target.name == "score"
        assert isinstance(s.value, A.IntLiteral)

    def test_assign_expr(self):
        stmts = parse_stmts("score is score plus 50")
        s = stmts[0]
        assert isinstance(s.value, A.BinaryOp)
        assert s.value.op == "plus"

    def test_field_assign(self):
        stmts = parse_stmts("sample.left_channel is 1024")
        s = stmts[0]
        assert isinstance(s.target, A.FieldAccess)
        assert s.target.field == "left_channel"


# ── Expressions ───────────────────────────────────────────────────────────────

class TestExpressions:
    def _expr(self, src):
        stmts = parse_stmts(f"result is {src}")
        return stmts[0].value

    def test_int_literal(self):
        e = self._expr("42")
        assert isinstance(e, A.IntLiteral)
        assert e.value == 42

    def test_hex_literal(self):
        e = self._expr("0xFF")
        assert isinstance(e, A.IntLiteral)
        assert e.value == 255

    def test_float_literal(self):
        e = self._expr("3.14")
        assert isinstance(e, A.FloatLiteral)

    def test_bool_true(self):
        e = self._expr("true")
        assert isinstance(e, A.BoolLiteral)
        assert e.value is True

    def test_plus(self):
        e = self._expr("a plus b")
        assert isinstance(e, A.BinaryOp)
        assert e.op == "plus"

    def test_minus(self):
        e = self._expr("total minus tax")
        assert isinstance(e, A.BinaryOp)
        assert e.op == "minus"

    def test_multiply(self):
        e = self._expr("width multiply height")
        assert isinstance(e, A.BinaryOp)
        assert e.op == "multiply"

    def test_is_equal_to(self):
        e = self._expr("score is equal to 100")
        assert isinstance(e, A.CompareOp)
        assert e.op == "is equal to"

    def test_is_greater_than(self):
        e = self._expr("temp is greater than 100")
        assert isinstance(e, A.CompareOp)
        assert e.op == "is greater than"

    def test_is_not_null(self):
        e = self._expr("ptr is not null")
        assert isinstance(e, A.CompareOp)
        assert e.op == "is not null"

    def test_and(self):
        e = self._expr("a is equal to 1 and b is equal to 2")
        assert isinstance(e, A.LogicOp)
        assert e.op == "and"

    def test_not(self):
        e = self._expr("not flag")
        assert isinstance(e, A.NotOp)

    def test_field_access(self):
        e = self._expr("sample.left_channel")
        assert isinstance(e, A.FieldAccess)
        assert e.field == "left_channel"

    def test_address_of(self):
        e = self._expr("address of my_var")
        assert isinstance(e, A.AddressOf)
        assert e.name == "my_var"

    def test_size_of(self):
        e = self._expr("size of integer[signed, 32bit]")
        assert isinstance(e, A.SizeOf)
        assert isinstance(e.target, A.IntegerType)


# ── Control flow ──────────────────────────────────────────────────────────────

class TestControlFlow:
    def test_if_basic(self):
        stmts = parse_stmts(
            "if score is greater than 100\n"
            "stop\n"
            "end if"
        )
        s = stmts[0]
        assert isinstance(s, A.IfStmt)
        assert isinstance(s.condition, A.CompareOp)
        assert len(s.then_body) == 1

    def test_if_otherwise(self):
        stmts = parse_stmts(
            "if flag is equal to true\n"
            "stop\n"
            "otherwise\n"
            "skip\n"
            "end otherwise\n"
            "end if"
        )
        s = stmts[0]
        assert s.else_body is not None
        assert len(s.else_body) == 1

    def test_repeat_while(self):
        stmts = parse_stmts(
            "repeat while counter is less than 10\n"
            "counter is counter plus 1\n"
            "end repeat"
        )
        s = stmts[0]
        assert isinstance(s, A.RepeatStmt)
        assert isinstance(s.condition, A.CompareOp)

    def test_stop(self):
        stmts = parse_stmts("stop")
        assert isinstance(stmts[0], A.StopStmt)

    def test_skip(self):
        stmts = parse_stmts("skip")
        assert isinstance(stmts[0], A.SkipStmt)


# ── Function definitions ──────────────────────────────────────────────────────

class TestFunctions:
    def _parse_func(self, src):
        full = f"program Test\n{src}\nbody\nend body\nend program"
        return parse_program(full).functions[0]

    def test_simple_function(self):
        f = self._parse_func(
            "function get_value\n"
            "receives\nnothing\n"
            "returns\ninteger[signed, 32bit] named result\n"
            "body\nresult is 42\nend body\n"
            "end function"
        )
        assert isinstance(f, A.FunctionDef)
        assert f.name == "get_value"
        assert f.params == []
        assert isinstance(f.return_type, A.IntegerType)

    def test_function_with_params(self):
        f = self._parse_func(
            "function add\n"
            "receives\n"
            "integer[signed, 32bit] named first_number\n"
            "integer[signed, 32bit] named second_number\n"
            "returns\ninteger[signed, 32bit] named total\n"
            "body\ntotal is first_number plus second_number\nend body\n"
            "end function"
        )
        assert len(f.params) == 2
        assert f.params[0].name == "first_number"

    def test_function_returns_nothing(self):
        f = self._parse_func(
            "function log_it\n"
            "receives\nnothing\n"
            "returns\nnothing\n"
            "body\nend body\n"
            "end function"
        )
        assert isinstance(f.return_type, A.NothingType)


# ── Call statements ───────────────────────────────────────────────────────────

class TestCalls:
    def test_simple_call(self):
        stmts = parse_stmts('log_message receives "hello" and 1')
        s = stmts[0]
        assert isinstance(s, A.SimpleCallStmt)
        assert s.func_name == "log_message"
        assert len(s.args) == 2

    def test_call_block(self):
        stmts = parse_stmts(
            "call divide_numbers\n"
            "with dividend: 100\n"
            "with divisor: 5\n"
            "on error[division_by_zero]\n"
            "stop\n"
            "on success\n"
            "skip\n"
            "end call"
        )
        s = stmts[0]
        assert isinstance(s, A.CallStmt)
        assert s.func_name == "divide_numbers"
        assert len(s.args) == 2
        assert s.args[0] == ("dividend", A.IntLiteral(span=s.args[0][1].span, value=100))
        assert len(s.handlers) == 2
        assert s.handlers[0].kind == "error"
        assert s.handlers[0].error_name == "division_by_zero"
        assert s.handlers[1].kind == "success"


# ── Reject ────────────────────────────────────────────────────────────────────

class TestReject:
    def test_reject(self):
        stmts = parse_stmts("reject with error[division_by_zero]")
        s = stmts[0]
        assert isinstance(s, A.RejectStmt)
        assert s.error_name == "division_by_zero"


# ── Parse errors ──────────────────────────────────────────────────────────────

class TestParseErrors:
    def test_missing_end(self):
        with pytest.raises(ParseError):
            parse_program("program Test\nbody\nif true\nend program")

    def test_wrong_type_qualifier(self):
        with pytest.raises(ParseError):
            parse_stmts("declare integer[32bit] named x is 0")  # missing signed/unsigned
