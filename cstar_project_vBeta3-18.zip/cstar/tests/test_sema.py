import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from src.parser import Parser
from src.sema import Analyzer


def analyze(src):
    full = f"program Test\n{src}\nbody\nend body\nend program"
    prog = Parser(full).parse_program()
    a = Analyzer()
    diags = a.analyze_program(prog)
    return diags

def errors(src):
    return [d for d in analyze(src) if d.kind == "error"]

def warnings(src):
    return [d for d in analyze(src) if d.kind == "warning"]

def err_msgs(src):
    return [d.message for d in errors(src)]

def no_errors(src):
    return errors(src) == []


# ── Variable declaration ──────────────────────────────────────────────────────

class TestDeclare:
    def test_valid_declare(self):
        assert no_errors(
            "body\ndeclare integer[signed, 32bit] named x is 0\nend body")

    def test_redeclaration(self):
        src = ("body\n"
               "declare integer[signed, 32bit] named x is 0\n"
               "declare integer[signed, 32bit] named x is 1\n"
               "end body")
        msgs = err_msgs(src)
        assert any("already declared" in m for m in msgs)

    def test_constant_reassign(self):
        src = ("body\n"
               "declare constant integer[unsigned, 32bit] named max is 100\n"
               "max is 200\n"
               "end body")
        msgs = err_msgs(src)
        assert any("constant" in m for m in msgs)

    def test_type_mismatch_init(self):
        src = ('body\n'
               'declare boolean named flag is 42\n'
               'end body')
        # 42 is integer, flag is boolean — mismatch
        msgs = err_msgs(src)
        assert any("boolean" in m or "integer" in m for m in msgs)

    def test_null_to_pointer_ok(self):
        assert no_errors(
            "body\n"
            "declare pointer[to byte] named ptr is null\n"
            "end body")


# ── Variable usage ────────────────────────────────────────────────────────────

class TestUsage:
    def test_use_before_declare(self):
        src = ("body\n"
               "result is 42\n"
               "end body")
        msgs = err_msgs(src)
        assert any("not declared" in m for m in msgs)

    def test_use_after_declare(self):
        assert no_errors(
            "body\n"
            "declare integer[signed, 32bit] named result is 0\n"
            "result is 42\n"
            "end body")

    def test_assign_undeclared(self):
        src = ("body\n"
               "ghost_var is 99\n"
               "end body")
        msgs = err_msgs(src)
        assert any("not declared" in m for m in msgs)


# ── Arithmetic type checking ──────────────────────────────────────────────────

class TestArithmetic:
    def test_int_plus_int_ok(self):
        assert no_errors(
            "body\n"
            "declare integer[signed, 32bit] named a is 1\n"
            "declare integer[signed, 32bit] named b is 2\n"
            "declare integer[signed, 32bit] named c is 0\n"
            "c is a plus b\n"
            "end body")

    def test_bool_plus_int_error(self):
        src = ("body\n"
               "declare boolean named flag is true\n"
               "declare integer[signed, 32bit] named x is 0\n"
               "declare integer[signed, 32bit] named result is 0\n"
               "result is flag plus x\n"
               "end body")
        msgs = err_msgs(src)
        assert any("numeric" in m or "Arithmetic" in m for m in msgs)


# ── Comparison ────────────────────────────────────────────────────────────────

class TestComparison:
    def test_int_compare_ok(self):
        assert no_errors(
            "body\n"
            "declare integer[signed, 32bit] named x is 5\n"
            "declare boolean named result is false\n"
            "result is x is greater than 3\n"
            "end body")

    def test_bool_compare_int_error(self):
        src = ("body\n"
               "declare boolean named flag is true\n"
               "declare integer[signed, 32bit] named x is 1\n"
               "declare boolean named result is false\n"
               "result is flag is greater than x\n"
               "end body")
        # boolean vs integer comparison — error
        msgs = err_msgs(src)
        assert any("compare" in m or "Cannot compare" in m for m in msgs)


# ── Logic operators ───────────────────────────────────────────────────────────

class TestLogic:
    def test_bool_and_ok(self):
        assert no_errors(
            "body\n"
            "declare boolean named a is true\n"
            "declare boolean named b is false\n"
            "declare boolean named result is false\n"
            "result is a and b\n"
            "end body")

    def test_int_and_error(self):
        src = ("body\n"
               "declare integer[signed, 32bit] named a is 1\n"
               "declare integer[signed, 32bit] named b is 2\n"
               "declare boolean named result is false\n"
               "result is a and b\n"
               "end body")
        msgs = err_msgs(src)
        assert any("boolean" in m for m in msgs)


# ── Stop / Skip outside loop ──────────────────────────────────────────────────

class TestLoopControl:
    def test_stop_outside_loop(self):
        src = ("body\n"
               "stop\n"
               "end body")
        msgs = err_msgs(src)
        assert any("repeat" in m or "stop" in m for m in msgs)

    def test_skip_outside_loop(self):
        src = ("body\n"
               "skip\n"
               "end body")
        msgs = err_msgs(src)
        assert any("repeat" in m or "skip" in m for m in msgs)

    def test_stop_inside_loop_ok(self):
        assert no_errors(
            "body\n"
            "declare boolean named flag is true\n"
            "repeat while flag is equal to true\n"
            "stop\n"
            "end repeat\n"
            "end body")


# ── Call validation ───────────────────────────────────────────────────────────

class TestCalls:
    def test_call_missing_success(self):
        src = ("function my_func\nreceives\nnothing\nreturns\nnothing\n"
               "body\nend body\nend function\n"
               "body\n"
               "call my_func\n"
               "on error[something]\nskip\n"
               "end call\n"
               "end body")
        msgs = err_msgs(src)
        assert any("success" in m for m in msgs)

    def test_call_missing_error_handler(self):
        src = ("function risky\nreceives\nnothing\nreturns\nnothing\n"
               "on overflow\nreject with error[overflow]\n"
               "body\nend body\nend function\n"
               "body\n"
               "call risky\n"
               "on success\nskip\n"
               "end call\n"
               "end body")
        msgs = err_msgs(src)
        assert any("error" in m for m in msgs)

    def test_call_unknown_function(self):
        src = ("body\n"
               "call nonexistent_function\n"
               "on success\nskip\n"
               "end call\n"
               "end body")
        msgs = err_msgs(src)
        assert any("Unknown function" in m or "nonexistent" in m for m in msgs)

    def test_valid_call(self):
        src = ("function safe_func\nreceives\nnothing\nreturns\nnothing\n"
               "body\nend body\nend function\n"
               "body\n"
               "call safe_func\n"
               "on success\nskip\n"
               "end call\n"
               "end body")
        assert no_errors(src)


# ── Reject validation ─────────────────────────────────────────────────────────

class TestReject:
    def test_reject_undeclared_error(self):
        src = ("function my_func\nreceives\nnothing\nreturns\nnothing\n"
               "body\n"
               "reject with error[undeclared_error]\n"
               "end body\nend function\n"
               "body\nend body")
        msgs = err_msgs(src)
        assert any("undeclared_error" in m or "not declared" in m for m in msgs)

    def test_reject_declared_error_ok(self):
        src = ("function my_func\nreceives\nnothing\nreturns\nnothing\n"
               "on overflow\nreject with error[overflow]\n"
               "body\n"
               "reject with error[overflow]\n"
               "end body\nend function\n"
               "body\nend body")
        assert no_errors(src)


# ── Duplicate function ────────────────────────────────────────────────────────

class TestFunctions:
    def test_duplicate_function(self):
        src = ("function foo\nreceives\nnothing\nreturns\nnothing\n"
               "body\nend body\nend function\n"
               "function foo\nreceives\nnothing\nreturns\nnothing\n"
               "body\nend body\nend function\n"
               "body\nend body")
        msgs = err_msgs(src)
        assert any("more than once" in m or "defined" in m for m in msgs)

    def test_address_of_ok(self):
        assert no_errors(
            "body\n"
            "declare integer[signed, 32bit] named x is 0\n"
            "declare pointer[to integer[signed, 32bit]] named ptr is null\n"
            "ptr is address of x\n"
            "end body")
