import sys
import os

# ВАЖНО: Сначала расширяем пути поиска, чтобы Python увидел cstarc.py
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import subprocess
import pytest
# Теперь этот импорт сработает
from cstarc import compile_source

MEGA_PROGRAM = """
program MegaSuperTest
--[
    MEGA TEST v0.2
    Проверяет: Generics, Ownership, Match, Range Checks, Float, Bitwise
]--

define type[Percent] as integer[signed, 32bit]
    valid range from 0 to 100
end type

define type[Status]
    can be
        offline
        online
        error
    end can be
end type

define type[Container] for any[T]
    contains
        T named value
    end contains
end type

body
    print_text receives "INTEGRATION_START"

    -- 1. Test: Range Invariants (Sema)
    declare Percent named p on stack is 85
    print_text receives "RANGE_OK"

    -- 2. Test: Generics & Structs (Codegen)
    declare Container[float[64bit]] named box on stack is 0
    box.value is 3.14159
    if box.value is greater than 3.0
        print_text receives "GENERIC_FLOAT_OK"
    end if

    -- 3. Test: Bitwise & Logic (Linker)
    declare integer[unsigned, 32bit] named b is 10 -- 1010
    declare integer[unsigned, 32bit] named res is 0
    res is bits of b and bits of 8
    if res is equal to 8
        print_text receives "BITWISE_LOGIC_OK"
    end if

    -- 4. Test: Enum & Match (Flow)
    declare Status named current is online
    match current
        when online
            print_text receives "MATCH_OK"
        when offline
            print_text receives "MATCH_FAIL"
        when error
            print_text receives "MATCH_FAIL"
    end match

    -- 5. Test: Ownership & Heap (Safety)
    declare pointer[to integer[signed, 32bit]] named ptr on heap is null
    allocate 4 bytes for ptr
    if ptr is not null
        value at ptr is 777
        if value at ptr is equal to 777
            print_text receives "HEAP_OWNERSHIP_OK"
        end if
        release ptr
    end if

    print_text receives "INTEGRATION_SUCCESS"
end body
end program
"""

def test_mega_compiler_full_cycle(tmp_path):
    source_file = tmp_path / "mega_test.cstar"
    source_file.write_text(MEGA_PROGRAM, encoding="utf-8")
    binary_path = tmp_path / "mega_test_bin"

    # Запуск всех стадий анализа и генерации IR
    result = compile_source(MEGA_PROGRAM, str(source_file), quiet=True)
    
    assert result.success is True, f"Compilation failed at stage {result.stage}"

    # Линковка через linker.py
    from compiler.scripts.linker import link
    link_res = link(result.ir, str(binary_path))
    
    assert link_res.success is True, f"Linking failed: {link_res.error}"

    # Выполнение бинарника
    run_res = subprocess.run([str(binary_path)], capture_output=True, text=True)
    output = run_res.stdout
    
    expected_markers = [
        "INTEGRATION_START",
        "RANGE_OK",
        "GENERIC_FLOAT_OK",
        "BITWISE_LOGIC_OK",
        "MATCH_OK",
        "HEAP_OWNERSHIP_OK",
        "INTEGRATION_SUCCESS"
    ]
    
    for marker in expected_markers:
        assert marker in output, f"Marker {marker} not found in output: {output}"
