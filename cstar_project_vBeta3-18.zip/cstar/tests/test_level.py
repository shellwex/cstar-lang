import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from src.parser import Parser
from src.level import LevelChecker, CFGBuilder


def parse(src):
    full = f"program Test\n{src}\nend program"
    return Parser(full).parse_program()

def violations(src):
    prog = parse(src)
    checker = LevelChecker()
    return checker.check_program(prog)

def violation_kinds(src):
    return [v.kind for v in violations(src)]

def no_violations(src):
    return violations(src) == []

def has_violation(src, kind):
    return any(v.kind == kind for v in violations(src))


# ── CFG building ──────────────────────────────────────────────────────────────

class TestCFG:
    def test_empty_function(self):
        prog = parse(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\nend body\nend function\nbody\nend body")
        builder = CFGBuilder()
        cfg = builder.build(prog.functions[0])
        assert cfg.func_name == "f"
        assert len(cfg.exits) >= 1

    def test_simple_sequence(self):
        prog = parse(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare integer[signed, 32bit] named x is 0\n"
            "declare integer[signed, 32bit] named y is 1\n"
            "end body\nend function\nbody\nend body")
        builder = CFGBuilder()
        cfg = builder.build(prog.functions[0])
        assert len(cfg.blocks) >= 2

    def test_if_creates_branches(self):
        prog = parse(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare boolean named flag is true\n"
            "if flag is equal to true\n"
            "declare integer[signed, 32bit] named x is 1\n"
            "end if\n"
            "end body\nend function\nbody\nend body")
        builder = CFGBuilder()
        cfg = builder.build(prog.functions[0])
        paths = cfg.all_paths()
        assert len(paths) >= 2   # then-path and skip-path

    def test_repeat_creates_loop(self):
        prog = parse(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare boolean named flag is true\n"
            "repeat while flag is equal to true\n"
            "flag is false\n"
            "end repeat\n"
            "end body\nend function\nbody\nend body")
        builder = CFGBuilder()
        cfg = builder.build(prog.functions[0])
        # Loop creates cond + body + after blocks
        assert len(cfg.blocks) >= 4

    def test_paths_found(self):
        prog = parse(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare boolean named a is true\n"
            "declare boolean named b is false\n"
            "if a is equal to true\n"
            "declare integer[signed, 32bit] named x is 1\n"
            "otherwise\n"
            "declare integer[signed, 32bit] named y is 2\n"
            "end otherwise\n"
            "end if\n"
            "end body\nend function\nbody\nend body")
        builder = CFGBuilder()
        cfg = builder.build(prog.functions[0])
        paths = cfg.all_paths()
        assert len(paths) >= 2


# ── Narrow point 1: Release ───────────────────────────────────────────────────

class TestRelease:
    def test_heap_var_released_ok(self):
        assert no_violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named buf on heap is 0\n"
            "release buf\n"
            "end body\nend function\nbody\nend body")

    def test_heap_var_not_released(self):
        assert has_violation(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named buf on heap is 0\n"
            "end body\nend function\nbody\nend body",
            "release")

    def test_stack_var_no_release_needed(self):
        assert no_violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare integer[signed, 32bit] named x on stack is 0\n"
            "end body\nend function\nbody\nend body")

    def test_release_on_all_paths_ok(self):
        # Both if and else release
        assert no_violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named buf on heap is 0\n"
            "declare boolean named flag is true\n"
            "if flag is equal to true\n"
            "release buf\n"
            "otherwise\n"
            "release buf\n"
            "end otherwise\n"
            "end if\n"
            "end body\nend function\nbody\nend body")

    def test_missing_release_on_error_path(self):
        # heap var not released before reject
        assert has_violation(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "on my_error\nreject with error[my_error]\n"
            "body\n"
            "declare byte named buf on heap is 0\n"
            "reject with error[my_error]\n"
            "release buf\n"
            "end body\nend function\nbody\nend body",
            "release")

    def test_release_before_reject_ok(self):
        assert no_violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "on my_error\nreject with error[my_error]\n"
            "body\n"
            "declare byte named buf on heap is 0\n"
            "release buf\n"
            "reject with error[my_error]\n"
            "end body\nend function\nbody\nend body")

    def test_two_heap_vars_both_released(self):
        assert no_violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named buf1 on heap is 0\n"
            "declare byte named buf2 on heap is 0\n"
            "release buf1\n"
            "release buf2\n"
            "end body\nend function\nbody\nend body")

    def test_two_heap_vars_one_missing(self):
        vlist = violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named buf1 on heap is 0\n"
            "declare byte named buf2 on heap is 0\n"
            "release buf1\n"
            "end body\nend function\nbody\nend body")
        assert any(v.kind == "release" and "buf2" in v.message for v in vlist)


# ── Narrow point 2: Null check ────────────────────────────────────────────────

class TestNullCheck:
    def test_null_checked_ok(self):
        assert no_violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare pointer[to byte] named ptr on stack is null\n"
            "if ptr is not null\n"
            "declare byte named val is value at ptr\n"
            "end if\n"
            "end body\nend function\nbody\nend body")

    def test_deref_without_null_check(self):
        assert has_violation(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare pointer[to byte] named ptr on stack is null\n"
            "declare byte named val is value at ptr\n"
            "end body\nend function\nbody\nend body",
            "null")


# ── Narrow point 3: Use after free ────────────────────────────────────────────

class TestUseAfterFree:
    def test_use_after_release(self):
        assert has_violation(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named buf on heap is 0\n"
            "release buf\n"
            "declare byte named x is buf\n"
            "end body\nend function\nbody\nend body",
            "owner")

    def test_no_use_after_release_ok(self):
        assert no_violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named buf on heap is 0\n"
            "release buf\n"
            "end body\nend function\nbody\nend body")


# ── Violation messages ────────────────────────────────────────────────────────

class TestMessages:
    def test_release_message_contains_var_name(self):
        vlist = violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named audio_buffer on heap is 0\n"
            "end body\nend function\nbody\nend body")
        assert any("audio_buffer" in v.message for v in vlist)

    def test_violation_has_hint(self):
        vlist = violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named buf on heap is 0\n"
            "end body\nend function\nbody\nend body")
        assert all(v.hint for v in vlist)

    def test_violation_str_format(self):
        vlist = violations(
            "function f\nreceives\nnothing\nreturns\nnothing\n"
            "body\n"
            "declare byte named buf on heap is 0\n"
            "end body\nend function\nbody\nend body")
        s = str(vlist[0])
        assert "LEVEL VIOLATION" in s
        assert "Why this is a problem" in s
        assert "How to fix" in s
