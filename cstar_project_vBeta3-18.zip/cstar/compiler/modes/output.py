"""
C* Compiler — Output Modes
Implements the three compiler output modes from Section 6.1:

    compiler mode silent   -- результат и ошибки только
    compiler mode normal   -- стадии и результат (по умолчанию)
    compiler mode verbose  -- всё включая внутренние решения
"""

from __future__ import annotations
from enum import Enum

SEP   = "━" * 56
TICK  = "✓"
CROSS = "✗"


class OutputMode(str, Enum):
    SILENT  = "silent"
    NORMAL  = "normal"
    VERBOSE = "verbose"


def make_printer(mode: OutputMode) -> "Printer":
    if mode == OutputMode.SILENT:
        return SilentPrinter()
    if mode == OutputMode.VERBOSE:
        return VerbosePrinter()
    return NormalPrinter()


# ── Base ──────────────────────────────────────────────────────────────────────

class Printer:
    """Base interface. All methods are no-ops by default."""

    def header(self, project: str, target: str):          pass
    def stage_ok(self, n: int, name: str, detail: str=""): pass
    def stage_fail(self, n: int, name: str):               pass
    def file_not_found(self, path: str):                   pass
    def summary_success(self, *, files, lines, output, elapsed): pass
    def summary_rejected(self, *, elapsed):                pass


# ── Silent ────────────────────────────────────────────────────────────────────

class SilentPrinter(Printer):
    """Prints only the final result line and errors — no stage chatter."""

    def file_not_found(self, path: str):
        print(f"{CROSS} File not found: {path}")

    def summary_success(self, *, files, lines, output, elapsed):
        print(f"{TICK} SUCCESS — {output}  ({elapsed:.2f}s)")

    def summary_rejected(self, *, elapsed):
        print(f"{CROSS} REJECTED  ({elapsed:.2f}s)")


# ── Normal ────────────────────────────────────────────────────────────────────

class NormalPrinter(Printer):
    """
    Shows each stage with ✓ / ✗ and a final summary block.
    Matches the 'normal mode' example in Section 6.1.
    """

    def header(self, project: str, target: str):
        print()
        print(f"C* Compiler v1.0")
        print(f"Compiling project: {project}")
        print(f"Target: {target}")
        print(SEP)
        print()

    def stage_ok(self, n: int, name: str, detail: str = ""):
        label = f"Stage {n} — {name}"
        line  = f"    {label:<44} {TICK}"
        print(line)
        if detail:
            print(f"    {detail}")

    def stage_fail(self, n: int, name: str):
        label = f"Stage {n} — {name}"
        print(f"    {label:<44} {CROSS}")

    def file_not_found(self, path: str):
        print(f"\n{CROSS} File not found: {path}\n")

    def summary_success(self, *, files, lines, output, elapsed):
        print()
        print(SEP)
        print(f"Result:  SUCCESS")
        print(f"Output:  {output}")
        print(f"Files:   {files}   Lines: {lines}")
        print(f"Time:    {elapsed:.2f} seconds")
        print(SEP)

    def summary_rejected(self, *, elapsed):
        print()
        print(SEP)
        print(f"Result:  REJECTED")
        print(f"Time:    {elapsed:.2f} seconds")
        print(SEP)


# ── Verbose ───────────────────────────────────────────────────────────────────

class VerbosePrinter(NormalPrinter):
    """
    Extends NormalPrinter with per-token counts, optimisation details,
    and machine-instruction mappings — all from Section 6.1 VERBOSE examples.
    """

    def stage_ok(self, n: int, name: str, detail: str = ""):
        label = f"Stage {n} — {name} [VERBOSE]"
        line  = f"    {label:<52} {TICK}"
        print(line)
        if detail:
            # indent each detail line
            for row in detail.splitlines():
                print(f"         {row}")

    def print_token_stats(self, tokens: list):
        """Call after Stage 1 to show token breakdown."""
        kw   = sum(1 for t in tokens if t.kind.name.startswith("KW_"))
        ids  = sum(1 for t in tokens if t.kind.name == "IDENTIFIER")
        lits = sum(1 for t in tokens if t.kind.name in
                   ("INTEGER_LIT", "FLOAT_LIT", "HEX_LIT",
                    "STRING_LIT",  "BOOL_LIT",  "NULL_LIT"))
        print(f"         Tokens:      {len(tokens)}")
        print(f"         Keywords:    {kw}")
        print(f"         Identifiers: {ids}")
        print(f"         Literals:    {lits}")

    def print_ast_stats(self, prog):
        """Call after Stage 2 to show AST counts."""
        funcs = len(getattr(prog, "functions",  []))
        types = len(getattr(prog, "type_defs",  []))
        print(f"         Functions: {funcs}   Types: {types}")

    def print_optimisation(self, kind: str, detail: str):
        """Call once per optimisation applied in Stage 5."""
        print(f"         {kind}: {detail}   {TICK}")

    def print_codegen_mapping(self, cstar_line: int, cstar_src: str, asm: list[str]):
        """Call per instruction in Stage 6 to show C* → machine mapping."""
        print(f"         line {cstar_line}: {cstar_src}")
        for instr in asm:
            print(f"             → {instr}")
        print(f"             {TICK}")
