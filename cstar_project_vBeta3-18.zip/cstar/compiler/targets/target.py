"""
C* Compiler — Compilation Targets
Defines supported target platforms for Stage 6 (Code Generation).

Each target describes:
    triple      — target triple string shown in compiler header
    arch        — processor architecture
    os          — operating system / environment
    pointer_bits — pointer width in bits (32 or 64)
    endian      — byte order ('little' or 'big')
    abi         — calling convention / ABI name

Per Section 6.1 the default target is automatically detected from the host
system, falling back to aarch64-android when detection fails.
"""

from __future__ import annotations
import platform
from dataclasses import dataclass


@dataclass(frozen=True)
class Target:
    triple:       str
    arch:         str
    os:           str
    pointer_bits: int
    endian:       str   # 'little' | 'big'
    abi:          str


# ── Supported targets ─────────────────────────────────────────────────────────

_TARGETS: dict[str, Target] = {
    # Android / Termux (primary development platform)
    "aarch64-android": Target(
        triple       = "aarch64-android",
        arch         = "aarch64",
        os           = "android",
        pointer_bits = 64,
        endian       = "little",
        abi          = "aapcs64",
    ),

    # Linux 64-bit (desktop / server)
    "x86-64-linux": Target(
        triple       = "x86-64 Linux",
        arch         = "x86_64",
        os           = "linux",
        pointer_bits = 64,
        endian       = "little",
        abi          = "sysv64",
    ),

    # Linux 32-bit (embedded)
    "x86-linux": Target(
        triple       = "x86 Linux",
        arch         = "x86",
        os           = "linux",
        pointer_bits = 32,
        endian       = "little",
        abi          = "cdecl",
    ),

    # ARM bare-metal (microcontrollers)
    "arm-none-eabi": Target(
        triple       = "arm-none-eabi",
        arch         = "arm",
        os           = "none",
        pointer_bits = 32,
        endian       = "little",
        abi          = "aapcs",
    ),

    # RISC-V 64-bit bare-metal
    "riscv64-none": Target(
        triple       = "riscv64-none",
        arch         = "riscv64",
        os           = "none",
        pointer_bits = 64,
        endian       = "little",
        abi          = "lp64",
    ),
}


def detect_host_target() -> str:
    """Auto-detect the host target triple based on machine and system."""
    machine = platform.machine().lower()
    system = platform.system().lower()

    if "aarch64" in machine:
        return "aarch64-android"
    if "x86_64" in machine or "amd64" in machine:
        return "x86-64-linux"
    # Fallback for Termux or unknown environments
    return "aarch64-android"


DEFAULT_TARGET = detect_host_target()


def get_target(name: str) -> Target:
    """
    Return the Target for *name*. Falls back to the default target and
    prints a warning when the name is not recognised.
    """
    normalised = name.lower().strip()
    if normalised in _TARGETS:
        return _TARGETS[normalised]

    print(
        f"  ⚠ Unknown target '{name}'. "
        f"Using default: {DEFAULT_TARGET}"
    )
    return _TARGETS[DEFAULT_TARGET]


def list_targets() -> list[str]:
    """Return all supported target triple strings."""
    return list(_TARGETS.keys())
