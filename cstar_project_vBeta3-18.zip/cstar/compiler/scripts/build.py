#!/usr/bin/env python3
"""
C* Compiler — Build Script
Orchestrates output for 7 compilation stages per Section 6.1.

Usage:
    python compiler/scripts/build.py <file.cstar>
    python compiler/scripts/build.py --mode verbose <file.cstar>
    python compiler/scripts/build.py --mode silent  <file.cstar>
    python compiler/scripts/build.py --target x86-64-linux <file.cstar>
"""

import sys
import os
import time
import argparse

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)

from cstarc import compile_source
from compiler.modes.output import OutputMode, make_printer
from compiler.targets.target import get_target
from compiler.scripts.linker import link

STAGE_NAMES = {
    1: "Lexical Analysis",
    2: "Syntax Analysis",
    3: "Type Checking",
    4: "Level Traversal",
    5: "Optimization",
    6: "Code Generation",
    7: "Linking",
}

# Map src.diagnostics.Stage → stage number
STAGE_NUMBER = {
    "LEXICAL": 1,
    "SYNTAX":  2,
    "TYPE":    3,
    "LEVEL":   4,
}


def parse_args():
    p = argparse.ArgumentParser(prog="cstar-build")
    p.add_argument("files", nargs="+", metavar="FILE")
    p.add_argument("--mode",   choices=["silent", "normal", "verbose"], default="normal")
    p.add_argument("--target", default="aarch64-android")
    p.add_argument("--output", "-o", default=None)
    p.add_argument("--emit-c", action="store_true",
                   help="Save generated C source next to the output binary")
    return p.parse_args()


def run():
    args   = parse_args()
    mode   = OutputMode(args.mode)
    target = get_target(args.target)
    pr     = make_printer(mode)

    project_name = os.path.splitext(os.path.basename(args.files[0]))[0]
    output_path  = args.output or os.path.join("build", project_name)

    pr.header(project_name, target.triple)

    total_start = time.time()

    for filepath in args.files:
        if not os.path.isfile(filepath):
            pr.file_not_found(filepath)
            sys.exit(1)

        with open(filepath, encoding="utf-8") as f:
            source = f.read()

        # compile_source handles all analysis; we suppress its own printing
        result = compile_source(
            source=source,
            filename=filepath,
            verbose=False,
            quiet=True,          # ← наш build.py управляет выводом
        )

        if result.success:
            # Stages 1-6 passed
            for n in range(1, 7):
                pr.stage_ok(n, STAGE_NAMES[n])

            # Stage 7 — real linking via gcc
            link_result = link(
                result.ir,
                output_path,
                emit_c=args.emit_c,
                verbose=(mode == OutputMode.VERBOSE),
            )
            if link_result.success:
                pr.stage_ok(7, STAGE_NAMES[7])
                if args.emit_c and link_result.c_source:
                    c_path = output_path + ".c"
                    with open(c_path, "w", encoding="utf-8") as f:
                        f.write(link_result.c_source)
                    if mode != OutputMode.SILENT:
                        print(f"\n    C source:  {c_path}")
            else:
                pr.stage_fail(7, STAGE_NAMES[7])
                if mode != OutputMode.SILENT:
                    print()
                    print(f"    Linker error: {link_result.error.strip()}")
                elapsed = time.time() - total_start
                pr.summary_rejected(elapsed=elapsed)
                sys.exit(1)
        else:
            # Print stages up to the failed one
            failed_at = 1
            if result.stage is not None:
                failed_at = STAGE_NUMBER.get(result.stage.name, 1)

            for n in range(1, failed_at):
                pr.stage_ok(n, STAGE_NAMES[n])
            pr.stage_fail(failed_at, STAGE_NAMES[failed_at])

            # Print the error diagnostics
            if mode != OutputMode.SILENT:
                print()
                result.print_all()

            elapsed = time.time() - total_start
            pr.summary_rejected(elapsed=elapsed)
            sys.exit(1)

    elapsed    = time.time() - total_start
    total_lines = 0
    for filepath in args.files:
        with open(filepath, encoding="utf-8") as f:
            total_lines += sum(1 for _ in f)

    pr.summary_success(
        files=len(args.files),
        lines=total_lines,
        output=output_path,
        elapsed=elapsed,
    )


if __name__ == "__main__":
    run()
