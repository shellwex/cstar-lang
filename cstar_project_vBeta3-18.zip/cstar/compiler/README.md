# compiler/

Эта папка содержит инфраструктуру компилятора C* —
скрипты запуска, определения платформ, режимы вывода и форматтер сообщений.

Реализована по **Разделу 6** спецификации C* Language Reference.

---

## Структура

```
compiler/
├── scripts/
│   └── build.py          — точка входа: запуск компиляции одного или нескольких файлов
│
├── modes/
│   └── output.py         — три режима вывода: silent / normal / verbose (Раздел 6.1)
│
├── targets/
│   └── target.py         — поддерживаемые платформы (aarch64-android и другие)
│
└── messages/
    ├── formatter.py      — форматтер сообщений компилятора (Раздел 6.3)
    └── summary.py        — итоговая сводка после компиляции (Раздел 6.3)
```

---

## Как запустить

```bash
# Скомпилировать один файл (режим normal по умолчанию)
python compiler/scripts/build.py examples/hello.cstar

# Verbose режим
python compiler/scripts/build.py --mode verbose examples/hello.cstar

# Silent режим — только результат
python compiler/scripts/build.py --mode silent examples/hello.cstar

# Указать платформу
python compiler/scripts/build.py --target x86-64-linux examples/hello.cstar

# Несколько файлов (проект)
python compiler/scripts/build.py --output build/MyProject src/main.cstar src/utils.cstar
```

---

## Поддерживаемые платформы

| Имя              | Архитектура | ОС       | Биты |
|------------------|-------------|----------|------|
| aarch64-android  | aarch64     | Android  | 64   |
| x86-64-linux     | x86_64      | Linux    | 64   |
| x86-linux        | x86         | Linux    | 32   |
| arm-none-eabi    | ARM         | bare     | 32   |
| riscv64-none     | RISC-V 64   | bare     | 64   |

По умолчанию: **aarch64-android** (Termux / Android — основная платформа разработки).

---

## Режимы вывода (Раздел 6.1)

### normal (по умолчанию)
```
C* Compiler v1.0
Compiling project: hello
Target: aarch64-android
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    Stage 1 — Lexical Analysis                             ✓
    Stage 2 — Syntax Analysis                              ✓
    Stage 3 — Type Checking                                ✓
    Stage 4 — Level Traversal                              ✓
    Stage 5 — Optimization                                 ✓
    Stage 6 — Code Generation                              ✓
    Stage 7 — Linking                                      ✓

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Result:  SUCCESS
Output:  build/hello
Time:    0.45 seconds
```

### silent
```
✓ SUCCESS — build/hello  (0.45s)
```

### verbose
Каждая стадия + подробная статистика токенов, AST, оптимизаций, и
соответствие инструкций C* машинным инструкциям (Раздел 6.1 VERBOSE).

---

## Формат сообщений об ошибках (Раздел 6.3)

Каждое сообщение отвечает на четыре вопроса:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SEVERITY — Kind
File: file.cstar
Line: N
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Что случилось:
    ...

Код с проблемой:
    <строка кода>
    ^

Почему это проблема:
    ...

Как исправить:
    ...

Правило: Раздел X.Y — ...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Четыре типа сообщений: `SYNTAX ERROR`, `TYPE ERROR`, `LEVEL VIOLATION`, `WARNING`.
