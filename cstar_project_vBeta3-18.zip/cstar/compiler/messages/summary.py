"""
C* Compiler — Compilation Summary
Prints the final summary block after all stages complete.

Format from Section 6.3:

    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    COMPILATION SUMMARY
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    Files processed:    N
    Lines of code:      N

    Syntax errors:      N
    Type errors:        N
    Level violations:   N
    Warnings:           N

    Optimizations:      N
        ...

    Result:  SUCCESS / REJECTED
    Output:  ./build/...
    Size:    N bytes
    Time:    N seconds
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

SEP = "━" * 56


@dataclass
class OptimisationRecord:
    kind:   str    # e.g. "Constant folding"
    detail: str    # e.g. "AudioEngine.cstar line 23: max_size multiply by 2 → 2048"


@dataclass
class WarningRecord:
    filename: str
    line:     int
    kind:     str


@dataclass
class SummaryData:
    files_processed:  int
    lines_of_code:    int
    syntax_errors:    int
    type_errors:      int
    level_violations: int
    warnings:         list[WarningRecord] = field(default_factory=list)
    optimisations:    list[OptimisationRecord] = field(default_factory=list)
    result_success:   bool   = True
    output_path:      Optional[str] = None
    output_size:      Optional[int] = None   # bytes
    elapsed:          float  = 0.0


def print_summary(data: SummaryData) -> None:
    print()
    print(SEP)
    print("COMPILATION SUMMARY")
    print(SEP)
    print()

    print(f"Files processed:    {data.files_processed}")
    print(f"Lines of code:      {data.lines_of_code}")
    print()
    print(f"Syntax errors:      {data.syntax_errors}")
    print(f"Type errors:        {data.type_errors}")
    print(f"Level violations:   {data.level_violations}")
    print(f"Warnings:           {len(data.warnings)}")

    if data.warnings:
        print()
        for w in data.warnings:
            print(f"    WARNING at {w.filename} line {w.line}")
            print(f"    {w.kind}")

    print()
    print(f"Optimizations:      {len(data.optimisations)}")

    if data.optimisations:
        # Group by kind
        by_kind: dict[str, list[str]] = {}
        for opt in data.optimisations:
            by_kind.setdefault(opt.kind, []).append(opt.detail)
        for kind, details in by_kind.items():
            print(f"    {kind}:")
            for d in details:
                print(f"        {d}")

    print()

    if data.result_success:
        print(f"Result:  SUCCESS" + (" with warnings" if data.warnings else ""))
        if data.output_path:
            print(f"Output:  {data.output_path}")
        if data.output_size is not None:
            print(f"Size:    {data.output_size:,} bytes")
    else:
        # Find the stage where it died
        print(f"Result:  REJECTED")

    print(f"Time:    {data.elapsed:.2f} seconds")
    print(SEP)
