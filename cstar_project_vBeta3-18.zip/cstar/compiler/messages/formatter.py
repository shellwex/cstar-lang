"""
C* Compiler — Message Formatter
Section 6.3 — Compiler Messages

Every message answers four questions:
    What happened?
    Where did it happen?  (file + line + source + ^)
    Why is it a problem?
    How to fix it?
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

SEP = "━" * 56


class Severity:
    SYNTAX  = "SYNTAX ERROR"
    TYPE    = "TYPE ERROR"
    LEVEL   = "LEVEL VIOLATION"
    BUILD   = "BUILD FAILED"
    WARNING = "WARNING"


@dataclass
class CompilerMessage:
    severity:      str
    kind:          str
    filename:      str
    line:          int
    col:           int = 0
    length:        int = 1
    what:          str = ""
    source_line:   str = ""
    why:           str = ""
    fix:           str = ""
    rule:          str = ""
    index:         Optional[str] = None
    # For cross-file violations (e.g. lifetime across module boundary)
    extra_file:    Optional[str] = None
    extra_line:    Optional[int] = None
    extra_code:    Optional[str] = None

    def render(self) -> str:
        parts: list[str] = []
        parts.append("")
        parts.append(SEP)

        # Header
        header = self.severity
        if self.index:
            header += f" [{self.index}]"
        header += f" — {self.kind}"
        parts.append(header)

        # Location
        loc = f"File: {self.filename}"
        if self.line:
            loc += f"   line {self.line}"
            if self.col:
                loc += f"  col {self.col}"
        parts.append(loc)
        parts.append(SEP)
        parts.append("")

        # Source line + caret
        if self.source_line:
            gutter = f"  {self.line} │ "
            parts.append(f"{gutter}{self.source_line}")
            pad   = " " * (len(gutter) + max(0, self.col - 1))
            squig = "^" + "~" * max(0, self.length - 1)
            parts.append(f"{pad}{squig}")
            parts.append("")

        # What happened
        if self.what:
            parts.append("What happened:")
            for row in self.what.strip().splitlines():
                parts.append(f"    {row.strip()}")
            parts.append("")

        # Extra file snippet
        if self.extra_file and self.extra_code:
            label = f"Related code in {self.extra_file}"
            if self.extra_line:
                label += f" line {self.extra_line}"
            parts.append(label + ":")
            parts.append(f"    {self.extra_code}")
            parts.append("")

        # Why
        if self.why:
            parts.append("Why this is a problem:")
            for row in self.why.strip().splitlines():
                parts.append(f"    {row.strip()}")
            parts.append("")

        # How to fix
        if self.fix:
            parts.append("How to fix:")
            for row in self.fix.strip().splitlines():
                parts.append(f"    {row.strip()}")
            parts.append("")

        # Rule
        if self.rule:
            parts.append(f"Rule: {self.rule}")

        parts.append(SEP)
        return "\n".join(parts)

    def __str__(self) -> str:
        return self.render()


# ── Pointer builder ───────────────────────────────────────────────────────────

def _caret(col: int, length: int = 1) -> str:
    return " " * max(0, col) + "^" + "~" * max(0, length - 1)


# ── Factory functions ─────────────────────────────────────────────────────────

def syntax_error(*, filename, line, col, found, expected,
                 source_line="", fix="", rule="") -> CompilerMessage:
    return CompilerMessage(
        severity    = Severity.SYNTAX,
        kind        = "Unexpected token",
        filename    = filename,
        line        = line,
        col         = col,
        source_line = source_line,
        what        = f'Found {found!r} where {expected!r} was expected.',
        why         = (f'The C* grammar requires {expected!r} at this position.\n'
                       f'{found!r} is not valid here.'),
        fix         = fix or f'Replace {found!r} with {expected!r}.',
        rule        = rule or "Section 1.7 — Blocks and Boundaries",
    )


def type_error(*, filename, line, col, from_type, to_type,
               source_line="", fix="", rule="",
               index=None) -> CompilerMessage:
    return CompilerMessage(
        severity    = Severity.TYPE,
        kind        = "Type mismatch",
        filename    = filename,
        line        = line,
        col         = col,
        index       = index,
        source_line = source_line,
        what        = f'Cannot use {from_type} where {to_type} is required.',
        why         = (f'C* does not allow implicit type conversion.\n'
                       f'{from_type} may contain values that do not fit in {to_type}.\n'
                       f'Data loss must be handled explicitly.'),
        fix         = fix or f"Use 'convert <value> to {to_type}' with 'on overflow' handler.",
        rule        = rule or "Section 1.5 — Types",
    )


def level_violation(*, filename, line, col, kind, what, source_line="",
                    why, fix, rule, index=None,
                    extra_file=None, extra_line=None,
                    extra_code=None) -> CompilerMessage:
    return CompilerMessage(
        severity    = Severity.LEVEL,
        kind        = kind,
        filename    = filename,
        line        = line,
        col         = col,
        index       = index,
        source_line = source_line,
        what        = what,
        why         = why,
        fix         = fix,
        rule        = rule,
        extra_file  = extra_file,
        extra_line  = extra_line,
        extra_code  = extra_code,
    )


def ownership_error(*, filename, line, col, var_name, mode,
                    source_line="", fix="") -> CompilerMessage:
    return CompilerMessage(
        severity    = Severity.TYPE,
        kind        = "Ownership violation",
        filename    = filename,
        line        = line,
        col         = col,
        source_line = source_line,
        what        = f"'{var_name}' was already transferred with 'as owner' and no longer exists.",
        why         = ("After transferring ownership with 'as owner', the original\n"
                       "variable is no longer valid. It has no owner and cannot be read,\n"
                       "written, or transferred again."),
        fix         = fix or f"Remove the second use of '{var_name}', or restructure so\nonly one owner exists at a time.",
        rule        = "Section 2.3 — Ownership",
    )


def warning(*, filename, line, col, kind, what,
            source_line="", why="", fix="", rule="") -> CompilerMessage:
    return CompilerMessage(
        severity    = Severity.WARNING,
        kind        = kind,
        filename    = filename,
        line        = line,
        col         = col,
        source_line = source_line,
        what        = what,
        why         = why,
        fix         = fix,
        rule        = rule,
    )
