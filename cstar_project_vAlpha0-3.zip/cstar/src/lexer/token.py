"""
C* Compiler — Token definitions
Based on C* Language Reference, Section 1.1–1.2
"""

from enum import Enum, auto
from dataclasses import dataclass
from typing import Optional


class TokenKind(Enum):
    # ── Literals ────────────────────────────────────────────────
    INTEGER_LIT   = auto()   # 42, 0, 255
    FLOAT_LIT     = auto()   # 3.14, 0.0
    HEX_LIT       = auto()   # 0xB8000
    STRING_LIT    = auto()   # "hello"
    BOOL_LIT      = auto()   # true / false
    NULL_LIT      = auto()   # null

    # ── Type keywords ────────────────────────────────────────────
    KW_INTEGER    = auto()   # integer
    KW_FLOAT      = auto()   # float
    KW_BYTE       = auto()   # byte
    KW_BOOLEAN    = auto()   # boolean
    KW_TEXT       = auto()   # text
    KW_POINTER    = auto()   # pointer
    KW_ADDRESS    = auto()   # address
    KW_NOTHING    = auto()   # nothing
    KW_ARRAY      = auto()   # array

    # ── Type property keywords ───────────────────────────────────
    KW_SIGNED     = auto()   # signed
    KW_UNSIGNED   = auto()   # unsigned
    KW_8BIT       = auto()   # 8bit
    KW_16BIT      = auto()   # 16bit
    KW_32BIT      = auto()   # 32bit
    KW_64BIT      = auto()   # 64bit
    KW_TO         = auto()   # to  (pointer[to ...])
    KW_BITS       = auto()   # bits

    # ── Structure keywords ───────────────────────────────────────
    KW_FUNCTION   = auto()   # function
    KW_END        = auto()   # end
    KW_MODULE     = auto()   # module
    KW_PROGRAM    = auto()   # program
    KW_BODY       = auto()   # body
    KW_RETURNS    = auto()   # returns
    KW_RECEIVES   = auto()   # receives

    # ── Variable keywords ────────────────────────────────────────
    KW_DECLARE    = auto()   # declare
    KW_NAMED      = auto()   # named
    KW_IS         = auto()   # is
    KW_AS         = auto()   # as
    KW_CONSTANT   = auto()   # constant
    KW_CONVERT    = auto()   # convert

    # ── Comparison (multi-word tokens) ───────────────────────────
    KW_IS_EQUAL_TO        = auto()   # is equal to
    KW_IS_NOT_EQUAL_TO    = auto()   # is not equal to
    KW_IS_GREATER_THAN    = auto()   # is greater than
    KW_IS_LESS_THAN       = auto()   # is less than
    KW_IS_GREATER_OR_EQUAL = auto()  # is greater or equal
    KW_IS_LESS_OR_EQUAL   = auto()   # is less or equal
    KW_IS_NOT_NULL        = auto()   # is not null
    KW_IS_NULL            = auto()   # is null (== null check)

    # ── Arithmetic keywords ──────────────────────────────────────
    KW_PLUS       = auto()   # plus
    KW_MINUS      = auto()   # minus
    KW_MULTIPLY   = auto()   # multiply
    KW_BY         = auto()   # by  (multiply by)
    KW_DIVIDE     = auto()   # divide
    KW_REMAINDER  = auto()   # remainder
    KW_SHIFTED    = auto()   # shifted

    # ── Logic keywords ───────────────────────────────────────────
    KW_AND        = auto()   # and
    KW_OR         = auto()   # or
    KW_NOT        = auto()   # not
    KW_XOR        = auto()   # xor

    # ── Control flow ─────────────────────────────────────────────
    KW_IF         = auto()   # if
    KW_OTHERWISE  = auto()   # otherwise
    KW_REPEAT     = auto()   # repeat
    KW_WHILE      = auto()   # while
    KW_STOP       = auto()   # stop
    KW_SKIP       = auto()   # skip
    KW_RETURN     = auto()   # return
    KW_LOOP       = auto()   # loop

    # ── Memory keywords ──────────────────────────────────────────
    KW_ALLOCATE   = auto()   # allocate
    KW_RELEASE    = auto()   # release
    KW_TRANSFER   = auto()   # transfer
    KW_COPY       = auto()   # copy
    KW_ADDRESS_OF = auto()   # address of  (multi-word)
    KW_VALUE_AT   = auto()   # value at    (multi-word)
    KW_OF         = auto()   # of
    KW_AT         = auto()   # at
    KW_ON         = auto()   # on
    KW_STACK      = auto()   # stack
    KW_HEAP       = auto()   # heap
    KW_SIZE       = auto()   # size
    KW_OWNER      = auto()   # owner
    KW_ACCESS     = auto()   # access
    KW_NULL       = auto()   # null (keyword sense)

    # ── Error handling ───────────────────────────────────────────
    KW_REJECT     = auto()   # reject
    KW_WITH       = auto()   # with
    KW_ERROR      = auto()   # error
    KW_HANDLE     = auto()   # handle
    KW_RECOVER    = auto()   # recover
    KW_OVERFLOW   = auto()   # overflow
    KW_SUCCESS    = auto()   # success

    # ── Module / type definition ─────────────────────────────────
    KW_USES       = auto()   # uses
    KW_MEMORY     = auto()   # memory
    KW_DEFINE     = auto()   # define
    KW_TYPE       = auto()   # type
    KW_RULE       = auto()   # rule
    KW_GATEWAY    = auto()   # gateway
    KW_STEP       = auto()   # step
    KW_CONTAINS   = auto()   # contains
    KW_ALIGNMENT  = auto()   # alignment
    KW_BYTES      = auto()   # bytes
    KW_CAN_BE     = auto()   # can be (multi-word)
    KW_END_CAN_BE = auto()   # end can be (multi-word)
    KW_PRIVATE    = auto()   # private
    KW_PUBLIC     = auto()   # public
    KW_INTERNAL   = auto()   # internal
    KW_DEPENDS    = auto()   # depends
    KW_VERSION    = auto()   # version
    KW_CALL       = auto()   # call
    KW_WITH_ARG   = auto()   # with (call arg context — same token, context differs)
    KW_NAMED_ARG  = auto()   # named (reused for call args too)
    KW_OPERATIONS = auto()   # operations
    KW_OPERATION  = auto()   # operation

    # ── Validation / range ─────────────────────────────────────
    KW_VALID      = auto()   # valid
    KW_RANGE      = auto()   # range
    KW_FROM       = auto()   # from

    # ── Type-qualifier misc ──────────────────────────────────────
    KW_EQUAL      = auto()   # equal
    KW_GREATER    = auto()   # greater
    KW_LESS       = auto()   # less

    # ── Size-of ──────────────────────────────────────────────────
    KW_SIZE_OF    = auto()   # size of (multi-word)

    # ── Punctuation ──────────────────────────────────────────────
    LBRACKET      = auto()   # [
    RBRACKET      = auto()   # ]
    LPAREN        = auto()   # (
    RPAREN        = auto()   # )
    COMMA         = auto()   # ,
    COLON         = auto()   # :
    DOT           = auto()   # .
    UNDERSCORE    = auto()   # _  (should only appear inside identifiers)

    # ── Comments ─────────────────────────────────────────────────
    COMMENT_LINE  = auto()   # -- ...
    COMMENT_BLOCK = auto()   # --[ ... ]--

    # ── Identifier ───────────────────────────────────────────────
    IDENTIFIER    = auto()   # user-defined names: audio_buffer, etc.

    # ── Special ──────────────────────────────────────────────────
    NEWLINE       = auto()   # significant for "one statement per line"
    EOF           = auto()


# Map single-word strings → TokenKind
# Multi-word compound tokens are resolved in the lexer after lookahead.
KEYWORDS: dict[str, TokenKind] = {
    # Structure
    "function":  TokenKind.KW_FUNCTION,
    "end":       TokenKind.KW_END,
    "module":    TokenKind.KW_MODULE,
    "program":   TokenKind.KW_PROGRAM,
    "body":      TokenKind.KW_BODY,
    "returns":   TokenKind.KW_RETURNS,
    "receives":  TokenKind.KW_RECEIVES,
    # Variables
    "declare":   TokenKind.KW_DECLARE,
    "named":     TokenKind.KW_NAMED,
    "is":        TokenKind.KW_IS,          # may start compound token
    "as":        TokenKind.KW_AS,
    "constant":  TokenKind.KW_CONSTANT,
    "convert":   TokenKind.KW_CONVERT,
    # Types
    "integer":   TokenKind.KW_INTEGER,
    "float":     TokenKind.KW_FLOAT,
    "byte":      TokenKind.KW_BYTE,
    "boolean":   TokenKind.KW_BOOLEAN,
    "text":      TokenKind.KW_TEXT,
    "pointer":   TokenKind.KW_POINTER,
    "address":   TokenKind.KW_ADDRESS,
    "nothing":   TokenKind.KW_NOTHING,
    "array":     TokenKind.KW_ARRAY,
    # Type properties
    "signed":    TokenKind.KW_SIGNED,
    "unsigned":  TokenKind.KW_UNSIGNED,
    "8bit":      TokenKind.KW_8BIT,
    "16bit":     TokenKind.KW_16BIT,
    "32bit":     TokenKind.KW_32BIT,
    "64bit":     TokenKind.KW_64BIT,
    "to":        TokenKind.KW_TO,
    "bits":      TokenKind.KW_BITS,
    # Arithmetic
    "plus":      TokenKind.KW_PLUS,
    "minus":     TokenKind.KW_MINUS,
    "multiply":  TokenKind.KW_MULTIPLY,
    "by":        TokenKind.KW_BY,
    "divide":    TokenKind.KW_DIVIDE,
    "remainder": TokenKind.KW_REMAINDER,
    "shifted":   TokenKind.KW_SHIFTED,
    # Logic
    "and":       TokenKind.KW_AND,
    "or":        TokenKind.KW_OR,
    "not":       TokenKind.KW_NOT,
    "xor":       TokenKind.KW_XOR,
    # Control flow
    "if":        TokenKind.KW_IF,
    "otherwise": TokenKind.KW_OTHERWISE,
    "repeat":    TokenKind.KW_REPEAT,
    "while":     TokenKind.KW_WHILE,
    "stop":      TokenKind.KW_STOP,
    "skip":      TokenKind.KW_SKIP,
    "return":    TokenKind.KW_RETURN,
    "loop":      TokenKind.KW_LOOP,
    # Memory
    "allocate":  TokenKind.KW_ALLOCATE,
    "release":   TokenKind.KW_RELEASE,
    "transfer":  TokenKind.KW_TRANSFER,
    "copy":      TokenKind.KW_COPY,
    "of":        TokenKind.KW_OF,
    "at":        TokenKind.KW_AT,
    "on":        TokenKind.KW_ON,
    "stack":     TokenKind.KW_STACK,
    "heap":      TokenKind.KW_HEAP,
    "size":      TokenKind.KW_SIZE,
    "owner":     TokenKind.KW_OWNER,
    "access":    TokenKind.KW_ACCESS,
    "value":     TokenKind.KW_VALUE_AT,    # starts "value at"
    "null":      TokenKind.NULL_LIT,
    # Error handling
    "reject":    TokenKind.KW_REJECT,
    "with":      TokenKind.KW_WITH,
    "error":     TokenKind.KW_ERROR,
    "handle":    TokenKind.KW_HANDLE,
    "recover":   TokenKind.KW_RECOVER,
    "overflow":  TokenKind.KW_OVERFLOW,
    "success":   TokenKind.KW_SUCCESS,
    # Module / type
    "uses":      TokenKind.KW_USES,
    "memory":    TokenKind.KW_MEMORY,
    "define":    TokenKind.KW_DEFINE,
    "type":      TokenKind.KW_TYPE,
    "rule":      TokenKind.KW_RULE,
    "gateway":   TokenKind.KW_GATEWAY,
    "step":      TokenKind.KW_STEP,
    "contains":  TokenKind.KW_CONTAINS,
    "alignment": TokenKind.KW_ALIGNMENT,
    "bytes":     TokenKind.KW_BYTES,
    "private":   TokenKind.KW_PRIVATE,
    "public":    TokenKind.KW_PUBLIC,
    "internal":  TokenKind.KW_INTERNAL,
    "depends":   TokenKind.KW_DEPENDS,
    "version":   TokenKind.KW_VERSION,
    "call":      TokenKind.KW_CALL,
    "operations": TokenKind.KW_OPERATIONS,
    "operation":  TokenKind.KW_OPERATION,
    # Validation / range
    "valid":     TokenKind.KW_VALID,
    "range":     TokenKind.KW_RANGE,
    "from":      TokenKind.KW_FROM,
    # Type-qualifier misc
    "equal":     TokenKind.KW_EQUAL,
    "greater":   TokenKind.KW_GREATER,
    "less":      TokenKind.KW_LESS,
    "can":       TokenKind.KW_CAN_BE,      # starts "can be"
    # Literals
    "true":      TokenKind.BOOL_LIT,
    "false":     TokenKind.BOOL_LIT,
}

# Bit-size suffixes that follow digits directly (e.g. "32bit")
BIT_SIZES = {"8bit", "16bit", "32bit", "64bit"}


@dataclass(frozen=True)
class Span:
    """Source location: line and column (1-based)."""
    line: int
    col: int
    length: int = 1

    def __str__(self) -> str:
        return f"{self.line}:{self.col}"


@dataclass
class Token:
    kind: TokenKind
    value: str          # raw source text of the token
    span: Span

    def __repr__(self) -> str:
        return f"Token({self.kind.name}, {self.value!r}, {self.span})"
