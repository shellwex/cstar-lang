#!/usr/bin/env python3
"""
cstarc — C* Compiler
7 stages per Section 6 of C* Language Reference.
Error messages per Section 6.3 — Compiler Messages.
"""

import sys
import os
import argparse
import subprocess
import time

sys.path.insert(0, os.path.dirname(__file__))

from src.lexer      import Lexer, LexError
from src.parser     import Parser, ParseError
from src.sema       import Analyzer
from src.level      import LevelChecker
from src.codegen    import Codegen
from src.diagnostics import (
    Diagnostic, DiagnosticBuilder, CompilationResult,
    Stage, Severity,
    from_lex_error, from_parse_error,
    from_sema_diagnostic, from_level_violation,
)

SEP   = "━" * 56
TICK  = "✓"
CROSS = "✗"


def stage_line(n: int, name: str, status: str = "") -> str:
    label = f"Stage {n} — {name}"
    return f"    {label:<44} {status}"


def compile_source(
    source:   str,
    filename: str  = "<input>",
    verbose:  bool = False,
    quiet:    bool = False,
) -> CompilationResult:

    diags: list[Diagnostic] = []
    fname = os.path.basename(filename)

    if not quiet:
        print(f"\nC* Compiler")
        print(f"Compiling: {fname}")
        print(f"Target:    aarch64-android")
        print(SEP)

    t_total = time.time()
    builder = DiagnosticBuilder(source, fname)

    # ── Stage 1 — Lexical Analysis ────────────────────────────────────────────
    t = time.time()
    try:
        tokens = list(Lexer(source, filename).tokenise())
    except LexError as exc:
        d = from_lex_error(exc, source, fname)
        diags.append(d)
        result = CompilationResult(success=False, stage=Stage.LEXICAL, diagnostics=diags)
        if not quiet:
            print(stage_line(1, "Lexical Analysis", CROSS))
            print()
            result.print_all()
        return result

    if not quiet:
        if verbose:
            kw  = sum(1 for t in tokens if t.kind.name.startswith("KW_"))
            ids = sum(1 for t in tokens if t.kind.name == "IDENTIFIER")
            lit = sum(1 for t in tokens if t.kind.name in
                      ("INTEGER_LIT","FLOAT_LIT","HEX_LIT","STRING_LIT","BOOL_LIT","NULL_LIT"))
            print(stage_line(1, "Lexical Analysis", TICK))
            print(f"         Tokens: {len(tokens)}  Keywords: {kw}  Identifiers: {ids}  Literals: {lit}")
            print(f"         Time: {time.time()-t:.3f}s")
        else:
            print(stage_line(1, "Lexical Analysis", TICK))

    # ── Stage 2 — Syntax Analysis ─────────────────────────────────────────────
    t = time.time()
    try:
        prog = Parser(source, filename).parse_any()
    except ParseError as exc:
        d = from_parse_error(exc, source, fname)
        diags.append(d)
        result = CompilationResult(success=False, stage=Stage.SYNTAX, diagnostics=diags)
        if not quiet:
            print(stage_line(2, "Syntax Analysis", CROSS))
            print()
            result.print_all()
        return result

    if not quiet:
        if verbose:
            print(stage_line(2, "Syntax Analysis", TICK))
            print(f"         Functions: {len(prog.functions)}  Types: {len(prog.type_defs)}")
            print(f"         Time: {time.time()-t:.3f}s")
        else:
            print(stage_line(2, "Syntax Analysis", TICK))

    # ── Stage 3 — Type Checking ───────────────────────────────────────────────
    t = time.time()
    analyzer     = Analyzer()
    sema_diags   = analyzer.analyze_program(prog)
    sema_errors  = [d for d in sema_diags if d.kind == "error"]
    sema_warns   = [d for d in sema_diags if d.kind == "warning"]

    for sd in sema_warns:
        diags.append(from_sema_diagnostic(sd, source, fname))
    for sd in sema_errors:
        diags.append(from_sema_diagnostic(sd, source, fname))

    if sema_errors:
        result = CompilationResult(success=False, stage=Stage.TYPE, diagnostics=diags)
        if not quiet:
            print(stage_line(3, "Type Checking", CROSS))
            print()
            result.print_all()
        return result

    if not quiet:
        if verbose:
            print(stage_line(3, "Type Checking", TICK))
            print(f"         Time: {time.time()-t:.3f}s")
        else:
            print(stage_line(3, "Type Checking", TICK))

    # ── Stage 4 — Level Traversal ─────────────────────────────────────────────
    t = time.time()
    checker    = LevelChecker()
    violations = checker.check_program(prog)

    for v in violations:
        diags.append(from_level_violation(v, source, fname))

    if violations:
        result = CompilationResult(success=False, stage=Stage.LEVEL, diagnostics=diags)
        if not quiet:
            print(stage_line(4, "Level Traversal", CROSS))
            print()
            result.print_all()
        return result

    if not quiet:
        if verbose:
            print(stage_line(4, "Level Traversal", TICK))
            print(f"         All paths valid — 4 narrow points passed")
            print(f"         Time: {time.time()-t:.3f}s")
        else:
            print(stage_line(4, "Level Traversal", TICK))

    # ── Stage 5 — Optimization ────────────────────────────────────────────────
    t = time.time()
    # Phase 1: placeholder
    if not quiet:
        if verbose:
            print(stage_line(5, "Optimization", TICK))
            print(f"         0 optimizations applied")
            print(f"         Time: {time.time()-t:.3f}s")
        else:
            print(stage_line(5, "Optimization", TICK))

    # ── Stage 6 — Code Generation ─────────────────────────────────────────────
    t = time.time()
    cg = Codegen()
    ir = cg.generate_program(prog)

    if not quiet:
        if verbose:
            print(stage_line(6, "Code Generation", TICK))
            print(f"         IR lines: {len(ir.splitlines())}")
            print(f"         Time: {time.time()-t:.3f}s")
        else:
            print(stage_line(6, "Code Generation", TICK))

    # ── Stage 7 — Linking ─────────────────────────────────────────────────────
    if not quiet:
        print(stage_line(7, "Linking", TICK))

    elapsed = time.time() - t_total
    if not quiet:
        print(SEP)
        print(f"Result:  SUCCESS")
        print(f"Time:    {elapsed:.2f} seconds")
        print(SEP)

    return CompilationResult(success=True, stage=None, diagnostics=diags, ir=ir)


def main() -> None:
    ap = argparse.ArgumentParser(
        description="cstarc — C* Compiler",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cstarc.py program.cstar           Compile to binary
  python cstarc.py program.cstar --run     Compile and run
  python cstarc.py program.cstar --emit-ir Show LLVM IR
  python cstarc.py program.cstar --verbose Show all 7 stages in detail
  python cstarc.py a.cstar b.cstar -o prog Compile multiple files
        """,
    )
    ap.add_argument("source", nargs='+', help="Source file(s) (.cstar)")
    ap.add_argument("-o",           dest="output", default=None)
    ap.add_argument("--emit-ir",    action="store_true")
    ap.add_argument("--run",        action="store_true")
    ap.add_argument("--verbose",    action="store_true")
    ap.add_argument("--quiet",      action="store_true")
    args = ap.parse_args()

    # Проверка существования всех файлов
    for src in args.source:
        if not os.path.exists(src):
            print(f"cstarc: file not found: {src}", file=sys.stderr)
            sys.exit(1)

    # --run пока работает только с одним файлом
    if args.run and len(args.source) > 1:
        print("cstarc: --run supports only one source file", file=sys.stderr)
        sys.exit(1)

    # Компиляция каждого исходного файла
    results = []
    for src in args.source:
        with open(src, "r") as f:
            source = f.read()
        result = compile_source(source, src,
                                verbose=args.verbose,
                                quiet=args.quiet)
        if not result.success:
            sys.exit(1)
        results.append((src, result))

    # --emit-ir выводит IR всех файлов и завершается
    if args.emit_ir:
        for src, result in results:
            print(f"; IR for {src}")
            print(result.ir)
        return

    # Запись .ll для каждого модуля (для сборки, но не для --run)
    if not args.run:
        for src, result in results:
            base = os.path.splitext(src)[0]
            ll_file = base + ".ll"
            with open(ll_file, "w") as f:
                f.write(result.ir)
            if not args.quiet:
                print(f"IR written to {ll_file}")

    if args.run:
        from compiler.scripts.linker import link
        # Берём результат единственного исходного файла
        run_result = results[0][1]
        # Генерируем временное имя для бинарника
        binary_name = "./temp_cstar_app"
        
        # Печатаем статус для пользователя
        if not args.quiet:
            print("Транспиляция и запуск...")
            
        link_res = link(run_result.ir, binary_name)
        if link_res.success:
            subprocess.run([binary_name])
            if os.path.exists(binary_name):
                os.remove(binary_name)
        else:
            print(f"Ошибка линковки: {link_res.error}")
        return

    # Обычная сборка (без --run): компиляция .ll -> .o и линковка
    obj_files = []
    for src, _ in results:
        base = os.path.splitext(src)[0]
        ll_file = base + ".ll"
        obj_file = base + ".o"
        r = subprocess.run(["llc", "-filetype=obj", ll_file, "-o", obj_file],
                           capture_output=True)
        if r.returncode != 0:
            print("llc failed:", r.stderr.decode(), file=sys.stderr)
            sys.exit(1)
        obj_files.append(obj_file)

    out_file = args.output or os.path.splitext(args.source[0])[0]
    for linker in ["clang", "cc", "gcc"]:
        r = subprocess.run([linker] + obj_files + ["-o", out_file],
                           capture_output=True)
        if r.returncode == 0:
            if not args.quiet:
                print(f"Binary: {out_file}")
            break
    else:
        print("Linking failed — no suitable linker", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
