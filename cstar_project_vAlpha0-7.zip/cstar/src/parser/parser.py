"""
C* Compiler — Parser
Converts a flat token stream into an AST.

Design:
• Recursive-descent, one method per grammar rule.
• Skips NEWLINE and COMMENT tokens transparently.
• Raises ParseError with line:col and a human-readable message.
"""

from __future__ import annotations
from typing import Optional

from ..lexer.token import Token, TokenKind, Span
from ..lexer.lexer import Lexer
from . import ast as A
from .ast import OwnershipMode


# ── Error ─────────────────────────────────────────────────────────────────────

class ParseError(Exception):
    def __init__(self, message: str, span: Span) -> None:
        super().__init__(f"[{span}] PARSE ERROR: {message}")
        self.span = span


# ── Token stream ──────────────────────────────────────────────────────────────

_SKIP = {TokenKind.NEWLINE, TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK}

class TokenStream:
    def __init__(self, tokens: list[Token]) -> None:
        self._tokens = [t for t in tokens if t.kind not in _SKIP]
        self._pos = 0

    def peek(self, offset: int = 0) -> Token:
        idx = self._pos + offset
        if idx < len(self._tokens):
            return self._tokens[idx]
        return self._tokens[-1]   # EOF

    def advance(self) -> Token:
        tok = self._tokens[self._pos]
        if self._pos < len(self._tokens) - 1:
            self._pos += 1
        return tok

    def check(self, *kinds: TokenKind) -> bool:
        return self.peek().kind in kinds

    def match(self, *kinds: TokenKind) -> Optional[Token]:
        if self.peek().kind in kinds:
            return self.advance()
        return None

    SOFT_KEYWORDS = {
        "value", "size", "access", "step", "copy", "owner",
        "address", "result", "count", "index", "length",
        "width", "height", "depth", "level", "version",
        "type", "name", "data", "state", "mode", "flag",
        "offset", "limit", "min", "max", "total",
    }

    def expect(self, kind: TokenKind, msg: str = "") -> Token:
        tok = self.peek()
        if tok.kind != kind:
            if kind == TokenKind.IDENTIFIER and tok.value in self.SOFT_KEYWORDS:
                return self.advance()
            label = msg or kind.name
            raise ParseError(
                f"Expected {label} but got {tok.value!r}", tok.span)
        return self.advance()

    def expect_value(self, value: str) -> Token:
        tok = self.peek()
        if tok.value != value:
            raise ParseError(
                f"Expected {value!r} but got {tok.value!r}", tok.span)
        return self.advance()

    @property
    def span(self) -> Span:
        return self.peek().span


# ── Parser ────────────────────────────────────────────────────────────────────

class Parser:
    def __init__(self, source: str, filename: str = "<input>") -> None:
        tokens = list(Lexer(source, filename).tokenise())
        self._ts = TokenStream(tokens)

    # ── Entry points ──────────────────────────────────────────────────────────

    def parse_any(self) -> A.Node:
        """Flexible entry point: determines whether source is program or module."""
        tok = self._ts.peek()
        if tok.kind == TokenKind.KW_PROGRAM:
            return self.parse_program()
        if tok.kind == TokenKind.KW_MODULE:
            return self.parse_module()
        raise ParseError(
            f"File must start with 'program' or 'module', got {tok.value!r}",
            tok.span)

    def parse_program(self) -> A.ProgramDef:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_PROGRAM, "program")
        name = self._ts.expect(TokenKind.IDENTIFIER, "program name").value
        functions, type_defs, body, interrupt_handlers, hw_regs = self._parse_top_level_body("program")
        return A.ProgramDef(span=span, name=name,
                            functions=functions, type_defs=type_defs, body=body,
                            interrupt_handlers=interrupt_handlers,
                            hardware_registers=hw_regs)

    def parse_module(self) -> A.ModuleDef:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_MODULE, "module")
        name = self._ts.expect(TokenKind.IDENTIFIER, "module name").value
        functions, type_defs, body, interrupt_handlers, hw_regs = self._parse_top_level_body("module")
        return A.ModuleDef(span=span, name=name,
                           functions=functions, type_defs=type_defs, body=body,
                           interrupt_handlers=interrupt_handlers,
                           hardware_registers=hw_regs)

    # ── Top-level body (program / module) ────────────────────────────────────

    def _parse_top_level_body(self, keyword: str):
        functions: list[A.FunctionDef] = []
        type_defs: list = []
        body: list[A.StmtNode] = []
        interrupt_handlers: list[A.InterruptHandlerDef] = []
        hw_regs: list[A.HardwareRegisterDef] = []

        # --- Parse optional module header (version / depends) ---
        while self._ts.check(TokenKind.KW_VERSION, TokenKind.KW_DEPENDS):
            if self._ts.match(TokenKind.KW_VERSION):
                self._ts.expect(TokenKind.LBRACKET, "[")
                self._ts.advance()
                self._ts.expect(TokenKind.RBRACKET, "]")
            if self._ts.match(TokenKind.KW_DEPENDS):
                self._ts.expect(TokenKind.KW_ON, "on")
                self._ts.expect(TokenKind.KW_MODULE, "module")
                self._ts.expect(TokenKind.LBRACKET, "[")
                self._ts.expect(TokenKind.IDENTIFIER, "module name")
                self._ts.expect(TokenKind.RBRACKET, "]")

        # --- Main body ---
        while not self._ts.check(TokenKind.EOF):
            tok = self._ts.peek()

            # end program / end module
            if tok.kind == TokenKind.KW_END and self._ts.peek(1).value == keyword:
                self._ts.advance()  # 'end'
                self._ts.advance()  # keyword
                break

            # visibility prefix (default private)
            visibility = "private"
            if tok.kind in (TokenKind.KW_PUBLIC, TokenKind.KW_PRIVATE, TokenKind.KW_INTERNAL):
                visibility = tok.value
                self._ts.advance()
                tok = self._ts.peek()

            # Interrupt handler: `declare interrupt handler named ...`
            if tok.kind == TokenKind.KW_DECLARE and self._ts.peek(1).kind == TokenKind.KW_INTERRUPT:
                self._ts.advance()  # consume 'declare'
                interrupt_handlers.append(self._parse_interrupt_handler())
            # Hardware register: `declare hardware register ...`
            elif tok.kind == TokenKind.KW_DECLARE and self._ts.peek(1).kind == TokenKind.KW_HARDWARE:
                self._ts.advance()  # consume 'declare'
                hw_regs.append(self._parse_hardware_register())
            elif tok.kind == TokenKind.KW_FUNCTION:
                functions.append(self._parse_function(visibility))
            elif tok.kind == TokenKind.KW_DEFINE:
                type_defs.append(self._parse_type_def())
            elif tok.kind == TokenKind.KW_BODY:
                body = self._parse_body_block()
            else:
                body.append(self._parse_statement())

        return functions, type_defs, body, interrupt_handlers, hw_regs

    # ── Function ─────────────────────────────────────────────────────────────

    def _parse_function(self, visibility: str = "private") -> A.FunctionDef:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_FUNCTION, "function")
        name = self._ts.expect(TokenKind.IDENTIFIER, "function name").value

        params = self._parse_receives()
        return_type, return_name = self._parse_returns()
        stops_when = self._parse_stops_when()
        guards = self._parse_guards()
        body = self._parse_body_block()

        self._ts.expect(TokenKind.KW_END, "end")
        self._ts.expect(TokenKind.KW_FUNCTION, "function")

        return A.FunctionDef(
            span=span, name=name, params=params,
            return_type=return_type, return_name=return_name,
            guards=guards, stops_when=stops_when,
            body=body, visibility=visibility,
        )

    def _parse_receives(self) -> list[A.Param]:
        self._ts.expect(TokenKind.KW_RECEIVES, "receives")
        if self._ts.check(TokenKind.KW_NOTHING):
            self._ts.advance()
            return []
        params = []
        while not self._ts.check(TokenKind.KW_RETURNS, TokenKind.KW_BODY,
                                   TokenKind.KW_ON, TokenKind.EOF,
                                   TokenKind.KW_END):
            params.append(self._parse_param())
        return params

    def _parse_returns(self) -> tuple:
        self._ts.expect(TokenKind.KW_RETURNS, "returns")
        if self._ts.check(TokenKind.KW_NOTHING):
            self._ts.advance()
            return A.NothingType(span=self._ts.span), None
        type_node = self._parse_type()
        self._ts.expect(TokenKind.KW_NAMED, "named")
        ret_name = self._ts.expect(TokenKind.IDENTIFIER, "return variable name").value
        return type_node, ret_name

    def _parse_stops_when(self) -> Optional[A.ExprNode]:
        if self._ts.peek().value == "stops" and self._ts.peek(1).value == "when":
            self._ts.advance(); self._ts.advance()
            return self._parse_expr()
        return None

    def _parse_guards(self) -> list[A.OnGuard]:
        guards = []
        while self._ts.check(TokenKind.KW_ON):
            span = self._ts.span
            self._ts.advance()   # consume 'on'

            tok = self._ts.peek()
            if tok.kind == TokenKind.KW_OVERFLOW:
                self._ts.advance()
                condition = A.Identifier(span=tok.span, name="overflow")
            elif tok.kind == TokenKind.KW_ERROR:
                self._ts.advance()
                self._ts.expect(TokenKind.LBRACKET, "[")
                ename = self._ts.expect(TokenKind.IDENTIFIER, "error name").value
                self._ts.expect(TokenKind.RBRACKET, "]")
                condition = A.Identifier(span=tok.span, name=f"error.{ename}")
            else:
                condition = self._parse_expr()

            self._ts.expect(TokenKind.KW_REJECT, "reject")
            self._ts.expect(TokenKind.KW_WITH, "with")
            self._ts.expect(TokenKind.KW_ERROR, "error")
            self._ts.expect(TokenKind.LBRACKET, "[")
            err_tok = self._ts.peek()
            if err_tok.kind == TokenKind.IDENTIFIER or err_tok.kind.name.startswith("KW_"):
                err_name = self._ts.advance().value
            else:
                raise ParseError(f"Expected error name, got {err_tok.value!r}", err_tok.span)
            self._ts.expect(TokenKind.RBRACKET, "]")
            guards.append(A.OnGuard(span=span, condition=condition, error_name=err_name))
        return guards

    def _parse_ownership_mode(self) -> OwnershipMode:
        if self._ts.check(TokenKind.KW_AS):
            self._ts.advance()
            tok = self._ts.peek()
            if tok.value == "owner":
                self._ts.advance()
                return OwnershipMode.OWNER
            if tok.value == "access":
                self._ts.advance()
                return OwnershipMode.ACCESS
            if tok.value == "copy":
                self._ts.advance()
                return OwnershipMode.COPY
            raise ParseError(
                f"Expected 'owner', 'access', or 'copy' after 'as', got {tok.value!r}",
                tok.span)
        return OwnershipMode.NONE

    def _parse_param(self) -> A.Param:
        span = self._ts.span
        type_node = self._parse_type()
        self._ts.expect(TokenKind.KW_NAMED, "named")
        name = self._ts.expect(TokenKind.IDENTIFIER, "parameter name").value
        mode = self._parse_ownership_mode()
        return A.Param(span=span, type_node=type_node, name=name, mode=mode)

    # ── Body block ────────────────────────────────────────────────────────────

    def _parse_body_block(self) -> list[A.StmtNode]:
        self._ts.expect(TokenKind.KW_BODY, "body")
        stmts = self._parse_stmts_until(TokenKind.KW_END)
        self._ts.expect(TokenKind.KW_END, "end")
        self._ts.expect(TokenKind.KW_BODY, "body")
        return stmts

    def _parse_stmts_until(self, *stop_kinds: TokenKind) -> list[A.StmtNode]:
        stmts = []
        while not self._ts.check(*stop_kinds, TokenKind.EOF):
            stmts.append(self._parse_statement())
        return stmts

    # ── Statements ────────────────────────────────────────────────────────────

    def _parse_statement(self) -> A.StmtNode:
        tok = self._ts.peek()

        if tok.kind == TokenKind.KW_DECLARE:
            next_kind = self._ts.peek(1).kind
            if next_kind == TokenKind.KW_INTERRUPT:
                self._ts.advance()
                return self._parse_interrupt_handler()
            elif next_kind == TokenKind.KW_HARDWARE:
                self._ts.advance()
                return self._parse_hardware_register()
            else:
                return self._parse_declare()
        if tok.kind == TokenKind.KW_IF:
            return self._parse_if()
        if tok.kind == TokenKind.KW_REPEAT:
            return self._parse_repeat()
        if tok.kind == TokenKind.KW_CALL:
            return self._parse_call()
        if tok.kind == TokenKind.KW_RETURN:
            return self._parse_return()
        if tok.kind == TokenKind.KW_REJECT:
            return self._parse_reject()
        if tok.kind == TokenKind.KW_STOP:
            return self._parse_stop()
        if tok.kind == TokenKind.KW_SKIP:
            return self._parse_skip()
        if tok.kind == TokenKind.KW_ALLOCATE:
            return self._parse_allocate()
        if tok.kind == TokenKind.KW_RELEASE:
            return self._parse_release()

        # "value at <ptr> is <expr>"
        if tok.kind == TokenKind.KW_VALUE_AT:
            span = self._ts.span
            self._ts.advance()  # consume 'value at'
            ptr_expr = self._parse_primary()
            self._ts.expect(TokenKind.KW_IS, "is")
            value_expr = self._parse_expr()
            return A.AssignStmt(span=span, target=A.ValueAt(span=span, pointer=ptr_expr), value=value_expr)

        # Hardware operations
        if tok.kind == TokenKind.KW_HARDWARE:
            if self._ts.peek(1).kind == TokenKind.KW_REGISTER:
                return self._parse_hardware_register()
            else:
                return self._parse_hardware_command()

        # Match expression
        if tok.kind == TokenKind.KW_MATCH:
            return self._parse_match()

        if tok.kind == TokenKind.IDENTIFIER:
            return self._parse_assign_or_simple_call()

        raise ParseError(f"Unexpected token {tok.value!r} in statement", tok.span)

    def _parse_declare(self) -> A.DeclareStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_DECLARE, "declare")
        is_constant = bool(self._ts.match(TokenKind.KW_CONSTANT))
        type_node = self._parse_type()
        self._ts.expect(TokenKind.KW_NAMED, "named")
        name = self._ts.expect(TokenKind.IDENTIFIER, "variable name").value

        location = None
        if self._ts.check(TokenKind.KW_ON):
            self._ts.advance()
            loc_tok = self._ts.peek()
            if loc_tok.kind in (TokenKind.KW_STACK, TokenKind.KW_HEAP):
                location = loc_tok.value
                self._ts.advance()

        if self._ts.check(TokenKind.KW_IS_NULL):
            tok = self._ts.advance()
            value: A.ExprNode = A.NullLiteral(span=tok.span)
        else:
            self._ts.expect(TokenKind.KW_IS, "is")
            value = self._parse_expr()

        return A.DeclareStmt(span=span, type_node=type_node, name=name,
                             initial_value=value, is_constant=is_constant,
                             location=location)

    def _parse_interrupt_handler(self) -> A.InterruptHandlerDef:
        span = self._ts.span
        # 'declare' already consumed, current token is KW_INTERRUPT
        self._ts.expect(TokenKind.KW_INTERRUPT, "interrupt")
        self._ts.expect(TokenKind.KW_HANDLER, "handler")
        self._ts.expect(TokenKind.KW_NAMED, "named")
        name = self._ts.expect(TokenKind.IDENTIFIER, "handler name").value
        self._ts.expect_value("for")
        self._ts.expect(TokenKind.KW_INTERRUPT, "interrupt")
        self._ts.expect(TokenKind.KW_VECTOR, "vector")

        vector_tok = self._ts.advance()
        vector_num = int(vector_tok.value, 16) if "x" in vector_tok.value.lower() else int(vector_tok.value)

        while not self._ts.check(TokenKind.KW_BODY):
            self._ts.advance()

        body = self._parse_body_block()

        self._ts.expect(TokenKind.KW_END, "end")
        self._ts.expect(TokenKind.KW_INTERRUPT, "interrupt")
        self._ts.expect(TokenKind.KW_HANDLER, "handler")

        return A.InterruptHandlerDef(span=span, name=name, vector=vector_num, body=body)

    # ── Hardware support ──────────────────────────────────────────────────────

    def _parse_hardware_register(self) -> A.HardwareRegisterDef:
        """Parse a hardware register definition, starting with 'hardware'."""
        span = self._ts.span
        self._ts.expect(TokenKind.KW_HARDWARE, "hardware")
        self._ts.expect(TokenKind.KW_REGISTER, "register")

        self._ts.expect(TokenKind.LBRACKET, "[")
        bits_str = self._ts.expect(TokenKind.KW_32BIT, "32bit").value
        bits = int(bits_str.replace("bit", ""))
        self._ts.expect(TokenKind.RBRACKET, "]")

        self._ts.expect(TokenKind.KW_NAMED, "named")
        name = self._ts.expect(TokenKind.IDENTIFIER, "register name").value

        self._ts.expect_value("at")
        self._ts.expect(TokenKind.KW_ADDRESS, "address")
        addr_tok = self._ts.expect(TokenKind.HEX_LIT, "hex address").value
        addr = int(addr_tok, 16)

        self._ts.expect(TokenKind.KW_ACCESS, "access")
        access_mode = self._ts.advance().value  # read / write / read-write

        is_volatile = False
        if self._ts.match(TokenKind.KW_VOLATILE):
            is_volatile = True

        self._ts.expect_value("note")
        self._ts.expect(TokenKind.STRING_LIT, "description")

        return A.HardwareRegisterDef(
            span=span, name=name, address=addr, bits=bits,
            access=access_mode, is_volatile=is_volatile)

    def _parse_hardware_command(self) -> A.StmtNode:
        """Parse a hardware command such as 'hardware write register ...'."""
        span = self._ts.span
        self._ts.expect(TokenKind.KW_HARDWARE, "hardware")
        cmd = self._ts.advance().value  # write / read

        if cmd == "write":
            self._ts.expect(TokenKind.KW_REGISTER, "register")
            name = self._ts.expect(TokenKind.IDENTIFIER, "register name").value
            self._ts.expect_value("value")
            val = self._parse_expr()
            return A.HardwareWriteStmt(span=span, reg_name=name, value=val)

        raise ParseError(f"Unknown hardware command '{cmd}'", span)

    # ── Match expression ─────────────────────────────────────────────────────

    def _parse_match(self) -> A.MatchStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_MATCH, "match")
        expr = self._parse_expr()
        cases = []
        while self._ts.check(TokenKind.KW_WHEN):
            self._ts.advance()  # 'when'
            tok = self._ts.advance()
            v_name = tok.value
            body = self._parse_stmts_until(TokenKind.KW_WHEN, TokenKind.KW_END)
            cases.append(A.MatchCase(span, v_name, body))
        self._ts.expect(TokenKind.KW_END, "end")
        self._ts.expect(TokenKind.KW_MATCH, "match")
        return A.MatchStmt(span, expr, cases)

    def _parse_assign_or_simple_call(self) -> A.StmtNode:
        span = self._ts.span
        
        target = self._parse_primary()

        if isinstance(target, A.CallExpr):
            return A.SimpleCallStmt(span=span, func_name=target.func_name, args=target.args)

        if self._ts.check(TokenKind.KW_IS_NULL):
            self._ts.advance()
            return A.AssignStmt(span=span, target=target, value=A.NullLiteral(span=span))

        if self._ts.check(TokenKind.KW_IS):
            self._ts.advance()
            value = self._parse_expr()
            return A.AssignStmt(span=span, target=target, value=value)

        if isinstance(target, A.Identifier) and self._ts.peek().value == "receives":
            self._ts.advance()
            args = self._parse_receives_args()
            return A.SimpleCallStmt(span=span, func_name=target.name, args=args)

        raise ParseError(f"Expected 'is' or 'receives' after expression", span)

    def _parse_receives_args(self) -> list[A.ExprNode]:
        args = [self._parse_comparison()]
        while self._ts.check(TokenKind.KW_AND):
            self._ts.advance()
            args.append(self._parse_comparison())
        return args

    def _parse_if(self) -> A.IfStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_IF, "if")
        condition = self._parse_expr()
        then_body = self._parse_stmts_until(
            TokenKind.KW_OTHERWISE, TokenKind.KW_END)

        elseif_branches = []
        else_body = None

        while self._ts.check(TokenKind.KW_OTHERWISE):
            self._ts.advance()
            if self._ts.check(TokenKind.KW_IF):
                self._ts.advance()
                elif_cond = self._parse_expr()
                elif_body = self._parse_stmts_until(
                    TokenKind.KW_OTHERWISE, TokenKind.KW_END)
                elseif_branches.append((elif_cond, elif_body))
                if self._ts.check(TokenKind.KW_END):
                    self._ts.advance()
                    self._ts.match(TokenKind.KW_OTHERWISE)
                    self._ts.match(TokenKind.KW_IF)
            else:
                else_body = self._parse_stmts_until(TokenKind.KW_END)
                self._ts.expect(TokenKind.KW_END, "end")
                self._ts.expect(TokenKind.KW_OTHERWISE, "otherwise")
                break

        self._ts.expect(TokenKind.KW_END, "end")
        self._ts.expect(TokenKind.KW_IF, "if")

        return A.IfStmt(span=span, condition=condition, then_body=then_body,
                        elseif_branches=elseif_branches, else_body=else_body)

    def _parse_repeat(self) -> A.RepeatStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_REPEAT, "repeat")
        self._ts.expect(TokenKind.KW_WHILE, "while")
        condition = self._parse_expr()

        loop_name = None
        if self._ts.match(TokenKind.KW_NAMED):
            loop_name = self._ts.expect(TokenKind.IDENTIFIER, "loop name").value

        body = self._parse_stmts_until(TokenKind.KW_END)
        self._ts.expect(TokenKind.KW_END, "end")
        self._ts.expect(TokenKind.KW_REPEAT, "repeat")

        return A.RepeatStmt(span=span, condition=condition, body=body, loop_name=loop_name)

    def _parse_call(self) -> A.CallStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_CALL, "call")
        func_name = self._ts.expect(TokenKind.IDENTIFIER, "function name").value

        args: list[tuple[str, A.ExprNode]] = []
        handlers: list[A.OnHandler] = []

        while self._ts.peek().value == "with":
            self._ts.advance()
            param_name = self._ts.expect(TokenKind.IDENTIFIER, "parameter name").value
            mode = self._parse_ownership_mode()
            self._ts.expect(TokenKind.COLON, ":")
            value = self._parse_expr()
            args.append((param_name, mode, value))

        while self._ts.check(TokenKind.KW_ON):
            handlers.append(self._parse_on_handler())

        self._ts.expect(TokenKind.KW_END, "end")
        self._ts.expect(TokenKind.KW_CALL, "call")

        return A.CallStmt(span=span, func_name=func_name,
                          args=args, handlers=handlers)

    def _parse_on_handler(self) -> A.OnHandler:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_ON, "on")
        tok = self._ts.peek()

        if tok.kind == TokenKind.KW_ERROR:
            self._ts.advance()
            self._ts.expect(TokenKind.LBRACKET, "[")
            err_tok = self._ts.peek()
            if err_tok.kind == TokenKind.IDENTIFIER or err_tok.kind.name.startswith("KW_"):
                err_name = self._ts.advance().value
            else:
                raise ParseError(f"Expected error name, got {err_tok.value!r}", err_tok.span)
            self._ts.expect(TokenKind.RBRACKET, "]")
            body = self._parse_stmts_until(TokenKind.KW_ON, TokenKind.KW_END)
            return A.OnHandler(span=span, kind="error", error_name=err_name, body=body)

        if tok.kind == TokenKind.KW_SUCCESS:
            self._ts.advance()
            body = self._parse_stmts_until(TokenKind.KW_ON, TokenKind.KW_END)
            return A.OnHandler(span=span, kind="success", error_name=None, body=body)

        if tok.kind == TokenKind.KW_OVERFLOW:
            self._ts.advance()
            body = self._parse_stmts_until(TokenKind.KW_ON, TokenKind.KW_END)
            return A.OnHandler(span=span, kind="overflow", error_name=None, body=body)

        raise ParseError(f"Expected error/success/overflow after 'on', got {tok.value!r}", tok.span)

    def _parse_return(self) -> A.ReturnStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_RETURN, "return")
        if self._ts.check(TokenKind.KW_END, TokenKind.KW_OTHERWISE,
                           TokenKind.KW_IF, TokenKind.EOF):
            return A.ReturnStmt(span=span, value=None)
        return A.ReturnStmt(span=span, value=self._parse_expr())

    def _parse_reject(self) -> A.RejectStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_REJECT, "reject")
        self._ts.expect(TokenKind.KW_WITH, "with")
        self._ts.expect(TokenKind.KW_ERROR, "error")
        self._ts.expect(TokenKind.LBRACKET, "[")
        err_tok = self._ts.peek()
        if err_tok.kind == TokenKind.IDENTIFIER or err_tok.kind.name.startswith("KW_"):
            err_name = self._ts.advance().value
        else:
            raise ParseError(f"Expected error name, got {err_tok.value!r}", err_tok.span)
        self._ts.expect(TokenKind.RBRACKET, "]")
        return A.RejectStmt(span=span, error_name=err_name)

    def _parse_stop(self) -> A.StopStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_STOP, "stop")
        
        loop_name = None
        if self._ts.match(TokenKind.KW_LOOP):
            self._ts.expect(TokenKind.LBRACKET, "[")
            loop_name = self._ts.expect(TokenKind.IDENTIFIER, "loop name").value
            self._ts.expect(TokenKind.RBRACKET, "]")
            
        return A.StopStmt(span=span, loop_name=loop_name)

    def _parse_skip(self) -> A.SkipStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_SKIP, "skip")
        
        loop_name = None
        if self._ts.match(TokenKind.KW_LOOP):
            self._ts.expect(TokenKind.LBRACKET, "[")
            loop_name = self._ts.expect(TokenKind.IDENTIFIER, "loop name").value
            self._ts.expect(TokenKind.RBRACKET, "]")
            
        return A.SkipStmt(span=span, loop_name=loop_name)

    def _parse_allocate(self) -> A.AllocateStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_ALLOCATE, "allocate")
        size = self._parse_expr()
        self._ts.expect(TokenKind.KW_BYTES, "bytes")
        self._ts.expect_value("for")
        name = self._ts.expect(TokenKind.IDENTIFIER, "variable name").value
        return A.AllocateStmt(span=span, name=name, size=size)

    def _parse_release(self) -> A.ReleaseStmt:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_RELEASE, "release")
        name = self._ts.expect(TokenKind.IDENTIFIER, "variable name").value
        return A.ReleaseStmt(span=span, name=name)

    # ── Type definitions ──────────────────────────────────────────────────────

    def _parse_int_with_sign(self) -> int:
        """Parse an optionally signed integer literal (e.g. '10' or 'minus 10')."""
        sign = 1
        if self._ts.peek().value == "minus":
            self._ts.advance()
            sign = -1
        return int(self._ts.expect(TokenKind.INTEGER_LIT).value) * sign

    def _parse_type_def(self):
        span = self._ts.span
        self._ts.expect(TokenKind.KW_DEFINE, "define")
        self._ts.expect(TokenKind.KW_TYPE, "type")
        self._ts.expect(TokenKind.LBRACKET, "[")
        name = self._ts.expect(TokenKind.IDENTIFIER, "type name").value
        self._ts.expect(TokenKind.RBRACKET, "]")

        # Case 1: Alias definition with 'as'
        if self._ts.check(TokenKind.KW_AS):
            self._ts.advance()
            target_type = self._parse_type()
            min_v, max_v = None, None
            if self._ts.match(TokenKind.KW_VALID):
                self._ts.expect(TokenKind.KW_RANGE, "range")
                self._ts.expect(TokenKind.KW_FROM, "from")
                min_v = self._parse_int_with_sign()
                self._ts.expect(TokenKind.KW_TO, "to")
                max_v = self._parse_int_with_sign()
            self._ts.expect(TokenKind.KW_END, "end")
            self._ts.expect(TokenKind.KW_TYPE, "type")
            return A.AliasDef(span=span, name=name, target=target_type,
                              min_val=min_v, max_val=max_v)

        # Case 2: Struct definition with 'contains'
        if self._ts.check(TokenKind.KW_CONTAINS):
            self._ts.advance()
            fields = []
            while not (self._ts.check(TokenKind.KW_END) and self._ts.peek(1).value == "contains"):
                f_type = self._parse_type()
                self._ts.expect(TokenKind.KW_NAMED, "named")
                f_name = self._ts.expect(TokenKind.IDENTIFIER, "field name").value
                fields.append(A.StructField(span=self._ts.span, type_node=f_type, name=f_name))
            self._ts.expect(TokenKind.KW_END, "end")
            self._ts.expect(TokenKind.KW_CONTAINS, "contains")

            ops = []
            if self._ts.check(TokenKind.KW_OPERATIONS):
                self._ts.advance()
                while not (self._ts.check(TokenKind.KW_END) and self._ts.peek(1).value == "operations"):
                    ops.append(self._parse_operation())
                self._ts.expect(TokenKind.KW_END, "end")
                self._ts.expect(TokenKind.KW_OPERATIONS, "operations")

            self._ts.expect(TokenKind.KW_END, "end")
            self._ts.expect(TokenKind.KW_TYPE, "type")
            return A.StructDef(span=span, name=name, fields=fields, alignment=4,
                               operations=ops)

        # Case 3: Enum definition with 'can be'
        if self._ts.check(TokenKind.KW_CAN_BE):
            self._ts.advance()  # consume 'can be'
            variants = []
            while not (self._ts.check(TokenKind.KW_END) and self._ts.peek(1).kind == TokenKind.KW_CAN_BE):
                tok = self._ts.advance()
                v_name = tok.value
                variants.append(A.EnumVariant(tok.span, v_name))
            self._ts.expect(TokenKind.KW_END, "end")
            self._ts.expect(TokenKind.KW_CAN_BE, "can be")
            self._ts.expect(TokenKind.KW_END, "end")
            self._ts.expect(TokenKind.KW_TYPE, "type")
            return A.EnumDef(span, name, variants)

        raise ParseError("Expected 'as', 'contains', or 'can be' in type definition", self._ts.span)

    def _parse_operation(self) -> A.OperationDef:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_OPERATION, "operation")
        name = self._ts.expect(TokenKind.IDENTIFIER, "operation name").value
        params = self._parse_receives()
        ret_type, ret_name = self._parse_returns()
        body = self._parse_body_block()
        self._ts.expect(TokenKind.KW_END, "end")
        self._ts.expect(TokenKind.KW_OPERATION, "operation")
        return A.OperationDef(span=span, name=name, params=params,
                              return_type=ret_type, return_name=ret_name, body=body)

    # ── Types ─────────────────────────────────────────────────────────────────

    def _parse_type(self) -> A.TypeNode:
        span = self._ts.span
        tok = self._ts.peek()

        if tok.kind == TokenKind.KW_INTEGER:
            self._ts.advance()
            self._ts.expect(TokenKind.LBRACKET, "[")
            signed = self._parse_signedness()
            self._ts.expect(TokenKind.COMMA, ",")
            bits = self._parse_bits()
            self._ts.expect(TokenKind.RBRACKET, "]")
            return A.IntegerType(span=span, signed=signed, bits=bits)

        if tok.kind == TokenKind.KW_FLOAT:
            self._ts.advance()
            self._ts.expect(TokenKind.LBRACKET, "[")
            bits = self._parse_bits()
            self._ts.expect(TokenKind.RBRACKET, "]")
            return A.FloatType(span=span, bits=bits)

        if tok.kind == TokenKind.KW_BYTE:
            self._ts.advance()
            return A.ByteType(span=span)

        if tok.kind == TokenKind.KW_BOOLEAN:
            self._ts.advance()
            return A.BooleanType(span=span)

        if tok.kind == TokenKind.KW_TEXT:
            self._ts.advance()
            return A.TextType(span=span)

        if tok.kind == TokenKind.KW_NOTHING:
            self._ts.advance()
            return A.NothingType(span=span)

        if tok.kind == TokenKind.KW_POINTER:
            self._ts.advance()
            self._ts.expect(TokenKind.LBRACKET, "[")
            self._ts.expect(TokenKind.KW_TO, "to")
            inner = self._parse_type()
            self._ts.expect(TokenKind.RBRACKET, "]")
            return A.PointerType(span=span, inner=inner)

        if tok.kind == TokenKind.KW_ARRAY:
            self._ts.advance()
            self._ts.expect(TokenKind.LBRACKET, "[")
            etype = self._parse_type()
            self._ts.expect(TokenKind.COMMA, ",")
            size_tok = self._ts.expect(TokenKind.INTEGER_LIT)
            self._ts.expect(TokenKind.RBRACKET, "]")
            return A.ArrayType(span=span, element_type=etype, size=int(size_tok.value))

        if tok.kind == TokenKind.IDENTIFIER:
            self._ts.advance()
            return A.NamedType(span=span, name=tok.value)

        raise ParseError(f"Expected a type, got {tok.value!r}", tok.span)

    def _parse_signedness(self) -> bool:
        tok = self._ts.peek()
        if tok.kind == TokenKind.KW_SIGNED:
            self._ts.advance(); return True
        if tok.kind == TokenKind.KW_UNSIGNED:
            self._ts.advance(); return False
        raise ParseError(f"Expected 'signed' or 'unsigned', got {tok.value!r}", tok.span)

    def _parse_bits(self) -> int:
        tok = self._ts.peek()
        bit_map = {
            TokenKind.KW_8BIT: 8, TokenKind.KW_16BIT: 16,
            TokenKind.KW_32BIT: 32, TokenKind.KW_64BIT: 64,
        }
        if tok.kind in bit_map:
            self._ts.advance()
            return bit_map[tok.kind]
        raise ParseError(f"Expected bit size (8bit/16bit/32bit/64bit), got {tok.value!r}", tok.span)

    # ── Expressions ───────────────────────────────────────────────────────────

    def _parse_expr(self) -> A.ExprNode:
        return self._parse_logic()

    def _parse_logic(self) -> A.ExprNode:
        left = self._parse_comparison()
        while self._ts.check(TokenKind.KW_AND, TokenKind.KW_OR):
            op = self._ts.advance().value
            right = self._parse_comparison()
            left = A.LogicOp(span=left.span, op=op, left=left, right=right)
        return left

    def _parse_comparison(self) -> A.ExprNode:
        left = self._parse_arith()
        tok = self._ts.peek()
        cmp_kinds = {
            TokenKind.KW_IS_EQUAL_TO, TokenKind.KW_IS_NOT_EQUAL_TO,
            TokenKind.KW_IS_GREATER_THAN, TokenKind.KW_IS_LESS_THAN,
            TokenKind.KW_IS_GREATER_OR_EQUAL, TokenKind.KW_IS_LESS_OR_EQUAL,
            TokenKind.KW_IS_NOT_NULL, TokenKind.KW_IS_NULL,
        }
        if tok.kind in cmp_kinds:
            op = self._ts.advance().value
            if tok.kind in (TokenKind.KW_IS_NOT_NULL, TokenKind.KW_IS_NULL):
                return A.CompareOp(span=left.span, op=op, left=left,
                                   right=A.NullLiteral(span=tok.span))
            right = self._parse_arith()
            return A.CompareOp(span=left.span, op=op, left=left, right=right)
        return left

    def _parse_arith(self) -> A.ExprNode:
        left = self._parse_unary()
        arith_map = {
            TokenKind.KW_PLUS: "plus", TokenKind.KW_MINUS: "minus",
            TokenKind.KW_MULTIPLY: "multiply", TokenKind.KW_DIVIDE: "divide",
            TokenKind.KW_REMAINDER: "remainder",
        }
        while self._ts.peek().kind in arith_map:
            op = arith_map[self._ts.advance().kind]
            self._ts.match(TokenKind.KW_BY)
            right = self._parse_unary()
            left = A.BinaryOp(span=left.span, op=op, left=left, right=right)
        return left

    def _parse_unary(self) -> A.ExprNode:
        tok = self._ts.peek()
        if tok.kind == TokenKind.KW_NOT:
            self._ts.advance()
            return A.NotOp(span=tok.span, operand=self._parse_unary())
        if tok.kind == TokenKind.KW_ADDRESS_OF:
            self._ts.advance()
            name = self._ts.expect(TokenKind.IDENTIFIER, "variable name").value
            mode = self._parse_ownership_mode()
            return A.AddressOf(span=tok.span, name=name, mode=mode)
        if tok.kind == TokenKind.KW_VALUE_AT:
            self._ts.advance()
            ptr = self._parse_primary()
            return A.ValueAt(span=tok.span, pointer=ptr)
        if tok.kind == TokenKind.KW_SIZE_OF:
            self._ts.advance()
            type_node = self._parse_type()
            return A.SizeOf(span=tok.span, target=type_node)
        # --- Bitwise operations ---
        if tok.kind == TokenKind.KW_BITS:
            self._ts.advance() # consume 'bits'
            self._ts.expect(TokenKind.KW_OF, "of")
            value = self._parse_primary()
            
            next_tok = self._ts.peek()
            if next_tok.kind == TokenKind.KW_SHIFTED:
                self._ts.advance() # shifted
                direction = self._ts.advance().value # left / right
                self._ts.expect(TokenKind.KW_BY, "by")
                amount = self._parse_primary()
                return A.ShiftOp(span=tok.span, direction=direction, value=value, amount=amount)
                
            if next_tok.kind in (TokenKind.KW_AND, TokenKind.KW_OR, TokenKind.KW_XOR):
                op = self._ts.advance().value
                self._ts.expect(TokenKind.KW_BITS, "bits")
                self._ts.expect(TokenKind.KW_OF, "of")
                right = self._parse_primary()
                return A.BitwiseOp(span=tok.span, op=op, left=value, right=right)
        # --- End bitwise ---
        if tok.kind == TokenKind.KW_CONVERT:
            return self._parse_convert()
        return self._parse_primary()

    def _parse_convert(self) -> A.ConvertExpr:
        span = self._ts.span
        self._ts.expect(TokenKind.KW_CONVERT, "convert")
        value = self._parse_primary()
        self._ts.expect(TokenKind.KW_TO, "to")
        target_type = self._parse_type()
        
        on_overflow_stmts = []
        if self._ts.match(TokenKind.KW_ON):
            self._ts.expect(TokenKind.KW_OVERFLOW, "overflow")
            while not (self._ts.check(TokenKind.KW_END) and self._ts.peek(1).value == "overflow"):
                on_overflow_stmts.append(self._parse_statement())
            self._ts.expect(TokenKind.KW_END, "end")
            self._ts.expect(TokenKind.KW_OVERFLOW, "overflow")
            
        return A.ConvertExpr(span=span, value=value, target_type=target_type, on_overflow=on_overflow_stmts)

    def _parse_primary(self) -> A.ExprNode:
        span = self._ts.span
        tok = self._ts.peek()

        if tok.kind == TokenKind.INTEGER_LIT:
            self._ts.advance()
            return A.IntLiteral(span=span, value=int(tok.value))

        if tok.kind == TokenKind.HEX_LIT:
            self._ts.advance()
            return A.IntLiteral(span=span, value=int(tok.value, 16))

        if tok.kind == TokenKind.FLOAT_LIT:
            self._ts.advance()
            return A.FloatLiteral(span=span, value=float(tok.value))

        if tok.kind == TokenKind.BOOL_LIT:
            self._ts.advance()
            return A.BoolLiteral(span=span, value=(tok.value == "true"))

        if tok.kind == TokenKind.STRING_LIT:
            self._ts.advance()
            return A.TextLiteral(span=span, value=tok.value)

        if tok.kind == TokenKind.NULL_LIT:
            self._ts.advance()
            return A.NullLiteral(span=span)

        if tok.kind == TokenKind.KW_NOTHING:
            self._ts.advance()
            return A.NullLiteral(span=span)

        if tok.kind == TokenKind.LPAREN:
            self._ts.advance()
            expr = self._parse_expr()
            self._ts.expect(TokenKind.RPAREN, ")")
            return expr

        if tok.kind == TokenKind.IDENTIFIER:
            name = self._ts.advance().value

            # Function call expression: func receives ...
            if self._ts.peek().value == "receives":
                self._ts.advance()
                args = self._parse_receives_args()
                return A.CallExpr(span=span, func_name=name, args=args)

            # Variable reference, possibly followed by 'at index', '.field' or '.method receives'
            node: A.ExprNode = A.Identifier(span=span, name=name)
            while True:
                next_tok = self._ts.peek()
                if next_tok.kind == TokenKind.DOT:
                    self._ts.advance()
                    field_name = self._ts.expect(TokenKind.IDENTIFIER, "field/method name").value
                    # If followed by 'receives' it's a method call
                    if self._ts.peek().value == "receives":
                        self._ts.advance()
                        args = self._parse_receives_args()
                        node = A.MethodCallExpr(span=span, obj=node, method=field_name, args=args)
                    else:
                        node = A.FieldAccess(span=span, obj=node, field=field_name)
                elif next_tok.value == "at" and self._ts.peek(1).value == "index":
                    self._ts.advance()  # 'at'
                    self._ts.advance()  # 'index'
                    idx_expr = self._parse_expr()
                    node = A.ArrayIndex(span=span, target=node, index_expr=idx_expr)
                else:
                    break
            return node

        raise ParseError(f"Expected an expression, got {tok.value!r}", tok.span)
