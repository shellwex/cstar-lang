"""
C* Compiler — Control Flow Graph (CFG)
Stage 4, Step 1: Build all execution paths through a function.

Concepts
────────
• A BasicBlock is a linear sequence of statements with no branches inside.
• Edges connect blocks: unconditional (→), true-branch (→T), false-branch (→F).
• Every function has exactly one Entry block and one or more Exit blocks.
• On error / on success handlers are separate blocks connected by edges.
• The CFG is later traversed by the level checker to apply narrow points.

Block kinds
───────────
  ENTRY   — synthetic first block (no statements)
  NORMAL  — regular sequence of statements
  BRANCH  — ends with a conditional (if / repeat)
  EXIT    — function exit point (return, reject, or fall-off)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from ..parser import ast as A


# ── Block kind ────────────────────────────────────────────────────────────────

class BlockKind(Enum):
    ENTRY  = auto()
    NORMAL = auto()
    BRANCH = auto()
    EXIT   = auto()


# ── CFG node ──────────────────────────────────────────────────────────────────

@dataclass
class BasicBlock:
    id: int
    kind: BlockKind
    stmts: list = field(default_factory=list)   # AST statements in this block
    # Successors
    succ_true:  Optional["BasicBlock"] = None   # taken branch / unconditional next
    succ_false: Optional["BasicBlock"] = None   # not-taken branch
    # Predecessors (filled after graph is complete)
    preds: list["BasicBlock"] = field(default_factory=list)
    # Human-readable label
    label: str = ""

    def __repr__(self) -> str:
        return f"BB{self.id}({self.label or self.kind.name})"

    def successors(self) -> list["BasicBlock"]:
        s = []
        if self.succ_true  is not None: s.append(self.succ_true)
        if self.succ_false is not None: s.append(self.succ_false)
        return s


# ── CFG ───────────────────────────────────────────────────────────────────────

@dataclass
class CFG:
    func_name: str
    entry: BasicBlock
    blocks: list[BasicBlock] = field(default_factory=list)

    @property
    def exits(self) -> list[BasicBlock]:
        return [b for b in self.blocks if b.kind == BlockKind.EXIT]

    def all_paths(self) -> list[list[BasicBlock]]:
        """Return all simple paths from entry to any exit (for level checking)."""
        results: list[list[BasicBlock]] = []
        self._dfs(self.entry, [self.entry], set(), results)
        return results

    def _dfs(self, block: BasicBlock, path: list[BasicBlock],
             visited: set[int], results: list) -> None:
        if block.kind == BlockKind.EXIT:
            results.append(list(path))
            return
        for succ in block.successors():
            if succ.id in visited:
                # Back-edge (loop) — treat as exit of this path
                results.append(list(path) + [succ])
                continue
            self._dfs(succ, path + [succ], visited | {succ.id}, results)

    def dump(self) -> str:
        """Human-readable graph dump for debugging."""
        lines = [f"CFG for function '{self.func_name}'",
                 f"  Blocks: {len(self.blocks)}",
                 f"  Exits:  {len(self.exits)}",
                 ""]
        for b in self.blocks:
            lines.append(f"  {b!r}")
            lines.append(f"    statements: {len(b.stmts)}")
            for s in b.stmts:
                lines.append(f"      {type(s).__name__}")
            if b.succ_true:
                arrow = "→T" if b.succ_false else "→"
                lines.append(f"    {arrow} {b.succ_true!r}")
            if b.succ_false:
                lines.append(f"    →F {b.succ_false!r}")
            lines.append("")
        return "\n".join(lines)


# ── CFG Builder ───────────────────────────────────────────────────────────────

class CFGBuilder:
    """
    Builds a CFG from a FunctionDef AST node.

    Usage:
        builder = CFGBuilder()
        cfg = builder.build(func_def)
    """

    def __init__(self) -> None:
        self._counter = 0
        self._all_blocks: list[BasicBlock] = []

    def build(self, func: A.FunctionDef) -> CFG:
        self._counter = 0
        self._all_blocks = []

        entry = self._new_block(BlockKind.ENTRY, "entry")
        exit_block = self._new_block(BlockKind.EXIT, "exit")

        # Build the body starting from entry
        final = self._build_stmts(func.body, entry, exit_block)

        # Connect the last block to exit (if it doesn't already branch there)
        if final is not None and final is not exit_block:
            self._link(final, exit_block)

        # Fill predecessor lists
        self._fill_preds()

        return CFG(
            func_name=func.name,
            entry=entry,
            blocks=self._all_blocks,
        )

    def build_from_stmts(self, stmts: list, name: str = "<body>") -> CFG:
        """Build CFG from a raw statement list (e.g. program body)."""
        self._counter = 0
        self._all_blocks = []
        entry = self._new_block(BlockKind.ENTRY, "entry")
        exit_block = self._new_block(BlockKind.EXIT, "exit")
        final = self._build_stmts(stmts, entry, exit_block)
        if final is not None and final is not exit_block:
            self._link(final, exit_block)
        self._fill_preds()
        return CFG(func_name=name, entry=entry, blocks=self._all_blocks)

    # ── Statement sequence builder ────────────────────────────────────────────

    def _build_stmts(
        self,
        stmts: list,
        current: BasicBlock,
        exit_block: BasicBlock,
    ) -> Optional[BasicBlock]:
        """
        Append statements to *current*, creating new blocks as needed.
        Returns the last block in the sequence (may differ from *current*
        if control flow was introduced), or None if all paths exit.
        """
        for stmt in stmts:
            result = self._build_stmt(stmt, current, exit_block)
            if result is None:
                return None   # all paths from here exit (return/reject)
            current = result
        return current

    def _build_stmt(
        self,
        stmt,
        current: BasicBlock,
        exit_block: BasicBlock,
    ) -> Optional[BasicBlock]:
        """Returns the block to continue from, or None if stmt always exits."""

        # ── If ────────────────────────────────────────────────────────────────
        if isinstance(stmt, A.IfStmt):
            return self._build_if(stmt, current, exit_block)

        # ── Repeat ───────────────────────────────────────────────────────────
        if isinstance(stmt, A.RepeatStmt):
            return self._build_repeat(stmt, current, exit_block)

        # ── Call block ────────────────────────────────────────────────────────
        if isinstance(stmt, A.CallStmt):
            return self._build_call(stmt, current, exit_block)

        # ── Return ────────────────────────────────────────────────────────────
        if isinstance(stmt, A.ReturnStmt):
            current.stmts.append(stmt)
            self._link(current, exit_block)
            return None   # nothing after return on this path

        # ── Reject ────────────────────────────────────────────────────────────
        if isinstance(stmt, A.RejectStmt):
            current.stmts.append(stmt)
            reject_exit = self._new_block(BlockKind.EXIT,
                                          f"reject_{stmt.error_name}")
            reject_exit.stmts.append(stmt)
            self._link(current, reject_exit)
            return None

        # ── Stop (break) ──────────────────────────────────────────────────────
        if isinstance(stmt, A.StopStmt):
            current.stmts.append(stmt)
            self._link(current, exit_block)
            return None

        # ── Skip (continue) ───────────────────────────────────────────────────
        if isinstance(stmt, A.SkipStmt):
            current.stmts.append(stmt)
            # skip goes back to loop condition — modelled as exit of this path
            self._link(current, exit_block)
            return None

        # ── Everything else — plain statement ─────────────────────────────────
        current.stmts.append(stmt)
        return current

    # ── If builder ────────────────────────────────────────────────────────────

    def _build_if(
        self,
        stmt: A.IfStmt,
        current: BasicBlock,
        exit_block: BasicBlock,
    ) -> Optional[BasicBlock]:
        current.kind = BlockKind.BRANCH
        current.stmts.append(stmt)   # condition lives here
        merge = self._new_block(BlockKind.NORMAL, "if_merge")

        # Then branch
        then_block = self._new_block(BlockKind.NORMAL, "if_then")
        self._link_true(current, then_block)
        then_end = self._build_stmts(stmt.then_body, then_block, exit_block)
        if then_end is not None:
            self._link(then_end, merge)

        # Else-if branches
        prev_false = current
        for elif_cond, elif_body in stmt.elseif_branches:
            elif_block = self._new_block(BlockKind.BRANCH, "elif")
            self._link_false(prev_false, elif_block)
            elif_body_block = self._new_block(BlockKind.NORMAL, "elif_body")
            self._link_true(elif_block, elif_body_block)
            elif_end = self._build_stmts(elif_body, elif_body_block, exit_block)
            if elif_end is not None:
                self._link(elif_end, merge)
            prev_false = elif_block

        # Else branch
        if stmt.else_body is not None:
            else_block = self._new_block(BlockKind.NORMAL, "if_else")
            self._link_false(prev_false, else_block)
            else_end = self._build_stmts(stmt.else_body, else_block, exit_block)
            if else_end is not None:
                self._link(else_end, merge)
        else:
            # No else — false branch goes directly to merge
            self._link_false(prev_false, merge)

        # If merge has no predecessors and no successors, all paths exited
        if not merge.preds and merge not in self._all_blocks:
            return None
        return merge

    # ── Repeat builder ────────────────────────────────────────────────────────

    def _build_repeat(
        self,
        stmt: A.RepeatStmt,
        current: BasicBlock,
        exit_block: BasicBlock,
    ) -> Optional[BasicBlock]:
        # Loop structure:
        #   current → cond_block →T body_block → cond_block (back-edge)
        #                        →F after_block

        cond_block  = self._new_block(BlockKind.BRANCH, "loop_cond")
        body_block  = self._new_block(BlockKind.NORMAL, "loop_body")
        after_block = self._new_block(BlockKind.NORMAL, "loop_after")

        self._link(current, cond_block)
        cond_block.stmts.append(stmt)   # condition expression
        self._link_true(cond_block, body_block)
        self._link_false(cond_block, after_block)

        # Body — stop jumps to after_block, skip jumps back to cond_block
        body_end = self._build_stmts(stmt.body, body_block, after_block)
        if body_end is not None:
            self._link(body_end, cond_block)   # loop back-edge

        return after_block

    # ── Call block builder ────────────────────────────────────────────────────

    def _build_call(
        self,
        stmt: A.CallStmt,
        current: BasicBlock,
        exit_block: BasicBlock,
    ) -> Optional[BasicBlock]:
        """
        call f
            on error[X]  → error_block_X
            on success   → success_block
        end call

        All handler blocks merge at call_merge.
        """
        current.stmts.append(stmt)
        current.kind = BlockKind.BRANCH
        merge = self._new_block(BlockKind.NORMAL, f"call_{stmt.func_name}_merge")

        has_successor = False

        for handler in stmt.handlers:
            h_block = self._new_block(
                BlockKind.NORMAL,
                f"call_{stmt.func_name}_{handler.kind}"
                + (f"_{handler.error_name}" if handler.error_name else ""),
            )
            # All handlers are reachable from the call block
            if current.succ_true is None:
                self._link_true(current, h_block)
            else:
                # Additional handlers — link as false chain
                # (simplified: all handlers are equally reachable)
                self._link_false(current, h_block)
                # Extend the false chain for next handler
                current = h_block
                current.kind = BlockKind.BRANCH

            h_end = self._build_stmts(handler.body, h_block, exit_block)
            if h_end is not None:
                self._link(h_end, merge)
                has_successor = True

        return merge if has_successor else None

    # ── Graph helpers ─────────────────────────────────────────────────────────

    def _new_block(self, kind: BlockKind, label: str = "") -> BasicBlock:
        b = BasicBlock(id=self._counter, kind=kind, label=label)
        self._counter += 1
        self._all_blocks.append(b)
        return b

    def _link(self, src: BasicBlock, dst: BasicBlock) -> None:
        """Unconditional edge."""
        if src.succ_true is None:
            src.succ_true = dst
        # Don't overwrite — first link wins for unconditional

    def _link_true(self, src: BasicBlock, dst: BasicBlock) -> None:
        src.succ_true = dst

    def _link_false(self, src: BasicBlock, dst: BasicBlock) -> None:
        src.succ_false = dst

    def _fill_preds(self) -> None:
        """Fill predecessor lists after all edges are set."""
        for b in self._all_blocks:
            for s in b.successors():
                if b not in s.preds:
                    s.preds.append(b)
