"""
C* Compiler — Lifetime Analyzer (Stage 4, Step 4)
Based on Section 6.2 — Level System

Lifetime narrow point:
    "В этой точке кода — жива ли цель этого указателя?"

A pointer outlives its target when:
    1. A variable's address is taken inside a scope block (if/repeat)
    2. The pointer escapes that scope
    3. The pointer is used after the scope exits (target is dead)

Algorithm:
    - Track every `address of <name>` assignment to a pointer variable
    - Record the scope depth where the target lives
    - If the pointer is used at a shallower scope than where target was declared
      → lifetime violation
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

from ..parser import ast as A
from .checker import LevelViolation


@dataclass
class TargetInfo:
    """Where a pointer's target was declared."""
    target_name: str
    scope_depth: int     # depth at which target was declared
    span: A.Span


@dataclass
class LifetimeAnalyzer:
    violations: list[LevelViolation] = field(default_factory=list)

    def analyze_function(self, func: A.FunctionDef) -> list[LevelViolation]:
        self.violations = []
        # ptr_name → TargetInfo
        ptr_targets: dict[str, TargetInfo] = {}
        self._analyze_stmts(func.body, ptr_targets, scope_depth=0)
        return self.violations

    def analyze_stmts(self, stmts: list) -> list[LevelViolation]:
        self.violations = []
        self._analyze_stmts(stmts, {}, scope_depth=0)
        return self.violations

    # ── Statement walker ──────────────────────────────────────────────────────

    def _analyze_stmts(
        self,
        stmts: list,
        ptr_targets: dict[str, TargetInfo],
        scope_depth: int,
    ) -> None:
        for stmt in stmts:
            self._analyze_stmt(stmt, ptr_targets, scope_depth)

    def _analyze_stmt(
        self,
        stmt,
        ptr_targets: dict[str, TargetInfo],
        scope_depth: int,
    ) -> None:

        if isinstance(stmt, A.AssignStmt):
            self._check_assign(stmt, ptr_targets, scope_depth)

        elif isinstance(stmt, A.DeclareStmt):
            self._check_declare(stmt, ptr_targets, scope_depth)

        elif isinstance(stmt, A.IfStmt):
            # Enter deeper scope — local ptr_targets copy
            inner = dict(ptr_targets)
            self._analyze_stmts(stmt.then_body, inner, scope_depth + 1)
            # After if block, pointers pointing to inner targets are dead
            self._expire_scope(ptr_targets, inner, scope_depth + 1)

            for _, elif_body in stmt.elseif_branches:
                inner2 = dict(ptr_targets)
                self._analyze_stmts(elif_body, inner2, scope_depth + 1)
                self._expire_scope(ptr_targets, inner2, scope_depth + 1)

            if stmt.else_body:
                inner3 = dict(ptr_targets)
                self._analyze_stmts(stmt.else_body, inner3, scope_depth + 1)
                self._expire_scope(ptr_targets, inner3, scope_depth + 1)

        elif isinstance(stmt, A.RepeatStmt):
            inner = dict(ptr_targets)
            self._analyze_stmts(stmt.body, inner, scope_depth + 1)
            self._expire_scope(ptr_targets, inner, scope_depth + 1)

        elif isinstance(stmt, A.ReturnStmt):
            if stmt.value:
                self._check_expr_lifetime(stmt.value, ptr_targets, scope_depth, stmt)

        elif isinstance(stmt, A.CallStmt):
            for _, __, arg_expr in stmt.args:
                self._check_expr_lifetime(arg_expr, ptr_targets, scope_depth, stmt)
            for handler in stmt.handlers:
                inner = dict(ptr_targets)
                self._analyze_stmts(handler.body, inner, scope_depth + 1)

        elif isinstance(stmt, A.SimpleCallStmt):
            for arg in stmt.args:
                self._check_expr_lifetime(arg, ptr_targets, scope_depth, stmt)

    def _check_declare(
        self,
        stmt: A.DeclareStmt,
        ptr_targets: dict[str, TargetInfo],
        scope_depth: int,
    ) -> None:
        """Check declare initial value for address-of; check deref lifetime."""
        if isinstance(stmt.initial_value, A.AddressOf):
            # ptr is address of target — record where target lives
            target_name = stmt.initial_value.name
            ptr_targets[stmt.name] = TargetInfo(
                target_name=target_name,
                scope_depth=scope_depth,
                span=stmt.span,
            )
        elif isinstance(stmt.initial_value, A.ValueAt):
            self._check_expr_lifetime(stmt.initial_value, ptr_targets, scope_depth, stmt)

    def _check_assign(
        self,
        stmt: A.AssignStmt,
        ptr_targets: dict[str, TargetInfo],
        scope_depth: int,
    ) -> None:
        # ptr is address of x — record lifetime
        if isinstance(stmt.value, A.AddressOf):
            if isinstance(stmt.target, A.Identifier):
                target_name = stmt.value.name
                ptr_targets[stmt.target.name] = TargetInfo(
                    target_name=target_name,
                    scope_depth=scope_depth,
                    span=stmt.span,
                )
        else:
            self._check_expr_lifetime(stmt.value, ptr_targets, scope_depth, stmt)

    def _check_expr_lifetime(
        self,
        expr,
        ptr_targets: dict[str, TargetInfo],
        scope_depth: int,
        context_stmt,
    ) -> None:
        """Check if a ValueAt dereference uses a pointer whose target is dead."""
        if isinstance(expr, A.ValueAt):
            if isinstance(expr.pointer, A.Identifier):
                ptr_name = expr.pointer.name
                if ptr_name in ptr_targets:
                    info = ptr_targets[ptr_name]
                    if scope_depth < info.scope_depth:
                        # Pointer used at shallower depth than where target was born
                        # → target is no longer alive
                        self.violations.append(LevelViolation(
                            kind="lifetime",
                            message=(
                                f"Pointer '{ptr_name}' outlives its target "
                                f"'{info.target_name}'"
                            ),
                            detail=(
                                f"'{info.target_name}' was declared at scope depth "
                                f"{info.scope_depth} (inside a block). "
                                f"'{ptr_name}' now points to dead memory — "
                                f"the variable no longer exists. "
                                f"In C*, a pointer must never outlive the variable "
                                f"it points to."
                            ),
                            hint=(
                                f"Move the use of 'value at {ptr_name}' inside "
                                f"the same block where '{info.target_name}' is declared, "
                                f"or declare '{info.target_name}' at a wider scope."
                            ),
                            span=info.span,
                        ))

        # Recurse into sub-expressions
        if isinstance(expr, A.BinaryOp):
            self._check_expr_lifetime(expr.left, ptr_targets, scope_depth, context_stmt)
            self._check_expr_lifetime(expr.right, ptr_targets, scope_depth, context_stmt)
        elif isinstance(expr, A.CompareOp):
            self._check_expr_lifetime(expr.left, ptr_targets, scope_depth, context_stmt)
            self._check_expr_lifetime(expr.right, ptr_targets, scope_depth, context_stmt)
        elif isinstance(expr, A.LogicOp):
            self._check_expr_lifetime(expr.left, ptr_targets, scope_depth, context_stmt)
            self._check_expr_lifetime(expr.right, ptr_targets, scope_depth, context_stmt)
        elif isinstance(expr, A.NotOp):
            self._check_expr_lifetime(expr.operand, ptr_targets, scope_depth, context_stmt)

    def _expire_scope(
        self,
        outer: dict[str, TargetInfo],
        inner: dict[str, TargetInfo],
        inner_depth: int,
    ) -> None:
        """
        After an inner scope exits, propagate ALL pointer assignments
        back to the outer scope, but mark as dangling those whose
        targets lived only inside the inner scope.

        Key case:
            ptr is declared in OUTER scope.
            Inside if-body, ptr is address of x  (x born in inner scope).
            After if exits, ptr in outer scope now points to dead x.
            Next use of value at ptr in outer scope → lifetime violation.
        """
        for ptr_name, info in inner.items():
            # Target was born inside inner scope (depth >= inner_depth)
            target_is_inner = (info.scope_depth >= inner_depth)

            if target_is_inner:
                # Pointer now points to dead memory.
                # Propagate back to outer with a "dangling" marker:
                # scope_depth set to inner_depth so that any outer-scope
                # use (scope_depth < inner_depth) triggers a violation.
                outer[ptr_name] = TargetInfo(
                    target_name=info.target_name,
                    scope_depth=inner_depth,
                    span=info.span,
                )
            else:
                # Target lives in outer scope or higher — still valid.
                # Propagate back unchanged.
                outer[ptr_name] = info
