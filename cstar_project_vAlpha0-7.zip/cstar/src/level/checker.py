"""
C* Compiler — Level Checker (Stage 4)
Applies narrow points to every path through every function's CFG.

Narrow points implemented
─────────────────────────
1. RELEASE  — every heap variable is released on every path to exit
2. NULL     — every pointer is null-checked before value-at dereference
3. LIFETIME — pointer does not outlive its target (scope-based)
4. OWNER    — heap variable not used after release (use-after-free)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

from ..parser import ast as A
from ..sema.analyzer import CType, ast_type_to_ctype, Diagnostic
from .cfg import CFG, CFGBuilder, BasicBlock, BlockKind


# ── Level violation ───────────────────────────────────────────────────────────

@dataclass
class LevelViolation:
    kind: str          # "release" | "null" | "lifetime" | "owner"
    message: str
    detail: str        # explanation of the rule
    hint: str          # how to fix
    span: A.Span

    def __str__(self) -> str:
        sep = "━" * 48
        return (
            f"\n{sep}\n"
            f"LEVEL VIOLATION — {self.message}\n"
            f"{sep}\n"
            f"\nWhy this is a problem:\n"
            f"    {self.detail}\n"
            f"\nHow to fix:\n"
            f"    {self.hint}\n"
            f"\nRule: Section 6.2 — Level System\n"
            f"{sep}"
        )


# ── Heap variable tracker ─────────────────────────────────────────────────────

@dataclass
class HeapVar:
    name: str
    span: A.Span
    released_in: set[int] = field(default_factory=set)  # block ids where released


# ── Null-check tracker ────────────────────────────────────────────────────────

@dataclass
class NullCheck:
    name: str       # variable name
    checked: bool   # True if a null check was seen on this path


# ── Level checker ─────────────────────────────────────────────────────────────

class LevelChecker:
    """
    Runs all four narrow-point checks on a program's functions.

    Usage:
        checker = LevelChecker()
        violations = checker.check_program(prog)
    """

    def __init__(self) -> None:
        self.violations: list[LevelViolation] = []

    def check_program(self, prog: A.ProgramDef) -> list[LevelViolation]:
        self.violations = []
        builder = CFGBuilder()
        for func in prog.functions:
            cfg = builder.build(func)
            self._check_function(func, cfg)
        # Also check program body
        if prog.body:
            cfg = builder.build_from_stmts(prog.body, prog.name)
            self._check_body(cfg)
        return self.violations

    def check_module(self, mod: A.ModuleDef) -> list[LevelViolation]:
        self.violations = []
        builder = CFGBuilder()
        for func in mod.functions:
            cfg = builder.build(func)
            self._check_function(func, cfg)
        return self.violations

    # ── Per-function checks ───────────────────────────────────────────────────

    def _check_function(self, func: A.FunctionDef, cfg: CFG) -> None:
        paths = cfg.all_paths()
        heap_vars = self._collect_heap_vars(func.body)
        ptr_vars  = self._collect_pointer_vars(func.body)

        # DEBUG: показать, что проверка началась и какие heap-переменные найдены
        print(f"[DEBUG] Checking function '{func.name}'")
        if heap_vars:
            print(f"[DEBUG]   Heap variables found: {[hv.name for hv in heap_vars]}")
        else:
            print("[DEBUG]   No heap variables in this function.")

        for path in paths:
            stmts_on_path = self._stmts_on_path(path)

            # Narrow point 1 — release
            for hv in heap_vars:
                self._check_release(hv, stmts_on_path, path)

            # Narrow point 2 — null check
            for pv in ptr_vars:
                self._check_null(pv, stmts_on_path)

            # Narrow point 3 — use after free
            for hv in heap_vars:
                self._check_use_after_free(hv, stmts_on_path)

        # Narrow point 4 — lifetime (scope-based, not path-based)
        self.violations.extend(_run_lifetime(func, is_func=True))

    def _check_body(self, cfg: CFG) -> None:
        paths = cfg.all_paths()
        # Collect heap vars from all blocks
        all_stmts = []
        for block in cfg.blocks:
            all_stmts.extend(block.stmts)
        heap_vars = self._collect_heap_vars(all_stmts)
        ptr_vars  = self._collect_pointer_vars(all_stmts)

        # DEBUG: показать, что проверка program body началась
        print("[DEBUG] Checking program body")
        if heap_vars:
            print(f"[DEBUG]   Heap variables found: {[hv.name for hv in heap_vars]}")

        for path in paths:
            stmts_on_path = self._stmts_on_path(path)
            for hv in heap_vars:
                self._check_release(hv, stmts_on_path, path)
            for pv in ptr_vars:
                self._check_null(pv, stmts_on_path)
            for hv in heap_vars:
                self._check_use_after_free(hv, stmts_on_path)

        # Narrow point 4 — lifetime
        self.violations.extend(_run_lifetime(all_stmts, is_func=False))

    # ── Narrow point 1: Release ───────────────────────────────────────────────

    def _check_release(
        self,
        hv: HeapVar,
        stmts: list,
        path: list[BasicBlock],
    ) -> None:
        """Every path to an exit must release the heap variable.
        Section 2.3: transferring with 'as owner' counts as release —
        the callee takes responsibility."""
        # Check if path ends at an exit
        last = path[-1]
        if last.kind != BlockKind.EXIT:
            return   # path doesn't reach exit (loop back-edge path)

        from ..parser.ast import OwnershipMode
        released = False
        for stmt in stmts:
            # Explicit release
            if isinstance(stmt, A.ReleaseStmt) and stmt.name == hv.name:
                released = True
                break
            # Transfer as owner in a call — callee takes ownership
            if isinstance(stmt, A.CallStmt):
                for arg_name, arg_mode, arg_expr in stmt.args:
                    if (arg_mode == OwnershipMode.OWNER and
                            isinstance(arg_expr, A.Identifier) and
                            arg_expr.name == hv.name):
                        released = True
                        break
            if released:
                break

        if not released:
            # Is this path a reject path?
            is_reject_path = any(
                isinstance(s, A.RejectStmt) for s in stmts
            )
            hint = (
                f"Add 'release {hv.name}' before the 'reject' statement"
                if is_reject_path
                else f"Add 'release {hv.name}' before the function exits"
            )
            self.violations.append(LevelViolation(
                kind="release",
                message=f"Missing release for heap variable '{hv.name}'",
                detail=(
                    f"'{hv.name}' is declared on heap but not released on "
                    f"{'the error path' if is_reject_path else 'all paths'}. "
                    f"Every heap variable must be released on every path through "
                    f"the function — including error paths."
                ),
                hint=hint,
                span=hv.span,
            ))

    # ── Narrow point 2: Null check ────────────────────────────────────────────

    def _check_null(self, ptr_name: str, stmts: list) -> None:
        """
        Every 'value at <ptr>' must be preceded by a null check
        on the same path.
        """
        null_checked = False
        for stmt in stmts:
            # A null check is: if ptr is not null ...
            if self._is_null_check_for(stmt, ptr_name):
                null_checked = True
            # A dereference without prior null check is a violation
            if self._dereferences(stmt, ptr_name) and not null_checked:
                self.violations.append(LevelViolation(
                    kind="null",
                    message=f"Missing null check before 'value at {ptr_name}'",
                    detail=(
                        f"Pointer '{ptr_name}' is dereferenced without a prior "
                        f"null check on this path. "
                        f"In C*, every pointer dereference must be preceded by "
                        f"'if {ptr_name} is not null' on all incoming paths."
                    ),
                    hint=(
                        f"Wrap the dereference:\n"
                        f"    if {ptr_name} is not null\n"
                        f"        value at {ptr_name} is ...\n"
                        f"    end if"
                    ),
                    span=A.Span(0, 0),
                ))

    # ── Narrow point 3: Use after free ────────────────────────────────────────

    def _check_use_after_free(self, hv: HeapVar, stmts: list) -> None:
        """After release, the variable must not be used."""
        released = False
        for stmt in stmts:
            if isinstance(stmt, A.ReleaseStmt) and stmt.name == hv.name:
                released = True
                continue
            if released and self._uses_var(stmt, hv.name):
                self.violations.append(LevelViolation(
                    kind="owner",
                    message=f"Use of '{hv.name}' after release",
                    detail=(
                        f"'{hv.name}' is used after being released. "
                        f"After 'release {hv.name}' the variable no longer "
                        f"has an owner and cannot be accessed."
                    ),
                    hint=(
                        f"Move the use of '{hv.name}' before 'release {hv.name}', "
                        f"or remove the use entirely."
                    ),
                    span=hv.span,
                ))
                break

    # ── Collection helpers ────────────────────────────────────────────────────

    def _collect_heap_vars(self, stmts) -> list[HeapVar]:
        """Find all variables declared with location == 'heap'."""
        heap_vars = []
        for stmt in self._all_stmts_deep(stmts):
            if isinstance(stmt, A.DeclareStmt) and stmt.location == "heap":
                hv = HeapVar(name=stmt.name, span=stmt.span)
                heap_vars.append(hv)
                # DEBUG: выводим каждую найденную heap-переменную
                print(f"[DEBUG]     Heap var detected: '{hv.name}' at span {hv.span}")
        return heap_vars

    def _collect_pointer_vars(self, stmts) -> list[str]:
        """Find all pointer variable names."""
        ptrs = []
        for stmt in self._all_stmts_deep(stmts):
            if isinstance(stmt, A.DeclareStmt):
                ct = ast_type_to_ctype(stmt.type_node)
                if ct.kind == "pointer":
                    ptrs.append(stmt.name)
        return ptrs

    def _all_stmts_deep(self, stmts) -> list:
        """Flatten all statements including inside if/repeat/call bodies."""
        result = []
        for stmt in stmts:
            result.append(stmt)
            if isinstance(stmt, A.IfStmt):
                result.extend(self._all_stmts_deep(stmt.then_body))
                for _, body in stmt.elseif_branches:
                    result.extend(self._all_stmts_deep(body))
                if stmt.else_body:
                    result.extend(self._all_stmts_deep(stmt.else_body))
            elif isinstance(stmt, A.RepeatStmt):
                result.extend(self._all_stmts_deep(stmt.body))
            elif isinstance(stmt, A.CallStmt):
                for h in stmt.handlers:
                    result.extend(self._all_stmts_deep(h.body))
        return result

    def _stmts_on_path(self, path: list[BasicBlock]) -> list:
        """Collect all statements along a CFG path in order."""
        stmts = []
        for block in path:
            stmts.extend(block.stmts)
        return stmts

    # ── AST pattern matchers ──────────────────────────────────────────────────

    def _is_null_check_for(self, stmt, ptr_name: str) -> bool:
        """Does this statement perform a null check for ptr_name?"""
        if isinstance(stmt, A.IfStmt):
            cond = stmt.condition
            if isinstance(cond, A.CompareOp):
                if cond.op in ("is not null", "is null"):
                    if isinstance(cond.left, A.Identifier):
                        return cond.left.name == ptr_name
        return False

    def _dereferences(self, stmt, ptr_name: str) -> bool:
        """Does this statement dereference ptr_name via 'value at'?"""
        return self._expr_dereferences(self._stmt_exprs(stmt), ptr_name)

    def _expr_dereferences(self, exprs: list, ptr_name: str) -> bool:
        for expr in exprs:
            if isinstance(expr, A.ValueAt):
                if isinstance(expr.pointer, A.Identifier):
                    if expr.pointer.name == ptr_name:
                        return True
        return False

    def _uses_var(self, stmt, name: str) -> bool:
        """Does this statement read or write the named variable?"""
        for expr in self._stmt_exprs(stmt):
            if isinstance(expr, A.Identifier) and expr.name == name:
                return True
        if isinstance(stmt, A.AssignStmt):
            if isinstance(stmt.target, A.Identifier):
                if stmt.target.name == name:
                    return True
        return False

    def _stmt_exprs(self, stmt) -> list:
        """Extract all expressions from a statement (shallow)."""
        if isinstance(stmt, A.DeclareStmt):
            return [stmt.initial_value]
        if isinstance(stmt, A.AssignStmt):
            return [stmt.value, stmt.target]
        if isinstance(stmt, A.IfStmt):
            return [stmt.condition]
        if isinstance(stmt, A.RepeatStmt):
            return [stmt.condition]
        if isinstance(stmt, A.ReturnStmt) and stmt.value:
            return [stmt.value]
        if isinstance(stmt, A.CallStmt):
            return [v for _, __, v in stmt.args]
        if isinstance(stmt, A.SimpleCallStmt):
            return list(stmt.args)
        return []


# ── Integration point for LifetimeAnalyzer ───────────────────────────────────
# (imported here to avoid circular import — checker imports ast, lifetime imports checker)

def _run_lifetime(func_or_stmts, is_func: bool = True):
    from .lifetime import LifetimeAnalyzer
    la = LifetimeAnalyzer()
    if is_func:
        return la.analyze_function(func_or_stmts)
    return la.analyze_stmts(func_or_stmts)