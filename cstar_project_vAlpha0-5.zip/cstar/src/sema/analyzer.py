"""
C* Compiler — Semantic Analyzer
Walks the AST and enforces the language's static rules.

Checks performed (Phase 1 — core):
  ✓ Variables declared before use
  ✓ No re-declaration in the same scope
  ✓ Constants not reassigned
  ✓ Type compatibility in assignments and arithmetic
  ✓ call blocks have at least one on error + one on success
  ✓ reject only inside functions that declare the error
  ✓ stop/skip only inside repeat blocks
  ✓ Empty blocks must contain a comment (warned, not errored here)
  ✓ Function return variable assigned on all paths (basic)
  ✓ Undeclared function calls flagged
  ✓ Struct field access and method call type checking (Phase 2)
  ✓ Direct field access inside struct methods (Phase 2)
  ✓ Ownership transfer and dead variable checks
  ✓ Range constraints for user-defined integer types (Phase 3)
  ✓ Memory allocation forbidden in interrupt handlers (Phase 5)
  ✓ Hardware register declaration and access rights (Phase 6)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Union

from ..parser import ast as A
from ..lexer.token import Span


# ── Diagnostic ────────────────────────────────────────────────────────────────

@dataclass
class Diagnostic:
    kind: str          # "error" | "warning"
    message: str
    span: A.Span

    def __str__(self) -> str:
        return f"[{self.span}] {self.kind.upper()}: {self.message}"


# ── Type representation ───────────────────────────────────────────────────────

@dataclass(frozen=True)
class CType:
    """Canonical type used during semantic analysis."""
    kind: str          # "integer"|"float"|"byte"|"boolean"|"text"|
                       # "pointer"|"nothing"|"named"|"array"|"unknown"
    signed: bool = True
    bits: int = 32
    inner: Optional["CType"] = None   # for pointer
    name: str = ""                     # for named types
    min_val: Optional[int] = None      # lower bound for range‑constrained types
    max_val: Optional[int] = None      # upper bound for range‑constrained types

    def __str__(self) -> str:
        if self.kind == "integer":
            s = "signed" if self.signed else "unsigned"
            return f"integer[{s}, {self.bits}bit]"
        if self.kind == "float":
            return f"float[{self.bits}bit]"
        if self.kind == "pointer":
            return f"pointer[to {self.inner}]"
        if self.kind == "named":
            return self.name
        if self.kind == "array":
            return f"array[{self.bits}]"
        return self.kind

    def is_numeric(self) -> bool:
        return self.kind in ("integer", "float", "byte")

    def is_comparable(self, other: "CType") -> bool:
        """Can self be compared with other?"""
        if self.kind == "unknown" or other.kind == "unknown":
            return True
        if self.kind == other.kind == "integer":
            return True
        if self.kind == other.kind == "float":
            return True
        if self.kind == other.kind == "boolean":
            return True
        if self.kind == other.kind == "text":
            return True
        if self.kind == other.kind == "byte":
            return True
        if "pointer" in (self.kind, other.kind):
            return True
        if self.kind == other.kind == "named":
            return self.name == other.name
        if self.is_numeric() and other.is_numeric():
            return True
        return False

    def is_assignable_from(self, other: "CType") -> bool:
        if self.kind == "unknown" or other.kind == "unknown":
            return True
        if self == other:
            return True
        # Allow array initialisation with a number (Section 4.2)
        if self.kind == "array" and other.is_numeric():
            return True
        # Allow struct (named) initialisation with a number (Section 4.1)
        if self.kind == "named" and other.is_numeric():
            return True
        # null → any pointer
        if self.kind == "pointer" and other.kind == "nothing":
            return True
        # numeric widening (relaxed – full check needs value‑range analysis)
        if self.is_numeric() and other.is_numeric():
            return True
        return False


# Singletons for common types
T_UNKNOWN  = CType("unknown")
T_NOTHING  = CType("nothing")
T_BOOL     = CType("boolean")
T_BYTE     = CType("byte")
T_TEXT     = CType("text")
T_INT32    = CType("integer", signed=True,  bits=32)
T_UINT32   = CType("integer", signed=False, bits=32)
T_INT64    = CType("integer", signed=True,  bits=64)
T_FLOAT64  = CType("float",   bits=64)


def ast_type_to_ctype(node: A.TypeNode) -> CType:
    if isinstance(node, A.IntegerType):
        return CType("integer", signed=node.signed, bits=node.bits)
    if isinstance(node, A.ArrayType):
        return CType("array", bits=node.size)
    if isinstance(node, A.FloatType):
        return CType("float", bits=node.bits)
    if isinstance(node, A.ByteType):
        return T_BYTE
    if isinstance(node, A.BooleanType):
        return T_BOOL
    if isinstance(node, A.TextType):
        return T_TEXT
    if isinstance(node, A.NothingType):
        return T_NOTHING
    if isinstance(node, A.PointerType):
        return CType("pointer", inner=ast_type_to_ctype(node.inner))
    if isinstance(node, A.NamedType):
        return CType("named", name=node.name)
    return T_UNKNOWN


# ── Symbol table ──────────────────────────────────────────────────────────────

@dataclass
class Symbol:
    name: str
    ctype: CType
    is_constant: bool
    span: A.Span
    assigned: bool = False
    is_dead: bool = False
    owner_transferred_at: Optional[A.Span] = None


class Scope:
    def __init__(self, parent: Optional["Scope"] = None) -> None:
        self._symbols: dict[str, Symbol] = {}
        self.parent = parent

    def declare(self, sym: Symbol) -> bool:
        if sym.name in self._symbols:
            return False
        self._symbols[sym.name] = sym
        return True

    def lookup(self, name: str) -> Optional[Symbol]:
        if name in self._symbols:
            return self._symbols[name]
        if self.parent:
            return self.parent.lookup(name)
        return None

    def child(self) -> "Scope":
        return Scope(parent=self)


# ── Function registry ─────────────────────────────────────────────────────────

@dataclass
class FuncSignature:
    name: str
    params: list[tuple[str, CType]]
    return_type: CType
    declared_errors: set[str]
    span: A.Span


# ── Analyzer ──────────────────────────────────────────────────────────────────

class SemanticError(Exception):
    pass


class Analyzer:
    def __init__(self) -> None:
        self.diagnostics: list[Diagnostic] = []
        self._funcs: dict[str, FuncSignature] = {}
        self._user_types: dict[str, CType] = {}               # alias‑defined types
        self._structs: dict[str, dict[str, CType]] = {}
        self._struct_ops: dict[str, dict[str, FuncSignature]] = {}
        self._hw_regs: dict[str, A.HardwareRegisterDef] = {}   # hardware registers
        self._loop_depth: int = 0
        self._current_func: Optional[FuncSignature] = None
        self._in_interrupt_context = False

    # ── Public API ────────────────────────────────────────────────────────────

    def analyze_program(self, program: A.Node) -> list[Diagnostic]:
        self.diagnostics = []
        global_scope = Scope()
        self._register_builtins()

        # --- ДИАГНОСТИКА ---
        # Проверим, получил ли анализатор список регистров от парсера
        print(f"[DEBUG] Registers in AST: {[r.name for r in program.hardware_registers] if hasattr(program, 'hardware_registers') else 'N/A'}")
        
        self._hw_regs = {}
        if hasattr(program, 'hardware_registers'):
            for reg in program.hardware_registers:
                self._hw_regs[reg.name] = reg
        
        print(f"[DEBUG] Internal map filled: {list(self._hw_regs.keys())}")
        # -------------------

        # 1. Регистрируем все функции
        for func in program.functions:
            self._register_function(func)

        # 2. Анализируем обработчики прерываний
        if hasattr(program, 'interrupt_handlers'):
            for handler in program.interrupt_handlers:
                self._analyze_interrupt_handler(handler, global_scope)

        # 3. Анализируем обычные функции
        for func in program.functions:
            self._analyze_function(func, global_scope)

        self._analyze_stmts(program.body, global_scope)
        return self.diagnostics

    def analyze_module(self, module: A.ModuleDef) -> list[Diagnostic]:
        return self.analyze_program(module)

    @property
    def has_errors(self) -> bool:
        return any(d.kind == "error" for d in self.diagnostics)

    # ── Registration ──────────────────────────────────────────────────────────

    def _register_builtins(self) -> None:
        nothing  = CType("nothing")
        int32    = CType("integer", signed=True,  bits=32)
        uint32   = CType("integer", signed=False, bits=32)
        float64  = CType("float",   bits=64)
        text     = CType("text")
        boolean  = CType("boolean")
        dummy    = A.Span(0, 0)
        builtins = {
            "print_integer":  ([("value", int32)],   nothing),
            "print_unsigned": ([("value", uint32)],  nothing),
            "print_float":    ([("value", float64)], nothing),
            "print_text":     ([("value", text)],    nothing),
            "print_boolean":  ([("value", boolean)], nothing),
            "print_line":     ([],                   nothing),
        }
        for name, (params, ret) in builtins.items():
            sig = FuncSignature(name=name, params=params, return_type=ret,
                                declared_errors=set(), span=dummy)
            self._funcs[name] = sig

    def _register_function(self, func: A.FunctionDef) -> None:
        params = [(p.name, ast_type_to_ctype(p.type_node)) for p in func.params]
        errors = {g.error_name for g in func.guards}
        sig = FuncSignature(name=func.name, params=params,
                            return_type=ast_type_to_ctype(func.return_type),
                            declared_errors=errors, span=func.span)
        if func.name in self._funcs:
            self._error(f"Function '{func.name}' defined more than once", func.span)
        self._funcs[func.name] = sig

    # ── Function body ─────────────────────────────────────────────────────────

    def _analyze_function(self, func: A.FunctionDef, outer: Scope) -> None:
        prev = self._current_func
        self._current_func = self._funcs.get(func.name)
        scope = outer.child()
        for p in func.params:
            scope.declare(Symbol(p.name, ast_type_to_ctype(p.type_node), False, p.span, assigned=True))
        if func.return_name:
            scope.declare(Symbol(func.return_name,
                                ast_type_to_ctype(func.return_type),
                                False, func.span, assigned=False))
        self._analyze_stmts(func.body, scope)
        self._current_func = prev

    # ── Struct operation analysis ─────────────────────────────────────────────

    def _analyze_operation(self, op: A.OperationDef, struct_name: str, outer: Scope) -> None:
        scope = outer.child()
        if op.return_name:
            scope.declare(Symbol(op.return_name, ast_type_to_ctype(op.return_type),
                                 False, op.span, assigned=False))
        for p in op.params:
            scope.declare(Symbol(p.name, ast_type_to_ctype(p.type_node), False, p.span, assigned=True))
        fields = self._structs.get(struct_name, {})
        for f_name, f_type in fields.items():
            scope.declare(Symbol(f_name, f_type, False, op.span, assigned=True))
        self._analyze_stmts(op.body, scope)

    # ── Interrupt handler analysis ────────────────────────────────────────────

    def _analyze_interrupt_handler(self, handler: A.InterruptHandlerDef, scope: Scope) -> None:
        old_context = self._in_interrupt_context
        self._in_interrupt_context = True
        self._analyze_stmts(handler.body, scope.child())
        self._in_interrupt_context = old_context

    # ── Statement dispatch ────────────────────────────────────────────────────

    def _analyze_stmts(self, stmts: list, scope: Scope) -> None:
        for stmt in stmts:
            self._analyze_stmt(stmt, scope)

    def _analyze_stmt(self, stmt, scope: Scope) -> None:
        if isinstance(stmt, A.DeclareStmt):
            self._chk_declare(stmt, scope)
        elif isinstance(stmt, A.AssignStmt):
            self._chk_assign(stmt, scope)
        elif isinstance(stmt, A.IfStmt):
            self._chk_if(stmt, scope)
        elif isinstance(stmt, A.RepeatStmt):
            self._chk_repeat(stmt, scope)
        elif isinstance(stmt, A.CallStmt):
            self._chk_call(stmt, scope)
        elif isinstance(stmt, A.SimpleCallStmt):
            self._chk_simple_call(stmt, scope)
        elif isinstance(stmt, A.RejectStmt):
            self._chk_reject(stmt, scope)
        elif isinstance(stmt, A.StopStmt):
            self._chk_stop(stmt)
        elif isinstance(stmt, A.SkipStmt):
            self._chk_skip(stmt)
        elif isinstance(stmt, A.ReturnStmt):
            self._chk_return(stmt, scope)
        elif isinstance(stmt, A.AllocateStmt):
            self._chk_allocate(stmt, scope)
        elif isinstance(stmt, A.ReleaseStmt):
            self._chk_release(stmt, scope)
        elif isinstance(stmt, A.MethodCallExpr):
            self._chk_method_call(stmt, scope)
        elif isinstance(stmt, A.HardwareWriteStmt):
            self._chk_hw_write(stmt)

    # ── Declare ───────────────────────────────────────────────────────────────

    def _chk_declare(self, stmt: A.DeclareStmt, scope: Scope) -> None:
        ctype = ast_type_to_ctype(stmt.type_node)
        if ctype.kind == "named" and ctype.name in self._user_types:
            ctype = self._user_types[ctype.name]

        val_type = self._infer_expr(stmt.initial_value, scope)
        if not ctype.is_assignable_from(val_type):
            self._error(
                f"Type Mismatch: Cannot initialize '{stmt.name}' of type {ctype} "
                f"with value of type {val_type}",
                stmt.span,
            )
        self._check_range_violation(ctype, stmt.initial_value)

        sym = Symbol(name=stmt.name, ctype=ctype, is_constant=stmt.is_constant,
                     span=stmt.span, assigned=True)
        if not scope.declare(sym):
            self._error(f"'{stmt.name}' is already declared in this scope", stmt.span)

    # ── Assign ────────────────────────────────────────────────────────────────

    def _chk_assign(self, stmt: A.AssignStmt, scope: Scope) -> None:
        val_type = self._infer_expr(stmt.value, scope)

        if isinstance(stmt.target, A.Identifier):
            sym = scope.lookup(stmt.target.name)
            if sym is None:
                self._error(f"'{stmt.target.name}' is not declared", stmt.target.span)
                return
            if sym.is_dead:
                self._error(f"OWNERSHIP VIOLATION: '{sym.name}' was already transferred as owner", stmt.span)
                return
            if sym.is_constant:
                self._error(f"'{sym.name}' is constant and cannot be reassigned", stmt.span)
                return
            if not sym.ctype.is_assignable_from(val_type):
                self._error(
                    f"Type Mismatch: Cannot assign {val_type} to '{sym.name}' of type {sym.ctype}",
                    stmt.span,
                )
            self._check_range_violation(sym.ctype, stmt.value)
            sym.assigned = True

        elif isinstance(stmt.target, A.FieldAccess):
            self._infer_expr(stmt.target, scope)
        elif isinstance(stmt.target, A.ValueAt):
            self._infer_expr(stmt.target.pointer, scope)

    # ── Range checking helper ─────────────────────────────────────────────────

    def _check_range_violation(self, target_ctype: CType, value_expr: A.ExprNode) -> None:
        if target_ctype.min_val is not None and isinstance(value_expr, A.IntLiteral):
            val = value_expr.value
            if val < target_ctype.min_val or val > target_ctype.max_val:
                self._error(
                    f"RANGE VIOLATION: Value {val} is outside of valid range "
                    f"[{target_ctype.min_val} to {target_ctype.max_val}] for type {target_ctype.name}",
                    value_expr.span,
                )

    # ── If ────────────────────────────────────────────────────────────────────

    def _chk_if(self, stmt: A.IfStmt, scope: Scope) -> None:
        self._infer_expr(stmt.condition, scope)
        self._analyze_stmts(stmt.then_body, scope.child())
        for cond, body in stmt.elseif_branches:
            self._infer_expr(cond, scope)
            self._analyze_stmts(body, scope.child())
        if stmt.else_body is not None:
            self._analyze_stmts(stmt.else_body, scope.child())

    # ── Repeat ────────────────────────────────────────────────────────────────

    def _chk_repeat(self, stmt: A.RepeatStmt, scope: Scope) -> None:
        self._infer_expr(stmt.condition, scope)
        self._loop_depth += 1
        self._analyze_stmts(stmt.body, scope.child())
        self._loop_depth -= 1

    # ── Call (block) ──────────────────────────────────────────────────────────

    def _chk_call(self, stmt: A.CallStmt, scope: Scope) -> None:
        from ..parser.ast import OwnershipMode
        sig = self._funcs.get(stmt.func_name)
        if sig is None:
            self._error(f"Unknown function '{stmt.func_name}'", stmt.span)
        else:
            provided = {name for name, _, __ in stmt.args}
            expected = {name for name, _ in sig.params}
            for missing in expected - provided:
                self._error(f"Call to '{stmt.func_name}' missing argument '{missing}'", stmt.span)
            for extra in provided - expected:
                self._error(f"Call to '{stmt.func_name}' has unexpected argument '{extra}'", stmt.span)
            param_map = dict(sig.params)
            for arg_name, arg_mode, arg_expr in stmt.args:
                if arg_name in param_map:
                    arg_type = self._infer_expr(arg_expr, scope)
                    expected_type = param_map[arg_name]
                    if not expected_type.is_assignable_from(arg_type):
                        self._error(
                            f"Argument '{arg_name}' expects {expected_type} "
                            f"but got {arg_type}",
                            arg_expr.span,
                        )

        for arg_name, arg_mode, arg_expr in stmt.args:
            if arg_mode == OwnershipMode.OWNER:
                if isinstance(arg_expr, A.Identifier):
                    sym = scope.lookup(arg_expr.name)
                    if sym:
                        if sym.is_dead:
                            self._error(f"OWNERSHIP VIOLATION: '{sym.name}' was already transferred as owner", arg_expr.span)
                        sym.is_dead = True
                        sym.owner_transferred_at = stmt.span

        handler_kinds = [h.kind for h in stmt.handlers]
        if "success" not in handler_kinds:
            self._error(f"Call to '{stmt.func_name}' is missing 'on success' handler", stmt.span)
        error_handlers = [h for h in stmt.handlers if h.kind == "error"]
        if sig and sig.declared_errors and not error_handlers:
            self._error(
                f"Call to '{stmt.func_name}' is missing 'on error' handler(s) "
                f"— function can raise: {', '.join(sig.declared_errors)}",
                stmt.span,
            )
        for handler in stmt.handlers:
            self._analyze_stmts(handler.body, scope.child())

    # ── Simple call ───────────────────────────────────────────────────────────

    def _chk_simple_call(self, stmt: A.SimpleCallStmt, scope: Scope) -> None:
        sig = self._funcs.get(stmt.func_name)
        if sig is None:
            self._warning(f"Function '{stmt.func_name}' not found in current scope (may be defined in another module)", stmt.span)
            return
        if sig.return_type.kind != "nothing":
            self._error(
                f"'{stmt.func_name}' returns {sig.return_type} — "
                f"use 'call ... on success' syntax to capture the return value",
                stmt.span,
            )
        if len(stmt.args) != len(sig.params):
            self._error(f"'{stmt.func_name}' expects {len(sig.params)} argument(s), got {len(stmt.args)}", stmt.span)
        for expr in stmt.args:
            self._infer_expr(expr, scope)

    # ── Method call (statement) ───────────────────────────────────────────────

    def _chk_method_call(self, stmt: A.MethodCallStmt, scope: Scope) -> None:
        obj_type = self._infer_expr(stmt.obj, scope)
        if obj_type.kind != "named":
            self._error(f"Method call on non-struct type {obj_type}", stmt.span)
            return
        struct_name = obj_type.name
        ops = self._struct_ops.get(struct_name, {})
        sig = ops.get(stmt.method_name)
        if sig is None:
            self._error(f"Struct '{struct_name}' has no operation '{stmt.method_name}'", stmt.span)
            return
        if len(stmt.args) != len(sig.params):
            self._error(f"'{stmt.method_name}' expects {len(sig.params)} argument(s), got {len(stmt.args)}", stmt.span)
        for a in stmt.args:
            self._infer_expr(a, scope)
        if sig.return_type.kind != "nothing":
            self._error(
                f"'{stmt.method_name}' returns {sig.return_type} — "
                f"use 'call ... on success' syntax to capture the return value",
                stmt.span,
            )

    # ── Reject ────────────────────────────────────────────────────────────────

    def _chk_reject(self, stmt: A.RejectStmt, scope: Scope) -> None:
        if self._current_func is None:
            self._error("'reject' used outside a function", stmt.span)
            return
        if stmt.error_name not in self._current_func.declared_errors:
            self._error(
                f"Error '{stmt.error_name}' not declared in function "
                f"'{self._current_func.name}' — add 'on {stmt.error_name} "
                f"reject with error[{stmt.error_name}]' to the function header",
                stmt.span,
            )

    # ── Stop / Skip ───────────────────────────────────────────────────────────

    def _chk_stop(self, stmt: A.StopStmt) -> None:
        if self._loop_depth == 0:
            self._error("'stop' used outside a 'repeat while' block", stmt.span)

    def _chk_skip(self, stmt: A.SkipStmt) -> None:
        if self._loop_depth == 0:
            self._error("'skip' used outside a 'repeat while' block", stmt.span)

    # ── Return ────────────────────────────────────────────────────────────────

    def _chk_return(self, stmt: A.ReturnStmt, scope: Scope) -> None:
        if stmt.value is not None:
            self._infer_expr(stmt.value, scope)

    # ── Allocate / Release ────────────────────────────────────────────────────

    def _chk_allocate(self, stmt: A.AllocateStmt, scope: Scope) -> None:
        if self._in_interrupt_context:
            self._error(
                "FORBIDDEN OPERATION: Memory allocation is forbidden inside interrupt handlers (Section 5.3)",
                stmt.span
            )
            return
        self._infer_expr(stmt.size, scope)
        sym = scope.lookup(stmt.name)
        if sym is None:
            self._error(f"'{stmt.name}' is not declared", stmt.span)
        elif sym.ctype.kind != "pointer":
            self._error(f"'allocate' target '{stmt.name}' must be a pointer type, got {sym.ctype}", stmt.span)

    def _chk_release(self, stmt: A.ReleaseStmt, scope: Scope) -> None:
        sym = scope.lookup(stmt.name)
        if sym is None:
            self._error(f"'{stmt.name}' is not declared", stmt.span)
        elif sym.ctype.kind not in ("pointer", "array"):
            self._error(f"'release' target '{stmt.name}' must be a pointer or array type, got {sym.ctype}", stmt.span)

    # ── Hardware write check ──────────────────────────────────────────────────

    def _chk_hw_write(self, stmt: A.HardwareWriteStmt) -> None:
        reg = self._hw_regs.get(stmt.reg_name)
        if reg is None:
            self._error(f"Unknown hardware register '{stmt.reg_name}'", stmt.span)
            return
        if "write" not in reg.access:
            self._error(
                f"HARDWARE VIOLATION: Register '{stmt.reg_name}' is read-only",
                stmt.span,
            )

    # ── Expression inference ──────────────────────────────────────────────────

    def _infer_expr(self, expr, scope: Scope) -> CType:
        if isinstance(expr, A.IntLiteral):
            return T_INT32
        if isinstance(expr, A.FloatLiteral):
            return T_FLOAT64
        if isinstance(expr, A.BoolLiteral):
            return T_BOOL
        if isinstance(expr, A.TextLiteral):
            return T_TEXT
        if isinstance(expr, A.NullLiteral):
            return T_NOTHING

        if isinstance(expr, A.Identifier):
            sym = scope.lookup(expr.name)
            if sym is None:
                self._error(f"'{expr.name}' is not declared", expr.span)
                return T_UNKNOWN
            if sym.is_dead:
                self._error(
                    f"OWNERSHIP VIOLATION: Variable '{expr.name}' no longer exists. "
                    f"It was transferred as owner at line {sym.owner_transferred_at}",
                    expr.span,
                )
                return T_UNKNOWN
            ctype = sym.ctype
            if ctype.kind == "named" and ctype.name in self._user_types:
                ctype = self._user_types[ctype.name]
            return ctype

        if isinstance(expr, A.FieldAccess):
            obj_type = self._infer_expr(expr.obj, scope)
            if obj_type.kind == "named":
                field_map = self._structs.get(obj_type.name, {})
                if expr.field in field_map:
                    return field_map[expr.field]
                else:
                    self._error(f"Struct '{obj_type.name}' has no field '{expr.field}'", expr.span)
            elif obj_type.kind != "unknown":
                self._warning(f"Field access on non-struct type {obj_type}", expr.span)
            return T_UNKNOWN

        if isinstance(expr, A.MethodCallExpr):
            obj_type = self._infer_expr(expr.obj, scope)
            if obj_type.kind == "named":
                struct_name = obj_type.name
                ops = self._struct_ops.get(struct_name, {})
                sig = ops.get(expr.method)
                if sig is None:
                    self._error(f"Struct '{struct_name}' has no operation '{expr.method}'", expr.span)
                    return T_UNKNOWN
                if len(expr.args) != len(sig.params):
                    self._error(f"'{expr.method}' expects {len(sig.params)} argument(s), got {len(expr.args)}", expr.span)
                for a in expr.args:
                    self._infer_expr(a, scope)
                return sig.return_type
            else:
                self._error(f"Type {obj_type} does not support methods", expr.span)
                return T_UNKNOWN

        if isinstance(expr, A.BinaryOp):
            left  = self._infer_expr(expr.left,  scope)
            right = self._infer_expr(expr.right, scope)
            if not (left.is_numeric() or left.kind == "unknown") or \
               not (right.is_numeric() or right.kind == "unknown"):
                self._error(f"Arithmetic '{expr.op}' requires numeric operands, got {left} and {right}", expr.span)
            return left if left.kind != "unknown" else right

        if isinstance(expr, A.CompareOp):
            left  = self._infer_expr(expr.left,  scope)
            right = self._infer_expr(expr.right, scope)
            if not left.is_comparable(right):
                self._error(f"Cannot compare {left} with {right}", expr.span)
            return T_BOOL

        if isinstance(expr, A.LogicOp):
            left  = self._infer_expr(expr.left,  scope)
            right = self._infer_expr(expr.right, scope)
            for t, side in ((left, "left"), (right, "right")):
                if t.kind not in ("boolean", "unknown"):
                    self._error(f"'{expr.op}' requires boolean operands, {side} side is {t}", expr.span)
            return T_BOOL

        if isinstance(expr, A.NotOp):
            t = self._infer_expr(expr.operand, scope)
            if t.kind not in ("boolean", "unknown"):
                self._error(f"'not' requires a boolean operand, got {t}", expr.span)
            return T_BOOL

        if isinstance(expr, A.AddressOf):
            from ..parser.ast import OwnershipMode
            sym = scope.lookup(expr.name)
            if sym is None:
                self._error(f"'{expr.name}' is not declared", expr.span)
                return T_UNKNOWN
            if sym.is_dead:
                self._error(f"OWNERSHIP VIOLATION: '{sym.name}' was already transferred as owner", expr.span)
                return T_UNKNOWN
            if expr.mode == OwnershipMode.OWNER:
                sym.is_dead = True
                sym.owner_transferred_at = expr.span
            return CType("pointer", inner=sym.ctype)

        if isinstance(expr, A.ValueAt):
            ptr_type = self._infer_expr(expr.pointer, scope)
            if ptr_type.kind == "pointer" and ptr_type.inner:
                return ptr_type.inner
            if ptr_type.kind != "unknown":
                self._error(f"'value at' requires a pointer, got {ptr_type}", expr.span)
            return T_UNKNOWN

        if isinstance(expr, A.SizeOf):
            return T_UINT32

        if isinstance(expr, A.ConvertExpr):
            self._infer_expr(expr.value, scope)
            return ast_type_to_ctype(expr.target_type)

        if isinstance(expr, A.CallExpr):
            sig = self._funcs.get(expr.func_name)
            if sig is None:
                self._error(f"Function '{expr.func_name}' is not declared", expr.span)
                return T_UNKNOWN
            if len(expr.args) != len(sig.params):
                self._error(f"'{expr.func_name}' expects {len(sig.params)} args, got {len(expr.args)}", expr.span)
            return sig.return_type

        return T_UNKNOWN

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _error(self, message: str, span: A.Span) -> None:
        self.diagnostics.append(Diagnostic("error", message, span))

    def _warning(self, message: str, span: A.Span) -> None:
        self.diagnostics.append(Diagnostic("warning", message, span))
