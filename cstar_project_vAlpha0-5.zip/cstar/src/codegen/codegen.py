"""
C* Compiler — LLVM IR Code Generator
Walks a semantically-verified AST and emits LLVM IR text.

Conventions
───────────
• Each C* function → one LLVM function.
• Variables live on the stack (alloca); SSA values used for temporaries.
• Strings are global constants (@str.N).
• Errors propagate via a hidden i8 return slot + out-parameter pattern:
    every function that can reject returns  { i8 error_code, <real_type> }
    via a sret pointer — kept simple for Phase 1.
• Phase 1 scope: integer, float, boolean, byte, text (pointer to i8),
  pointer types, basic arithmetic, comparisons, if/repeat, calls,
  bitwise operations, shifts, structure field access, method calls,
  range checking for narrow integer conversions, interrupt handlers,
  volatile hardware access.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Set, Dict
import textwrap

from ..parser import ast as A
from ..sema.analyzer import CType, ast_type_to_ctype, T_BOOL, T_NOTHING


# ── LLVM type mapping ─────────────────────────────────────────────────────────

def llvm_type(ct: CType) -> str:
    if ct.kind == "integer":
        return f"i{ct.bits}"
    if ct.kind == "float":
        return "float" if ct.bits == 32 else "double"
    if ct.kind == "byte":
        return "i8"
    if ct.kind == "boolean":
        return "i1"
    if ct.kind == "text":
        return "ptr"          # pointer to i8 string constant
    if ct.kind == "pointer":
        return "ptr"          # opaque pointer (LLVM 15+)
    if ct.kind == "nothing":
        return "void"
    if ct.kind == "named":
        return f"%struct.{ct.name}"   # пользовательские структуры
    if ct.kind == "array":
        if getattr(ct, 'heap', False):
            return "ptr"
        return f"[{ct.bits} x i32]"
    return "i64"              # fallback


def llvm_zero(ct: CType) -> str:
    if ct.kind in ("integer", "byte", "boolean"):
        return "0"
    if ct.kind == "float":
        return "0.0"
    if ct.kind in ("pointer", "text"):
        return "null"
    return "0"


# ── Code generator ────────────────────────────────────────────────────────────

class CodegenError(Exception):
    pass


@dataclass
class Codegen:
    _lines: list[str]          = field(default_factory=list)
    _globals: list[str]        = field(default_factory=list)
    _tmp: int                  = 0
    _lbl: int                  = 0
    _str_count: int            = 0
    _str_cache: dict[str, str] = field(default_factory=dict)
    _vars: dict[str, tuple[str, CType]] = field(default_factory=dict)
    _scope_stack: list[dict[str, tuple[str, CType]]] = field(default_factory=list)
    _func_types: dict[str, tuple[list[CType], CType]] = field(default_factory=dict)
    _current_func_ret: Optional[CType] = None
    _current_func_name: str = ""
    _loop_end_labels: list[str] = field(default_factory=list)
    _loop_cond_labels: list[str] = field(default_factory=list)
    _heap_vars: Set[str]       = field(default_factory=set)
    _struct_types: dict[str, list[tuple[str, CType]]] = field(default_factory=dict)
    _struct_fields: dict[str, list[str]] = field(default_factory=dict)
    # Карта регистров для hardware access: имя -> объект регистра (из AST)
    _hw_registers: Dict[str, object] = field(default_factory=dict)

    # ── Public ────────────────────────────────────────────────────────────────

    def generate_program(self, prog: A.Node) -> str:
        # 1. Очищаем старые данные и счётчики
        self._globals = []
        self._lines = []
        self._tmp = 0
        self._lbl = 0

        # 2. Заполняем словарь регистров железа из AST (имя атрибута зависит от ast.py)
        if hasattr(prog, 'hardware_registers'):
            self._hw_registers = {reg.name: reg for reg in prog.hardware_registers}
        else:
            self._hw_registers = {}

        # 3. Генерируем заголовок LLVM (target triple должен быть первой строкой)
        self._emit_header()

        # 4. Регистрируем структуры и операции (методы)
        for td in prog.type_defs:
            if isinstance(td, A.StructDef):
                field_types = [llvm_type(ast_type_to_ctype(f.type_node)) for f in td.fields]
                self._globals.append(f"%struct.{td.name} = type {{ {', '.join(field_types)} }}")
                self._struct_fields[td.name] = [f.name for f in td.fields]
                for op in td.operations:
                    self._gen_operation(op, td.name)

        # 5. Регистрируем сигнатуры глобальных функций
        for f in prog.functions:
            param_types = [ast_type_to_ctype(p.type_node) for p in f.params]
            ret_type    = ast_type_to_ctype(f.return_type)
            self._func_types[f.name] = (param_types, ret_type)

        # 6. Генерируем код глобальных функций
        for f in prog.functions:
            self._gen_function(f)

        # 7. Генерируем обработчики прерываний
        for handler in getattr(prog, 'interrupt_handlers', []):
            self._gen_interrupt_handler(handler)

        # 8. Генерируем main только для ProgramDef
        if isinstance(prog, A.ProgramDef):
            self._gen_main(prog.body)

        return "\n".join(self._globals + [""] + self._lines)

    # ── Header ────────────────────────────────────────────────────────────────

    def _emit_header(self) -> None:
        self._globals.extend([
            "; C* compiled output",
            f'target triple = "aarch64-unknown-linux-android24"',
            "",
            "; External declarations",
            "declare i32 @printf(ptr, ...)",
            "declare ptr @malloc(i64)",
            "declare void @free(ptr)",
            "declare i32 @putchar(i32)",
            "",
            "; Format strings for builtins",
            '@fmt.int  = private unnamed_addr constant [4 x i8] c"%d\\0A\\00"',
            '@fmt.uint = private unnamed_addr constant [4 x i8] c"%u\\0A\\00"',
            '@fmt.flt  = private unnamed_addr constant [4 x i8] c"%f\\0A\\00"',
            '@fmt.str  = private unnamed_addr constant [4 x i8] c"%s\\0A\\00"',
            '@fmt.true = private unnamed_addr constant [6 x i8] c"true\\0A\\00"',
            '@fmt.fals = private unnamed_addr constant [7 x i8] c"false\\0A\\00"',
            "",
        ])
        T_INT32  = CType("integer", signed=True,  bits=32)
        T_UINT32 = CType("integer", signed=False, bits=32)
        T_FLOAT  = CType("float",   bits=64)
        T_TEXT   = CType("text")
        T_BOOL   = CType("boolean")
        T_NOTHING = CType("nothing")
        self._func_types.update({
            "print_integer":  ([T_INT32],   T_NOTHING),
            "print_unsigned": ([T_UINT32],  T_NOTHING),
            "print_float":    ([T_FLOAT],   T_NOTHING),
            "print_text":     ([T_TEXT],    T_NOTHING),
            "print_boolean":  ([T_BOOL],    T_NOTHING),
            "print_line":     ([],          T_NOTHING),
        })

    # ── Operation (method) generation ──────────────────────────────────────

    def _gen_operation(self, op: A.OperationDef, struct_name: str) -> None:
        llvm_name = f"{struct_name}_{op.name}"
        ret_ct = ast_type_to_ctype(op.return_type)

        param_list = ["ptr %self"]
        param_cts = [CType("named", name=struct_name)]
        for p in op.params:
            ct = ast_type_to_ctype(p.type_node)
            param_list.append(f"{llvm_type(ct)} %arg_{p.name}")
            param_cts.append(ct)

        self._emit(f"define {llvm_type(ret_ct)} @{llvm_name}({', '.join(param_list)}) {{")
        self._emit("entry:")
        self._push_scope()
        self._current_func_ret = ret_ct
        self._current_func_name = llvm_name

        if op.return_name:
            ret_alloca = self._alloca(llvm_type(ret_ct), op.return_name)
            self._scope()[op.return_name] = (ret_alloca, ret_ct)

        for p in op.params:
            ct = ast_type_to_ctype(p.type_node)
            lt = llvm_type(ct)
            alloca = self._alloca(lt, p.name)
            self._store(f"%arg_{p.name}", lt, alloca)
            self._scope()[p.name] = (alloca, ct)

        field_names = self._struct_fields.get(struct_name, [])
        for i, f_name in enumerate(field_names):
            tmp_ptr = self._new_tmp()
            self._emit(f"  {tmp_ptr} = getelementptr %struct.{struct_name}, ptr %self, i32 0, i32 {i}")
            self._scope()[f_name] = (tmp_ptr, CType("integer", bits=32))

        self._gen_stmts(op.body)

        if ret_ct.kind == "nothing":
            self._emit("  ret void")
        elif op.return_name:
            ret_val = self._load(llvm_type(ret_ct), ret_alloca)
            self._emit(f"  ret {llvm_type(ret_ct)} {ret_val}")
        else:
            self._emit(f"  ret {llvm_type(ret_ct)} {llvm_zero(ret_ct)}")

        self._pop_scope()
        self._emit("}\n")

    # ── Function ─────────────────────────────────────────────────────────────

    def _gen_function(self, func: A.FunctionDef) -> None:
        ret_ct   = ast_type_to_ctype(func.return_type)
        llvm_ret = llvm_type(ret_ct)

        params = []
        for p in func.params:
            ct = ast_type_to_ctype(p.type_node)
            params.append(f"{llvm_type(ct)} %arg_{p.name}")

        params_str = ", ".join(params)
        self._emit(f"define {llvm_ret} @{func.name}({params_str}) {{")
        self._emit("entry:")

        self._push_scope()
        self._current_func_ret  = ret_ct
        self._current_func_name = func.name

        if func.return_name and ret_ct.kind != "nothing":
            ret_alloca = self._alloca(llvm_ret, func.return_name)
            self._store(llvm_zero(ret_ct), llvm_ret, ret_alloca)
            self._scope()[func.return_name] = (ret_alloca, ret_ct)

        for p in func.params:
            ct     = ast_type_to_ctype(p.type_node)
            lt     = llvm_type(ct)
            alloca = self._alloca(lt, p.name)
            self._store(f"%arg_{p.name}", lt, alloca)
            self._scope()[p.name] = (alloca, ct)

        self._gen_stmts(func.body)

        if ret_ct.kind == "nothing":
            self._emit("  ret void")
        else:
            ret_val = self._load(llvm_ret, self._scope().get(func.return_name, ("%undef", ret_ct))[0])
            self._emit(f"  ret {llvm_ret} {ret_val}")

        self._pop_scope()
        self._emit("}\n")

    def _gen_main(self, body: list) -> None:
        self._emit("define i32 @main() {")
        self._emit("entry:")
        self._push_scope()
        self._current_func_ret  = CType("integer", signed=True, bits=32)
        self._current_func_name = "main"
        self._gen_stmts(body)
        self._emit("  ret i32 0")
        self._pop_scope()
        self._emit("}\n")

    # ── Interrupt handler generation ───────────────────────────────────────

    def _gen_interrupt_handler(self, handler: A.InterruptHandlerDef) -> None:
        self._emit(f"; Interrupt Vector: {handler.vector}")
        self._emit(f"define void @handler_{handler.name}() {{")
        self._emit("entry:")
        self._push_scope()
        self._gen_stmts(handler.body)
        self._emit("  ret void")
        self._pop_scope()
        self._emit("}\n")

    # ── Statements ────────────────────────────────────────────────────────────

    def _gen_stmts(self, stmts: list) -> None:
        for s in stmts:
            self._gen_stmt(s)

    def _gen_stmt(self, stmt) -> None:
        if isinstance(stmt, A.DeclareStmt):
            self._gen_declare(stmt)
        elif isinstance(stmt, A.AssignStmt):
            self._gen_assign(stmt)
        elif isinstance(stmt, A.IfStmt):
            self._gen_if(stmt)
        elif isinstance(stmt, A.RepeatStmt):
            self._gen_repeat(stmt)
        elif isinstance(stmt, A.ReturnStmt):
            self._gen_return(stmt)
        elif isinstance(stmt, A.RejectStmt):
            self._gen_reject(stmt)
        elif isinstance(stmt, A.StopStmt):
            self._gen_stop()
        elif isinstance(stmt, A.SkipStmt):
            self._gen_skip()
        elif isinstance(stmt, A.CallStmt):
            self._gen_call(stmt)
        elif isinstance(stmt, A.SimpleCallStmt):
            self._gen_simple_call(stmt)
        elif isinstance(stmt, A.AllocateStmt):
            self._gen_allocate(stmt)
        elif isinstance(stmt, A.ReleaseStmt):
            self._gen_release(stmt)
        elif isinstance(stmt, A.HardwareWriteStmt):
            self._gen_hw_write(stmt)
        elif isinstance(stmt, A.HardwareReadStmt):
            self._gen_hw_read(stmt)

    def _gen_declare(self, stmt: A.DeclareStmt) -> None:
        ct = ast_type_to_ctype(stmt.type_node)
        lt = llvm_type(ct)

        if ct.kind == "named":
            alloca = self._alloca(lt, stmt.name)
            self._scope()[stmt.name] = (alloca, ct)
        elif ct.kind == "array":
            size = ct.bits
            if stmt.location == "heap":
                byte_size = size * 4
                tmp_ptr = self._new_tmp()
                self._emit(f"  {tmp_ptr} = call ptr @malloc(i64 {byte_size})")
                alloca = self._alloca("ptr", stmt.name)
                self._store(tmp_ptr, "ptr", alloca)
                self._heap_vars.add(stmt.name)
            else:
                alloca = self._alloca(f"[{size} x i32]", stmt.name)
            self._scope()[stmt.name] = (alloca, ct)
        else:
            alloca = self._alloca(lt, stmt.name)
            if stmt.location == "heap":
                self._heap_vars.add(stmt.name)
            if ct.kind != "array":
                val = self._gen_expr(stmt.initial_value, ct)
                self._store(val, lt, alloca)
            self._scope()[stmt.name] = (alloca, ct)

    def _gen_assign(self, stmt: A.AssignStmt) -> None:
        if isinstance(stmt.target, A.ArrayIndex):
            ptr = self._get_element_ptr(stmt.target)
            val = self._gen_expr(stmt.value, CType("integer"))
            self._emit(f"  store i32 {val}, ptr {ptr}")
            return

        if isinstance(stmt.target, A.FieldAccess):
            ptr = self._get_field_ptr(stmt.target.obj.name, stmt.target.field)
            val = self._gen_expr(stmt.value, CType("integer"))
            self._emit(f"  store i32 {val}, ptr {ptr}")
            return

        if isinstance(stmt.target, A.Identifier):
            alloca, ct = self._lookup(stmt.target.name)
            val = self._gen_expr(stmt.value, ct)
            self._store(val, llvm_type(ct), alloca)
        elif isinstance(stmt.target, A.ValueAt):
            ptr = self._gen_expr(stmt.target.pointer, None)
            val = self._gen_expr(stmt.value, None)
            self._emit(f"  store i64 {val}, ptr {ptr}")

    def _gen_if(self, stmt: A.IfStmt) -> None:
        cond      = self._gen_expr(stmt.condition, T_BOOL)
        then_lbl  = self._new_label("if_then")
        else_lbl  = self._new_label("if_else")
        end_lbl   = self._new_label("if_end")

        has_else = stmt.else_body is not None or stmt.elseif_branches

        self._emit(f"  br i1 {cond}, label %{then_lbl}, label %{else_lbl if has_else else end_lbl}")
        self._emit(f"{then_lbl}:")
        self._push_scope()
        self._gen_stmts(stmt.then_body)
        self._pop_scope()
        self._emit(f"  br label %{end_lbl}")

        if has_else:
            self._emit(f"{else_lbl}:")
            self._push_scope()
            if stmt.else_body:
                self._gen_stmts(stmt.else_body)
            self._pop_scope()
            self._emit(f"  br label %{end_lbl}")

        self._emit(f"{end_lbl}:")

    def _gen_repeat(self, stmt: A.RepeatStmt) -> None:
        cond_lbl = self._new_label("loop_cond")
        body_lbl = self._new_label("loop_body")
        end_lbl  = self._new_label("loop_end")

        self._loop_cond_labels.append(cond_lbl)
        self._loop_end_labels.append(end_lbl)

        self._emit(f"  br label %{cond_lbl}")
        self._emit(f"{cond_lbl}:")
        cond = self._gen_expr(stmt.condition, T_BOOL)
        self._emit(f"  br i1 {cond}, label %{body_lbl}, label %{end_lbl}")
        self._emit(f"{body_lbl}:")
        self._push_scope()
        self._gen_stmts(stmt.body)
        self._pop_scope()
        self._emit(f"  br label %{cond_lbl}")
        self._emit(f"{end_lbl}:")

        self._loop_cond_labels.pop()
        self._loop_end_labels.pop()

    def _gen_return(self, stmt: A.ReturnStmt) -> None:
        if stmt.value is None or self._current_func_ret.kind == "nothing":
            self._emit("  ret void")
        else:
            lt  = llvm_type(self._current_func_ret)
            val = self._gen_expr(stmt.value, self._current_func_ret)
            self._emit(f"  ret {lt} {val}")
        dead = self._new_label("dead")
        self._emit(f"{dead}:")

    def _gen_reject(self, stmt: A.RejectStmt) -> None:
        msg = self._str_const(f"ERROR: {stmt.error_name}\\n")
        self._emit(f"  call i32 (ptr, ...) @printf(ptr {msg})")
        if self._current_func_ret.kind == "nothing":
            self._emit("  ret void")
        else:
            lt = llvm_type(self._current_func_ret)
            self._emit(f"  ret {lt} {llvm_zero(self._current_func_ret)}")
        dead = self._new_label("dead")
        self._emit(f"{dead}:")

    def _gen_stop(self) -> None:
        if self._loop_end_labels:
            self._emit(f"  br label %{self._loop_end_labels[-1]}")
        dead = self._new_label("dead")
        self._emit(f"{dead}:")

    def _gen_skip(self) -> None:
        if self._loop_cond_labels:
            self._emit(f"  br label %{self._loop_cond_labels[-1]}")
        dead = self._new_label("dead")
        self._emit(f"{dead}:")

    def _gen_call(self, stmt: A.CallStmt) -> None:
        llvm_func_name = stmt.func_name
        obj_ptr = None
        if hasattr(stmt, 'object') and stmt.object is not None:
            _, obj_ct = self._lookup(stmt.object.name)
            llvm_func_name = f"{obj_ct.name}_{stmt.func_name}"
            obj_ptr = self._get_object_ptr(stmt.object)

        sig = self._func_types.get(llvm_func_name)
        args = []

        if obj_ptr is not None:
            args.append(f"ptr {obj_ptr}")

        for arg_name, arg_mode, arg_expr in stmt.args:
            if sig:
                param_map = {}
                for (an, am, ae), pct in zip(stmt.args, sig[0]):
                    param_map[an] = pct
                arg_ct = param_map.get(arg_name, CType("unknown"))
            else:
                arg_ct = CType("unknown")
            val = self._gen_expr(arg_expr, arg_ct)
            lt  = llvm_type(arg_ct)
            args.append(f"{lt} {val}")

        args_str = ", ".join(args)
        ret_ct   = sig[1] if sig else CType("nothing")
        lt       = llvm_type(ret_ct)

        if ret_ct.kind == "nothing":
            self._emit(f"  call void @{llvm_func_name}({args_str})")
        else:
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = call {lt} @{llvm_func_name}({args_str})")

        for h in stmt.handlers:
            if h.kind == "success":
                self._push_scope()
                self._gen_stmts(h.body)
                self._pop_scope()

    def _gen_simple_call(self, stmt: A.SimpleCallStmt) -> None:
        if self._gen_builtin_call(stmt):
            return

        llvm_func_name = stmt.func_name
        obj_ptr = None
        if hasattr(stmt, 'object') and stmt.object is not None:
            _, obj_ct = self._lookup(stmt.object.name)
            llvm_func_name = f"{obj_ct.name}_{stmt.func_name}"
            obj_ptr = self._get_object_ptr(stmt.object)

        sig = self._func_types.get(llvm_func_name)

        if sig is None:
            proto = f"declare void @{llvm_func_name}("
            if obj_ptr is not None:
                proto += "ptr"
                if stmt.args:
                    proto += ", "
            if stmt.args:
                proto += ", ".join(["i32"] * len(stmt.args))
            proto += ")"
            if proto not in self._globals:
                self._globals.append(proto)

            args = []
            if obj_ptr is not None:
                args.append(f"ptr {obj_ptr}")
            for arg_expr in stmt.args:
                val = self._gen_expr(arg_expr, CType("integer", signed=True, bits=32))
                args.append(f"i32 {val}")
            self._emit(f"  call void @{llvm_func_name}({', '.join(args)})")
            return

        args = []
        if obj_ptr is not None:
            self_ct = sig[0][0] if sig[0] else CType("named", name="unknown")
            args.append(f"{llvm_type(self_ct)} {obj_ptr}")

        for i, arg_expr in enumerate(stmt.args):
            param_idx = i + (1 if obj_ptr is not None else 0)
            arg_ct = sig[0][param_idx] if param_idx < len(sig[0]) else CType("integer")
            val    = self._gen_expr(arg_expr, arg_ct)
            lt     = llvm_type(arg_ct)
            args.append(f"{lt} {val}")

        args_str = ", ".join(args)
        ret_ct   = sig[1] if sig else CType("nothing")
        lt       = llvm_type(ret_ct)
        if ret_ct.kind == "nothing":
            self._emit(f"  call void @{llvm_func_name}({args_str})")
        else:
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = call {lt} @{llvm_func_name}({args_str})")

    # ── Hardware Access (volatile) ──────────────────────────────────────────

    def _gen_hw_write(self, stmt: A.HardwareWriteStmt) -> None:
        reg = self._hw_registers.get(stmt.reg_name)
        if reg is None:
            raise CodegenError(f"Register '{stmt.reg_name}' not found in codegen map")
        val = self._gen_expr(stmt.value, CType("integer"))
        ptr = self._new_tmp()
        self._emit(f"  {ptr} = inttoptr i64 {reg.address} to ptr")
        self._emit(f"  store volatile i32 {val}, ptr {ptr}")

    def _gen_hw_read(self, stmt: A.HardwareReadStmt) -> None:
        reg = self._hw_registers.get(stmt.reg_name)
        if reg is None:
            raise CodegenError(f"Register '{stmt.reg_name}' not found in codegen map")
        dest_ptr, _ = self._lookup(stmt.dest_name)
        ptr = self._new_tmp()
        self._emit(f"  {ptr} = inttoptr i64 {reg.address} to ptr")
        tmp_val = self._new_tmp()
        self._emit(f"  {tmp_val} = load volatile i32, ptr {ptr}")
        self._emit(f"  store i32 {tmp_val}, ptr {dest_ptr}")

    # ── Helpers for method calls ─────────────────────────────────────────────

    def _get_object_ptr(self, obj) -> str:
        if isinstance(obj, A.Identifier):
            alloca, ct = self._lookup(obj.name)
            return alloca
        elif isinstance(obj, A.FieldAccess):
            return self._get_field_ptr(obj.obj.name, obj.field)
        else:
            raise CodegenError(f"Unsupported object expression for method call: {type(obj)}")

    def _gen_builtin_call(self, stmt: A.SimpleCallStmt) -> bool:
        name = stmt.func_name

        if name == "print_integer":
            val = self._gen_expr(stmt.args[0], CType("integer", signed=True, bits=32))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.int, i32 {val})")
            return True

        if name == "print_unsigned":
            val = self._gen_expr(stmt.args[0], CType("integer", signed=False, bits=32))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.uint, i32 {val})")
            return True

        if name == "print_float":
            val = self._gen_expr(stmt.args[0], CType("float", bits=64))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.flt, double {val})")
            return True

        if name == "print_text":
            val = self._gen_expr(stmt.args[0], CType("text"))
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.str, ptr {val})")
            return True

        if name == "print_boolean":
            val  = self._gen_expr(stmt.args[0], CType("boolean"))
            t_lbl = self._new_label("bool_true")
            f_lbl = self._new_label("bool_false")
            e_lbl = self._new_label("bool_end")
            self._emit(f"  br i1 {val}, label %{t_lbl}, label %{f_lbl}")
            self._emit(f"{t_lbl}:")
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.true)")
            self._emit(f"  br label %{e_lbl}")
            self._emit(f"{f_lbl}:")
            self._emit(f"  call i32 (ptr, ...) @printf(ptr @fmt.fals)")
            self._emit(f"  br label %{e_lbl}")
            self._emit(f"{e_lbl}:")
            return True

        if name == "print_line":
            self._emit(f"  call i32 @putchar(i32 10)")
            return True

        return False

    def _gen_allocate(self, stmt: A.AllocateStmt) -> None:
        size_val = self._gen_expr(stmt.size, CType("integer", bits=64))
        tmp      = self._new_tmp()
        self._emit(f"  {tmp} = call ptr @malloc(i64 {size_val})")
        if stmt.name in self._scope():
            alloca, ct = self._scope()[stmt.name]
            self._store(tmp, "ptr", alloca)
        else:
            alloca = self._alloca("ptr", stmt.name)
            self._store(tmp, "ptr", alloca)
            self._scope()[stmt.name] = (alloca, CType("pointer"))

    def _gen_release(self, stmt: A.ReleaseStmt) -> None:
        alloca, ct = self._lookup(stmt.name)
        if stmt.name in self._heap_vars:
            ptr = self._load("ptr", alloca)
            self._emit(f"  call void @free(ptr {ptr})")
        else:
            ptr = self._load("ptr", alloca)
            self._emit(f"  call void @free(ptr {ptr})")

    # ── Structure field access ──────────────────────────────────────────────

    def _get_field_ptr(self, obj_name: str, field_name: str) -> str:
        alloca, ct = self._lookup(obj_name)
        struct_name = ct.name
        field_list = self._struct_fields.get(struct_name, [])
        if field_name not in field_list:
            raise CodegenError(f"Field '{field_name}' not found in struct '{struct_name}'")
        field_idx = field_list.index(field_name)

        tmp = self._new_tmp()
        self._emit(f"  {tmp} = getelementptr %struct.{struct_name}, ptr {alloca}, i32 0, i32 {field_idx}")
        return tmp

    # ── Helper for array element access ─────────────────────────────────────

    def _get_element_ptr(self, expr: A.ArrayIndex) -> str:
        if isinstance(expr.target, A.Identifier):
            base_ptr, ct = self._lookup(expr.target.name)
            idx_val = self._gen_expr(expr.index_expr, CType("integer"))
            tmp = self._new_tmp()
            
            if expr.target.name in self._heap_vars:
                real_ptr = self._load("ptr", base_ptr)
                self._emit(f"  {tmp} = getelementptr i32, ptr {real_ptr}, i32 {idx_val}")
            elif ct.kind == "array":
                N = ct.bits
                self._emit(f"  {tmp} = getelementptr [{N} x i32], ptr {base_ptr}, i32 0, i32 {idx_val}")
            else:
                self._emit(f"  {tmp} = getelementptr i32, ptr {base_ptr}, i32 {idx_val}")
            return tmp
        else:
            base_ptr = self._get_element_ptr(expr.target)
            idx_val = self._gen_expr(expr.index_expr, CType("integer"))
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = getelementptr i32, ptr {base_ptr}, i32 {idx_val}")
            return tmp

    # ── Expressions ───────────────────────────────────────────────────────────

    def _gen_expr(self, expr, hint_ct: Optional[CType]) -> str:
        if isinstance(expr, A.IntLiteral):
            return str(expr.value)

        if isinstance(expr, A.FloatLiteral):
            return f"{expr.value:.17g}"

        if isinstance(expr, A.BoolLiteral):
            return "1" if expr.value else "0"

        if isinstance(expr, A.TextLiteral):
            return self._str_const(expr.value)

        if isinstance(expr, A.NullLiteral):
            return "null"

        if isinstance(expr, A.Identifier):
            alloca, ct = self._lookup(expr.name)
            return self._load(llvm_type(ct), alloca)

        if isinstance(expr, A.FieldAccess):
            ptr = self._get_field_ptr(expr.obj.name, expr.field)
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = load i32, ptr {ptr}")
            return tmp

        if isinstance(expr, A.BinaryOp):
            return self._gen_binop(expr, hint_ct)

        if isinstance(expr, A.CompareOp):
            return self._gen_compare(expr)

        if isinstance(expr, A.LogicOp):
            return self._gen_logic(expr)

        if isinstance(expr, A.NotOp):
            val = self._gen_expr(expr.operand, T_BOOL)
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = xor i1 {val}, 1")
            return tmp

        if isinstance(expr, A.AddressOf):
            alloca, ct = self._lookup(expr.name)
            return alloca

        if isinstance(expr, A.ValueAt):
            ptr_val = self._gen_expr(expr.pointer, None)
            tmp     = self._new_tmp()
            lt      = llvm_type(hint_ct) if hint_ct else "i64"
            self._emit(f"  {tmp} = load {lt}, ptr {ptr_val}")
            return tmp

        if isinstance(expr, A.SizeOf):
            ct  = ast_type_to_ctype(expr.target)
            bits = ct.bits if hasattr(ct, "bits") else 64
            return str(bits // 8)

        if isinstance(expr, A.ConvertExpr):
            return self._gen_convert(expr, hint_ct)

        if isinstance(expr, A.MethodCallExpr):
            if isinstance(expr.obj, A.Identifier):
                obj_ptr, obj_ct = self._lookup(expr.obj.name)
                struct_name = obj_ct.name
            else:
                raise CodegenError("Method call target must be a struct variable")

            llvm_func_name = f"{struct_name}_{expr.method}"

            args = [f"ptr {obj_ptr}"]
            for arg_expr in expr.args:
                val = self._gen_expr(arg_expr, CType("integer", bits=32))
                args.append(f"i32 {val}")

            tmp = self._new_tmp()
            self._emit(f"  {tmp} = call i32 @{llvm_func_name}({', '.join(args)})")
            return tmp

        if isinstance(expr, A.CallExpr):
            llvm_func_name = expr.func_name
            obj_ptr = None
            if hasattr(expr, 'object') and expr.object is not None:
                _, obj_ct = self._lookup(expr.object.name)
                llvm_func_name = f"{obj_ct.name}_{expr.func_name}"
                obj_ptr = self._get_object_ptr(expr.object)

            sig = self._func_types.get(llvm_func_name)
            args = []
            if obj_ptr is not None:
                args.append(f"ptr {obj_ptr}")
            for i, arg_expr in enumerate(expr.args):
                arg_ct = sig[0][i] if sig and i < len(sig[0]) else CType("integer")
                val = self._gen_expr(arg_expr, arg_ct)
                args.append(f"{llvm_type(arg_ct)} {val}")
            ret_ct = sig[1] if sig else CType("integer")
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = call {llvm_type(ret_ct)} @{llvm_func_name}({', '.join(args)})")
            return tmp

        if isinstance(expr, A.ArrayIndex):
            ptr = self._get_element_ptr(expr)
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = load i32, ptr {ptr}")
            return tmp

        if isinstance(expr, A.BitwiseOp):
            left = self._gen_expr(expr.left, hint_ct)
            right = self._gen_expr(expr.right, hint_ct)
            tmp = self._new_tmp()
            op_map = {"and": "and", "or": "or", "xor": "xor"}
            self._emit(f"  {tmp} = {op_map[expr.op]} i32 {left}, {right}")
            return tmp

        if isinstance(expr, A.ShiftOp):
            val = self._gen_expr(expr.value, hint_ct)
            amt = self._gen_expr(expr.amount, hint_ct)
            tmp = self._new_tmp()
            llvm_op = "shl" if expr.direction == "left" else "lshr"
            self._emit(f"  {tmp} = {llvm_op} i32 {val}, {amt}")
            return tmp

        return "0"

    def _gen_binop(self, expr: A.BinaryOp, hint_ct: Optional[CType]) -> str:
        left  = self._gen_expr(expr.left,  hint_ct)
        right = self._gen_expr(expr.right, hint_ct)
        tmp   = self._new_tmp()

        is_float = (hint_ct and hint_ct.kind == "float")
        lt = llvm_type(hint_ct) if hint_ct else "i32"

        op_map_int   = {"plus": "add",  "minus": "sub",
                        "multiply": "mul", "divide": "sdiv", "remainder": "srem"}
        op_map_float = {"plus": "fadd", "minus": "fsub",
                        "multiply": "fmul", "divide": "fdiv", "remainder": "frem"}
        op_map = op_map_float if is_float else op_map_int
        op     = op_map.get(expr.op, "add")

        self._emit(f"  {tmp} = {op} {lt} {left}, {right}")
        return tmp

    def _gen_compare(self, expr: A.CompareOp) -> str:
        if isinstance(expr.left, A.Identifier):
            try:
                _, ct = self._lookup(expr.left.name)
            except CodegenError:
                ct = CType("integer", bits=32)
        else:
            ct = CType("integer", bits=32)

        left  = self._gen_expr(expr.left,  ct)
        right = self._gen_expr(expr.right, ct)
        tmp   = self._new_tmp()
        lt    = llvm_type(ct)

        is_float = ct.kind == "float"
        unsigned = (ct.kind == "integer" and not ct.signed)

        cmp_map = {
            "is equal to":          ("fcmp oeq" if is_float else "icmp eq"),
            "is not equal to":      ("fcmp one" if is_float else "icmp ne"),
            "is greater than":      ("fcmp ogt" if is_float else
                                     "icmp ugt" if unsigned else "icmp sgt"),
            "is less than":         ("fcmp olt" if is_float else
                                     "icmp ult" if unsigned else "icmp slt"),
            "is greater or equal":  ("fcmp oge" if is_float else
                                     "icmp uge" if unsigned else "icmp sge"),
            "is less or equal":     ("fcmp ole" if is_float else
                                     "icmp ule" if unsigned else "icmp sle"),
            "is not null":          "icmp ne",
            "is null":              "icmp eq",
        }
        op = cmp_map.get(expr.op, "icmp eq")

        if expr.op in ("is not null", "is null"):
            self._emit(f"  {tmp} = {op} ptr {left}, null")
        else:
            self._emit(f"  {tmp} = {op} {lt} {left}, {right}")
        return tmp

    def _gen_logic(self, expr: A.LogicOp) -> str:
        left  = self._gen_expr(expr.left,  T_BOOL)
        right = self._gen_expr(expr.right, T_BOOL)
        tmp   = self._new_tmp()
        op    = "and" if expr.op == "and" else "or"
        self._emit(f"  {tmp} = {op} i1 {left}, {right}")
        return tmp

    def _gen_convert(self, expr: A.ConvertExpr, hint_ct: Optional[CType]) -> str:
        val = self._gen_expr(expr.value, None)
        target_ct = ast_type_to_ctype(expr.target_type)
        
        if target_ct.kind == "integer" and target_ct.bits == 8:
            overflow_lbl = self._new_label("conv_overflow")
            ok_lbl = self._new_label("conv_ok")
            
            is_too_big = self._new_tmp()
            self._emit(f"  {is_too_big} = icmp sgt i32 {val}, 127")
            self._emit(f"  br i1 {is_too_big}, label %{overflow_lbl}, label %{ok_lbl}")
            
            self._emit(f"{overflow_lbl}:")
            self._push_scope()
            self._gen_stmts(expr.on_overflow)
            self._pop_scope()
            self._emit(f"  br label %{ok_lbl}")
            
            self._emit(f"{ok_lbl}:")
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = trunc i32 {val} to i8")
            return tmp
        elif target_ct.kind == "integer":
            dst_lt = llvm_type(target_ct)
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = trunc i32 {val} to {dst_lt}")
            return tmp
        elif target_ct.kind == "float":
            dst_lt = llvm_type(target_ct)
            tmp = self._new_tmp()
            self._emit(f"  {tmp} = sitofp i32 {val} to {dst_lt}")
            return tmp
        else:
            return val

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _alloca(self, llvm_t: str, name: str = "") -> str:
        tmp = f"%alloca_{name}_{self._tmp}" if name else self._new_tmp()
        self._tmp += 1
        self._emit(f"  {tmp} = alloca {llvm_t}")
        return tmp

    def _store(self, val: str, llvm_t: str, ptr: str) -> None:
        self._emit(f"  store {llvm_t} {val}, ptr {ptr}")

    def _load(self, llvm_t: str, ptr: str) -> str:
        tmp = self._new_tmp()
        self._emit(f"  {tmp} = load {llvm_t}, ptr {ptr}")
        return tmp

    def _new_tmp(self) -> str:
        self._tmp += 1
        return f"%t{self._tmp}"

    def _new_label(self, prefix: str) -> str:
        self._lbl += 1
        return f"{prefix}_{self._lbl}"

    def _str_const(self, text: str) -> str:
        if text in self._str_cache:
            return self._str_cache[text]
        name    = f"@str.{self._str_count}"
        self._str_count += 1
        escaped = text.replace("\\n", "\\0A")
        
        utf8_bytes = text.replace("\\n", "\n").encode('utf-8')
        length = len(utf8_bytes) + 1 
        
        self._globals.append(
            f'{name} = private unnamed_addr constant [{length} x i8] '
            f'c"{escaped}\\00"'
        )
        self._str_cache[text] = name
        return name

    def _push_scope(self) -> None:
        self._scope_stack.append({})

    def _pop_scope(self) -> None:
        self._scope_stack.pop()

    def _scope(self) -> dict:
        return self._scope_stack[-1]

    def _lookup(self, name: str) -> tuple[str, CType]:
        for scope in reversed(self._scope_stack):
            if name in scope:
                return scope[name]
        raise CodegenError(f"Undefined variable '{name}' during codegen")

    def _emit(self, line: str) -> None:
        self._lines.append(line)
