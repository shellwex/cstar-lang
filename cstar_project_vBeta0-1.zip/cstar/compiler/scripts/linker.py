"""
C* Compiler — Stage 7: Linking
Transpiles LLVM IR (produced by Stage 6) to C, then compiles with gcc.

Why not clang/llc directly?
    In many environments (Termux, minimal Linux) clang and llc are not
    installed. gcc is almost always available. The IR that Stage 6 produces
    is a restricted subset — alloca/store/load/add/icmp/br/call/ret — which
    maps cleanly to C without needing the full LLVM toolchain.

Pipeline:
    .cstar → [Stage 1-6] → LLVM IR → [Stage 7] → .c → gcc → binary
"""

from __future__ import annotations
import os
import re
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Optional


# ── Result ────────────────────────────────────────────────────────────────────

@dataclass
class LinkResult:
    success:     bool
    output_path: str = ""
    error:       str = ""
    c_source:    str = ""   # generated C (for --emit-c / debugging)


# ── IR → C transpiler ─────────────────────────────────────────────────────────

class IRTranspiler:
    """
    Converts the restricted LLVM IR subset that C* codegen produces into
    a valid C source file that gcc can compile.

    Supported IR constructs:
        Global string constants  (@name = ... constant [...] c"...")
        Function definitions     (define TYPE @name(...) { ... })
        alloca                   (stack slot declaration)
        store / load             (write / read slot)
        volatile store / load    (with volatile qualifier)
        getelementptr            (address calculation for structs/arrays)
        inttoptr                 (integer to pointer conversion)
        trunc / sext / zext      (integer conversion)
        sitofp / fptosi / uitofp / fptoui
        add / sub / mul / sdiv   (arithmetic)
        and / or / xor / shl / lshr (logical and shift)
        icmp slt/sgt/sle/sge/eq/ne
        br / conditional br      (gotos + labels)
        call                     (function calls, including printf)
        ret                      (return)
    """

    def __init__(self):
        self._lines: list[str] = []
        self._globals: dict[str, tuple[str, str]] = {}   # IR name → (C name, string literal)
        self._slots: dict[str, str]   = {}   # alloca name → C type
        self._temps: dict[str, str]   = {}   # %tN → expression string
        self._out:   list[str]        = []

    # ── Public entry point ────────────────────────────────────────────────────

    def transpile(self, ir: str) -> str:
        self._lines = [l.rstrip() for l in ir.splitlines()]
        self._out = []

        self._emit("#include <stdio.h>")
        self._emit("#include <stdlib.h>")
        self._emit("#include <stdint.h>")
        self._emit("")

        # Collect global string constants first
        self._collect_globals()

        # === NEW: emit struct definitions before any functions ===
        self._collect_and_emit_structs()

        # Emit global string literals
        for ir_name, (c_name, c_val) in self._globals.items():
            self._emit(f'static const char {c_name}[] = {c_val};')
        if self._globals:
            self._emit("")

        # Process function definitions
        i = 0
        while i < len(self._lines):
            line = self._lines[i]
            if line.startswith("define "):
                i = self._process_function(i)
            else:
                i += 1

        return "\n".join(self._out)

    # ── Globals ───────────────────────────────────────────────────────────────

    def _collect_globals(self):
        for line in self._lines:
            m = re.match(r'@([\w.]+)\s*=.*?c"(.*)"', line)
            if m:
                ir_name = m.group(1)
                raw     = m.group(2)
                c_name  = "g_" + re.sub(r'[.\-]', '_', ir_name)
                c_str   = self._ir_string_to_c(raw)
                self._globals[ir_name] = (c_name, f'"{c_str}"')

    def _ir_string_to_c(self, raw: str) -> str:
        """Convert IR c"..." content to C string content (escapes, hex)."""
        result = []
        i = 0
        while i < len(raw):
            if raw[i] == "\\" and i + 2 < len(raw):
                hex_byte = raw[i+1:i+3]
                try:
                    val = int(hex_byte, 16)
                    if val == 0:
                        pass  # NUL terminator — C handles it
                    elif val == 10:
                        result.append("\\n")
                    elif val == 13:
                        result.append("\\r")
                    elif val == 9:
                        result.append("\\t")
                    elif 32 <= val < 127:
                        result.append(chr(val))
                    else:
                        result.append(f"\\x{hex_byte}")
                    i += 3
                    continue
                except ValueError:
                    pass
            result.append(raw[i])
            i += 1
        return "".join(result)

    # ── Struct emitter (NEW) ──────────────────────────────────────────────────

    def _collect_and_emit_structs(self) -> None:
        """Emit forward-complete C struct definitions from LLVM IR type declarations.

        Scans self._lines for lines of the form:
            %struct.Foo = type { i32, ptr, i32 }
        and emits:
            struct Foo { int32_t f0; void* f1; int32_t f2; };
        before any function definitions, so all struct types are complete
        when the compiler sees function signatures and local variables.
        """
        found_any = False
        for line in self._lines:
            m = re.match(r'%struct\.(\w+)\s*=\s*type\s*\{([^}]*)\}', line)
            if not m:
                continue
            struct_name = m.group(1)
            fields_raw = [f.strip() for f in m.group(2).split(',') if f.strip()]
            self._emit(f'struct {struct_name} {{')
            for idx, ir_field_type in enumerate(fields_raw):
                c_type = self._ir_type_to_c(ir_field_type)
                self._emit(f'    {c_type} f{idx};')
            self._emit('};')
            found_any = True
        if found_any:
            self._emit('')

    # ── Functions ─────────────────────────────────────────────────────────────

    def _process_function(self, start: int) -> int:
        """Process one function definition. Returns index after closing '}'."""
        self._slots = {}
        self._temps = {}

        header = self._lines[start]
        m = re.match(r'define\s+(\S+)\s+@(\w+)\((.*?)\)', header)
        if not m:
            return start + 1

        ret_type = self._ir_type_to_c(m.group(1))
        func_name = m.group(2)
        params_ir = m.group(3).strip()

        params_c = self._parse_params(params_ir)
        self._emit(f"{ret_type} {func_name}({params_c}) {{")

        # Collect body lines
        body_lines = []
        i = start + 1
        while i < len(self._lines) and self._lines[i] != "}":
            body_lines.append(self._lines[i])
            i += 1

        # First pass: declare all allocas
        for bl in body_lines:
            bl = bl.strip()
            am = re.match(r'%(\w+)\s*=\s*alloca\s+(\S+)', bl)
            if am:
                slot_name = am.group(1)
                ir_type   = am.group(2)
                c_type    = self._ir_type_to_c(ir_type)
                self._slots[slot_name] = c_type
                # Structs are declared without initializer, others optionally with zero
                if ir_type.startswith("%struct."):
                    self._emit(f"    {c_type} {slot_name};")
                else:
                    self._emit(f"    {c_type} {slot_name};")

        self._emit("")   # blank line after declarations

        # Second pass: emit statements (skip entry label if present)
        skip_entry_label = True
        for bl in body_lines:
            bl_stripped = bl.strip()
            if not bl_stripped or bl_stripped.startswith(";"):
                continue
            # Labels (basic blocks)
            if re.match(r'^[\w.]+:$', bl_stripped):
                label = bl_stripped[:-1]
                if label == "entry" and skip_entry_label:
                    skip_entry_label = False
                    continue
                self._emit(f"  {label}:;")
                continue
            self._emit_statement(bl_stripped)

        self._emit("}")
        self._emit("")
        return i + 1  # skip closing '}'

    def _parse_params(self, params_ir: str) -> str:
        if not params_ir or params_ir == "...":
            return "void" if not params_ir else "..."
        parts = []
        for p in params_ir.split(","):
            p = p.strip()
            if not p:
                continue
            tokens = p.split()
            if len(tokens) >= 2:
                c_type = self._ir_type_to_c(tokens[0])
                c_name = tokens[-1].lstrip("%")
                parts.append(f"{c_type} {c_name}")
            else:
                parts.append(self._ir_type_to_c(tokens[0]))
        return ", ".join(parts) if parts else "void"

    # ── Statement emitter ─────────────────────────────────────────────────────

    def _emit_statement(self, line: str):
        # 1a. Struct field GEP: getelementptr %struct.Name, ptr base, i32 0, i32 fieldidx
        #     Используем адрес поля через указатель на struct — C сам считает правильный offset
        m = re.match(r'%(\w+)\s*=\s*getelementptr\s+%struct\.(\w+),\s*ptr\s+%?(\w+),\s*i32\s+0,\s*i32\s+(\d+)', line)
        if m:
            tmp, struct_name, base_name, field_idx = m.groups()
            ref = f"&{base_name}" if base_name in self._slots else base_name
            self._temps[tmp] = tmp
            self._emit(f"    void* {tmp} = (void*)&((struct {struct_name}*){ref})->f{field_idx};")
            return

        # 1b. Array/element GEP: getelementptr TYPE, ptr base, i32 idx
        #     Используем правильный тип элемента для корректного шага
        m = re.match(r'%(\w+)\s*=\s*getelementptr\s+(\S+),\s*ptr\s+%?(\w+),\s*i32\s+(.+)', line)
        if m:
            tmp, elem_type, base_name, idx_str = m.groups()
            idx = self._resolve_operand(idx_str)
            ref = f"&{base_name}" if base_name in self._slots else base_name
            c_elem_type = self._ir_type_to_c(elem_type)
            self._temps[tmp] = tmp
            self._emit(f"    void* {tmp} = (void*)(({c_elem_type}*){ref} + {idx});")
            return

        # 2. inttoptr (редко, но оставлен)
        m = re.match(r'%(\w+)\s*=\s*inttoptr\s+i64\s+(.+?)\s+to\s+ptr', line)
        if m:
            tmp = m.group(1)
            addr = self._resolve_operand(m.group(2))
            self._temps[tmp] = tmp
            self._emit(f"    void* {tmp} = (void*)(uintptr_t){addr};")
            return

        # 3. store
        m = re.match(r'store\s+(volatile\s+)?(\S+)\s+(.+?),\s*ptr\s+%(\w+)', line)
        if m:
            is_volatile = m.group(1) is not None
            val_type = m.group(2)
            val = self._resolve_val(val_type, m.group(3))
            ptr_name = m.group(4)
            c_type = self._ir_type_to_c(val_type)
            v_spec = "volatile " if is_volatile else ""

            if ptr_name in self._temps or ptr_name.startswith("t"):
                # Запись по указателю (временная переменная – адрес)
                self._emit(f"    *({v_spec}{c_type}*){ptr_name} = {val};")
            else:
                # Прямая запись в локальную переменную / alloca
                self._emit(f"    {ptr_name} = {val};")
            return

        # 4. load
        m = re.match(r'%(\w+)\s*=\s*load\s+(\S+),\s*ptr\s+%(\w+)', line)
        if m:
            tmp, lt, ptr_name = m.groups()
            ct = self._ir_type_to_c(lt)
            self._temps[tmp] = tmp

            if ptr_name in self._temps or ptr_name.startswith("t"):
                # Чтение по адресу (из временной переменной-указателя)
                self._emit(f"    {ct} {tmp} = *({ct}*){ptr_name};")
            else:
                # Чтение локальной переменной
                self._emit(f"    {ct} {tmp} = {ptr_name};")
            return

        # 5. Арифметика и битовые операции
        m = re.match(r'%(\w+)\s*=\s*(add|sub|mul|sdiv|udiv|and|or|xor|shl|lshr)\s+\S+\s+(.+?),\s*(.+)', line)
        if m:
            tmp, op, lhs, rhs = m.groups()
            op_map = {"add":"+", "sub":"-", "mul":"*", "sdiv":"/", "udiv":"/",
                      "and":"&", "or":"|", "xor":"^", "shl":"<<", "lshr":">>"}
            self._temps[tmp] = tmp
            self._emit(f"    int32_t {tmp} = ({self._resolve_operand(lhs)} {op_map[op]} {self._resolve_operand(rhs)});")
            return

        # 6. Сравнения (icmp)
        m = re.match(r'%(\w+)\s*=\s*icmp\s+(\w+)\s+\S+\s+(.+?),\s*(.+)', line)
        if m:
            tmp, pred, lhs, rhs = m.groups()
            op_map = {"eq":"==", "ne":"!=", "slt":"<", "sgt":">", "sle":"<=", "sge":">="}
            self._temps[tmp] = tmp
            self._emit(f"    int {tmp} = ({self._resolve_operand(lhs)} {op_map.get(pred, '==')} {self._resolve_operand(rhs)});")
            return

        # 7. Ветвления и возврат
        # br i1 %COND, label %TRUE, label %FALSE
        m = re.match(r'br\s+i1\s+%(\w+),\s*label\s+%(\w+),\s*label\s+%(\w+)', line)
        if m:
            cond  = self._resolve_operand(m.group(1))
            true_ = m.group(2)
            false_= m.group(3)
            self._emit(f"    if ({cond}) goto {true_}; else goto {false_};")
            return

        # br label %TARGET
        m = re.match(r'br\s+label\s+%(\w+)', line)
        if m:
            self._emit(f"    goto {m.group(1)};")
            return

        # ret TYPE VALUE  /  ret void
        m = re.match(r'ret\s+(\S+)\s*(.*)', line)
        if m:
            if m.group(1) == "void":
                self._emit("    return;")
            else:
                val = self._resolve_operand(m.group(2))
                self._emit(f"    return {val};")
            return

        # 8. Вызовы функций
        m = re.match(r'(?:%(\w+)\s*=\s*)?call\s+.+?@(\w+)\((.*)\)', line)
        if m:
            ret_tmp  = m.group(1)
            func     = m.group(2)
            args_raw = m.group(3)
            args_c   = self._parse_call_args(args_raw)

            # Несколько известных имён
            if func == "printf":
                call_expr = f'printf({args_c})'
            elif func == "malloc":
                call_expr = f'malloc({args_c})'
            elif func == "free":
                call_expr = f'free({args_c})'
            elif func == "putchar":
                call_expr = f'putchar({args_c})'
            else:
                call_expr = f'{func}({args_c})'

            if ret_tmp:
                # Сохраняем выражение для подстановки в последующих инструкциях
                # Не эмитим отдельный вызов — результат будет встроен через _temps
                self._temps[ret_tmp] = call_expr
            else:
                self._emit(f"    {call_expr};")
            return

        # alloca уже обработана в первом проходе — пропускаем
        if re.match(r'%\w+\s*=\s*alloca', line):
            return

    # ── Call argument parser (с авто-адресом для alloca) ─────────────────────

    def _parse_call_args(self, args_raw: str) -> str:
        if not args_raw.strip():
            return ""
        parts = []
        depth = 0
        cur   = []
        for ch in args_raw:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                parts.append("".join(cur).strip())
                cur = []
            else:
                cur.append(ch)
        if cur:
            parts.append("".join(cur).strip())

        c_args = []
        for part in parts:
            part = part.strip()
            if not part:
                continue
            # ptr @global_name
            m = re.match(r'ptr\s+@([\w.]+)', part)
            if m:
                ir_name = m.group(1)
                if ir_name in self._globals:
                    c_args.append(self._globals[ir_name][0])
                else:
                    c_args.append("g_" + re.sub(r'[.\-]', '_', ir_name))
                continue

            # TYPE %name  or  TYPE value
            tokens = part.split(None, 1)
            if len(tokens) == 2:
                val_str = tokens[1].strip()
                # Если аргумент — ссылка на alloca (локальную переменную), передаём её адрес
                if val_str.startswith("%"):
                    name = val_str[1:]
                    if name in self._slots:
                        c_args.append(f"&{name}")
                        continue
                c_args.append(self._resolve_operand(val_str))
            else:
                c_args.append(self._resolve_operand(tokens[0]))

        return ", ".join(c_args)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _resolve_val(self, ir_type: str, val_str: str) -> str:
        """Используется для store: преобразует литералы или %tmp в C‑выражение."""
        val_str = val_str.strip()
        if val_str == "null":
            return "NULL"
        if val_str.startswith("%"):
            name = val_str[1:]
            return self._temps.get(name, name)
        if val_str in ("true", "1") and ir_type == "i1":
            return "1"
        if val_str in ("false", "0") and ir_type == "i1":
            return "0"
        return val_str

    def _resolve_operand(self, op: str) -> str:
        """Используется в арифметике, сравнениях, возврате – выдаёт значение переменной."""
        op = op.strip()
        if op == "null":
            return "NULL"
        if op.startswith("%"):
            name = op[1:]
            return self._temps.get(name, name)   # если не temp, то само имя (напр. alloca)
        if op.startswith("@"):
            ir_name = op[1:]
            if ir_name in self._globals:
                return self._globals[ir_name][0]
            return "g_" + re.sub(r'[.\-]', '_', ir_name)
        return op

    def _ir_type_to_c(self, ir_type: str) -> str:
        """Преобразует LLVM-тип в C-тип, включая структуры."""
        if ir_type == "void":
            return "void"
        if ir_type == "ptr":
            return "void*"
        if ir_type.startswith("i1"):
            return "int"
        if ir_type.startswith("i8"):
            return "int8_t"
        if ir_type.startswith("i32"):
            return "int32_t"
        if ir_type.startswith("i64"):
            return "int64_t"
        if ir_type.startswith("%struct."):
            # %struct.List → struct List
            return "struct " + ir_type[len("%struct."):]
        return "int32_t"

    def _emit(self, line: str):
        self._out.append(line)


# ── Linker ────────────────────────────────────────────────────────────────────

def link(
    ir:          str,
    output_path: str,
    *,
    emit_c:      bool = False,
    verbose:     bool = False,
) -> LinkResult:
    """
    Stage 7: transpile IR → C → binary via gcc.

    Args:
        ir:          LLVM IR string from Stage 6
        output_path: destination binary path
        emit_c:      if True, also return the generated C in result.c_source
        verbose:     print gcc command
    Returns:
        LinkResult
    """
    transpiler = IRTranspiler()
    c_source   = transpiler.transpile(ir)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    with tempfile.NamedTemporaryFile(
        suffix=".c", mode="w", delete=False, encoding="utf-8"
    ) as tf:
        tf.write(c_source)
        c_path = tf.name

    cmd = ["gcc", c_path, "-o", output_path, "-lm"]
    if verbose:
        print(f"         gcc {' '.join(cmd[1:])}")

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            return LinkResult(
                success=False,
                error=proc.stderr,
                c_source=c_source if emit_c else "",
            )
    except FileNotFoundError:
        return LinkResult(
            success=False,
            error="gcc not found. Install gcc to enable Stage 7.",
        )
    finally:
        os.unlink(c_path)

    return LinkResult(
        success=True,
        output_path=output_path,
        c_source=c_source if emit_c else "",
    )
