"""
C* Compiler — Semantic Analyzer
Walks the AST and enforces the language's static rules.

Checks performed (Phase 1 — core):
  ... (все проверки из предыдущих фаз)
  ✓ Unified type name generation (get_type_name)
  ✓ Deep generic instantiation with proper naming
  ✓ Module function registration
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Union, List
import os

from ..parser import ast as A
from ..parser.parser import Parser
from ..lexer.token import Span


# ── Diagnostic ────────────────────────────────────────────────────────────────

@dataclass
class Diagnostic:
    kind: str          # "error" | "warning"
    message: str
    span: A.Span

    def __str__(self) -> str:
        return f"[{self.span}] {self.kind.upper()}: {self.message}"


# ── Type representation ───────────────────────────────────────────────────────

@dataclass(frozen=True)
class CType:
    """Canonical type used during semantic analysis."""
    kind: str          # "integer"|"float"|"byte"|"boolean"|"text"|
                       # "pointer"|"nothing"|"named"|"array"|"unknown"
    signed: bool = True
    bits: int = 32
    inner: Optional["CType"] = None   # for pointer
    name: str = ""                     # for named types (used also for builtin short names)
    min_val: Optional[int] = None      # lower bound for range‑constrained types
    max_val: Optional[int] = None      # upper bound for range‑constrained types

    def __str__(self) -> str:
        if self.kind == "integer":
            s = "signed" if self.signed else "unsigned"
            return f"integer[{s}, {self.bits}bit]"
        if self.kind == "float":
            return f"float[{self.bits}bit]"
        if self.kind == "pointer":
            return f"pointer[to {self.inner}]"
        if self.kind == "named":
            return self.name
        if self.kind == "array":
            return f"array[{self.bits}]"
        return self.kind

    def is_numeric(self) -> bool:
        return self.kind in ("integer", "float", "byte")

    def is_comparable(self, other: "CType") -> bool:
        """Can self be compared with other?"""
        if self.kind == "unknown" or other.kind == "unknown":
            return True
        if self.kind == other.kind == "integer":
            return True
        if self.kind == other.kind == "float":
            return True
        if self.kind == other.kind == "boolean":
            return True
        if self.kind == other.kind == "text":
            return True
        if self.kind == other.kind == "byte":
            return True
        if "pointer" in (self.kind, other.kind):
            return True
        if self.kind == other.kind == "named":
            return self.name == other.name
        if self.is_numeric() and other.is_numeric():
            return True
        return False

    def is_assignable_from(self, other: "CType") -> bool:
        if self.kind == "unknown" or other.kind == "unknown":
            return True
        if self == other:
            return True
        # Allow array initialisation with a number (Section 4.2)
        if self.kind == "array" and other.is_numeric():
            return True
        # Allow struct (named) initialisation with a number (Section 4.1)
        if self.kind == "named" and other.is_numeric():
            return True
        # null → any pointer
        if self.kind == "pointer" and other.kind == "nothing":
            return True
        # numeric widening (relaxed – full check needs value‑range analysis)
        if self.is_numeric() and other.is_numeric():
            return True
        return False


# Singletons for common types – short names added for template instantiation
T_UNKNOWN  = CType("unknown", name="unknown")
T_NOTHING  = CType("nothing", name="nothing")
T_BOOL     = CType("boolean", name="i1")          # LLVM любит i1
T_BYTE     = CType("byte", name="i8")
T_TEXT     = CType("text", name="text")
T_INT32    = CType("integer", signed=True,  bits=32, name="i32")
T_UINT32   = CType("integer", signed=False, bits=32, name="u32")
T_INT64    = CType("integer", signed=True,  bits=64, name="i64")
T_FLOAT64  = CType("float",   bits=64, name="f64")


# ── Unified type name generation ──────────────────────────────────────────────

def get_type_name(ct: CType) -> str:
    """Генерирует короткое имя типа для LLVM и метаданных."""
    if ct.kind == "integer": return f"i{ct.bits}"
    if ct.kind == "boolean": return "i1"      # согласовано с T_BOOL.name
    if ct.kind == "byte":    return "i8"
    if ct.kind == "text":    return "str"
    if ct.kind == "named":   return ct.name.replace("[", "_").replace("]", "").replace(" ", "")
    if ct.kind == "pointer": return f"ptr_{get_type_name(ct.inner)}"
    return ct.kind


# ── AST type node → CType conversion (global function) ────────────────────────

def ast_type_to_ctype(node: A.TypeNode) -> CType:
    """Преобразует узел AST в канонический тип CType."""
    # Защита от None (например, когда return_type отсутствует)
    if node is None:
        return T_NOTHING

    if isinstance(node, A.NothingType):
        return T_NOTHING

    # Обработка текстовых вариантов nothing / void / Nothing
    if isinstance(node, A.NamedType) and node.name in ("nothing", "void", "Nothing"):
        return T_NOTHING

    if isinstance(node, A.IntegerType):
        name = f"i{node.bits}" if node.signed else f"u{node.bits}"
        return CType("integer", signed=node.signed, bits=node.bits, name=name)
    if isinstance(node, A.FloatType):
        return CType("float", bits=node.bits, name=f"f{node.bits}")
    if isinstance(node, A.ByteType):
        return T_BYTE
    if isinstance(node, A.BooleanType):
        return T_BOOL
    if isinstance(node, A.TextType):
        return T_TEXT
    if isinstance(node, A.PointerType):
        inner = ast_type_to_ctype(node.inner)
        return CType("pointer", inner=inner)          # имя будет построено через get_type_name при необходимости
    if isinstance(node, A.ArrayType):
        return CType("array", bits=node.size)
    if isinstance(node, A.NamedType):
        # Обработка дженериков: если есть параметры, создаём конкретное имя типа
        if hasattr(node, 'params') and node.params:
            param_names = "_".join([get_type_name(ast_type_to_ctype(p)) for p in node.params])
            concrete_name = f"{node.name}_{param_names}"
            return CType("named", name=concrete_name)
        return CType("named", name=node.name)
    return T_UNKNOWN


# ── Symbol table ──────────────────────────────────────────────────────────────

@dataclass
class Symbol:
    name: str
    ctype: CType
    is_constant: bool
    span: A.Span
    assigned: bool = False
    is_dead: bool = False
    owner_transferred_at: Optional[A.Span] = None


class Scope:
    def __init__(self, parent: Optional["Scope"] = None) -> None:
        self._symbols: dict[str, Symbol] = {}
        self.parent = parent

    def declare(self, sym: Symbol) -> bool:
        if sym.name in self._symbols:
            return False
        self._symbols[sym.name] = sym
        return True

    def lookup(self, name: str) -> Optional[Symbol]:
        if name in self._symbols:
            return self._symbols[name]
        if self.parent:
            return self.parent.lookup(name)
        return None

    def child(self) -> "Scope":
        return Scope(parent=self)


# ── Function registry ─────────────────────────────────────────────────────────

@dataclass
class FuncSignature:
    name: str
    params: list[tuple[str, CType]]
    return_type: CType
    declared_errors: set[str]
    span: A.Span


# ── Analyzer ──────────────────────────────────────────────────────────────────

class SemanticError(Exception):
    pass


class Analyzer:
    def __init__(self, module_paths: Optional[List[str]] = None) -> None:
        self.diagnostics: list[Diagnostic] = []
        self.loaded_modules: list[A.ModuleDef] = []          # список загруженных модулей
        self._funcs: dict[str, FuncSignature] = {}
        self._user_types: dict[str, CType] = {}               # alias‑defined types
        self._structs: dict[str, dict[str, CType]] = {}
        self._struct_ops: dict[str, dict[str, FuncSignature]] = {}
        self._struct_templates: dict[str, A.StructDef] = {}   # чертежи шаблонов
        self._hw_regs: dict[str, A.HardwareRegisterDef] = {}
        self._enums: dict[str, list[str]] = {}
        self._loop_depth: int = 0
        self._active_loops: list[str] = []
        self._current_func: Optional[FuncSignature] = None
        self._in_interrupt_context = False
        self._module_paths = module_paths or [os.path.join(os.path.dirname(__file__), '..', 'std')]

    # ── Public API ────────────────────────────────────────────────────────────

    def analyze_program(self, program: A.Node) -> list[Diagnostic]:
        self.diagnostics = []
        global_scope = Scope()
        self._register_builtins()

        # Загрузка зависимых модулей
        if hasattr(program, 'dependencies') and program.dependencies:
            for dep in program.dependencies:
                self._load_module(dep.name)

        # Регистрация типов основного файла
        if hasattr(program, 'type_defs'):
            for type_def in program.type_defs:
                self._register_type_def(type_def, global_scope)

        for func in program.functions:
            self._register_function(func, global_scope)

        if hasattr(program, 'interrupt_handlers'):
            for handler in program.interrupt_handlers:
                self._analyze_interrupt_handler(handler, global_scope)

        for func in program.functions:
            self._analyze_function(func, global_scope)

        self._analyze_stmts(program.body, global_scope)
        return self.diagnostics

    def _load_module(self, module_name: str) -> None:
        for path in self._module_paths:
            filepath = os.path.join(path, module_name + ".cstar")
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    source = f.read()
                parser = Parser(source, filepath)
                try:
                    module_ast = parser.parse_any()
                    self.loaded_modules.append(module_ast)    # сохраняем AST модуля
                except Exception as e:
                    self._warning(f"Failed to parse module '{module_name}': {e}", A.Span(0, 0))
                    return
                self._register_module_definitions(module_ast)
                return
        self._warning(f"Module '{module_name}' not found", A.Span(0, 0))

    def _register_module_definitions(self, module: A.ModuleDef) -> None:
        """Регистрирует всё содержимое модуля в глобальные таблицы."""
        # 1. Регистрируем типы (структуры, дженерики)
        for type_def in module.type_defs:
            self._register_type_def(type_def, Scope())
            
        # 2. Регистрируем функции модуля
        for func in module.functions:
            full_name = f"{module.name}.{func.name}"
            params = [(p.name, self._resolve_type(p.type_node, Scope())) for p in func.params]
            sig = FuncSignature(
                name=full_name,
                params=params,
                return_type=self._resolve_type(func.return_type, Scope()),
                declared_errors={g.error_name for g in func.guards},
                span=func.span
            )
            self._funcs[full_name] = sig

    def _register_type_def(self, type_def, scope: Scope) -> None:
        if isinstance(type_def, A.StructDef):
            # Шаблон (есть generic_params) – сохраняем как чертёж и его операции
            if hasattr(type_def, 'generic_params') and type_def.generic_params:
                self._struct_templates[type_def.name] = type_def
                if hasattr(type_def, 'operations'):
                    ops = {}
                    for op in type_def.operations:
                        params = [(p.name, self._resolve_type(p.type_node, scope)) for p in op.params]
                        ret = self._resolve_type(op.return_type, scope)
                        sig = FuncSignature(name=op.name, params=params, return_type=ret,
                                            declared_errors=set(), span=op.span)
                        ops[op.name] = sig
                    self._struct_ops[type_def.name] = ops
            else:
                # Обычная структура
                fields = {}
                for f in type_def.fields:
                    fields[f.name] = self._resolve_type(f.type_node, scope)
                self._structs[type_def.name] = fields
                if hasattr(type_def, 'operations'):
                    ops = {}
                    for op in type_def.operations:
                        params = [(p.name, self._resolve_type(p.type_node, scope)) for p in op.params]
                        ret = self._resolve_type(op.return_type, scope)
                        sig = FuncSignature(name=op.name, params=params, return_type=ret,
                                            declared_errors=set(), span=op.span)
                        ops[op.name] = sig
                    self._struct_ops[type_def.name] = ops
        elif isinstance(type_def, A.AliasDef):
            inner = self._resolve_type(type_def.target, scope)
            self._user_types[type_def.name] = CType("named", name=type_def.name, inner=inner,
                                                    min_val=type_def.min_val, max_val=type_def.max_val)
        elif isinstance(type_def, A.EnumDef):
            self._enums[type_def.name] = [v.name for v in type_def.variants]

    # ── Template instantiation with deep substitution ─────────────────────────

    def _get_or_create_generic_type(self, name: str, params: list[A.TypeNode]) -> CType:
        param_ctypes = [ast_type_to_ctype(p) for p in params]
        suffix = "_".join([get_type_name(t) for t in param_ctypes])
        concrete_name = f"{name}_{suffix}"

        if concrete_name in self._structs:
            return CType("named", name=concrete_name)

        template = self._struct_templates.get(name)
        if template:
            substitutions = {gp: param_ctypes[i] for i, gp in enumerate(template.generic_params)}
            
            # Рекурсивная замена ElementType -> i32
            def _deep_subst(node):
                if isinstance(node, A.NamedType) and node.name in substitutions:
                    return substitutions[node.name]
                if isinstance(node, A.PointerType):
                    return CType("pointer", inner=_deep_subst(node.inner))
                return ast_type_to_ctype(node)

            concrete_fields = {}
            for field in template.fields:
                concrete_fields[field.name] = _deep_subst(field.type_node)

            # ВАЖНО: Регистрируем поля! Без этого Codegen их не увидит.
            self._structs[concrete_name] = concrete_fields
            
            # Копируем сигнатуры методов
            self._struct_ops[concrete_name] = self._struct_ops.get(name, {})
            return CType("named", name=concrete_name)
            
        return T_UNKNOWN

    def _resolve_type(self, node: A.TypeNode, scope: Scope) -> CType:
        """Преобразует AST-узел типа в CType с учётом области видимости."""
        # Защита от None (важно для операций с returns nothing)
        if node is None:
            return T_NOTHING

        if isinstance(node, A.NamedType):
            if hasattr(node, 'params') and node.params:
                return self._get_or_create_generic_type(node.name, node.params)
            return CType("named", name=node.name)
        return ast_type_to_ctype(node)

    # ── Built‑ins & registration ──────────────────────────────────────────────

    def _register_builtins(self) -> None:
        nothing  = CType("nothing")
        int32    = CType("integer", signed=True,  bits=32, name="i32")
        uint32   = CType("integer", signed=False, bits=32, name="u32")
        float64  = CType("float",   bits=64, name="f64")
        text     = CType("text", name="text")
        boolean  = CType("boolean", name="i1")       # единообразие с T_BOOL
        dummy    = A.Span(0, 0)

        builtins = {
            "print_integer":  ([("value", int32)],   nothing),
            "print_unsigned": ([("value", uint32)],  nothing),
            "print_float":    ([("value", float64)], nothing),
            "print_text":     ([("value", text)],    nothing),
            "print_boolean":  ([("value", boolean)], nothing),
            "print_line":     ([],                   nothing),
        }
        for name, (params, ret) in builtins.items():
            self._funcs[name] = FuncSignature(name=name, params=params, return_type=ret,
                                              declared_errors=set(), span=dummy)

        self._funcs["StdIO.print_int"] = FuncSignature(
            name="StdIO.print_int", params=[("value", int32)], return_type=nothing,
            declared_errors=set(), span=dummy)
        self._funcs["StdIO.print_msg"] = FuncSignature(
            name="StdIO.print_msg", params=[("message", text)], return_type=nothing,
            declared_errors=set(), span=dummy)

    def _register_function(self, func: A.FunctionDef, scope: Scope) -> None:
        params = [(p.name, self._resolve_type(p.type_node, scope)) for p in func.params]
        errors = {g.error_name for g in func.guards}
        sig = FuncSignature(name=func.name, params=params,
                            return_type=self._resolve_type(func.return_type, scope),
                            declared_errors=errors, span=func.span)
        if func.name in self._funcs:
            self._error(f"Function '{func.name}' defined more than once", func.span)
        self._funcs[func.name] = sig

    # ── Smart function/method resolution ──────────────────────────────────────

    def _get_call_sig(self, full_name: str, scope: Scope) -> Optional[FuncSignature]:
        if "." in full_name:
            obj_name, method_name = full_name.split(".")
            sym = scope.lookup(obj_name)
            if sym and sym.ctype.kind == "named":
                ops = self._struct_ops.get(sym.ctype.name, {})
                sig = ops.get(method_name)
                if sig:
                    return sig
        return self._funcs.get(full_name)

    # ── Analysis helpers ──────────────────────────────────────────────────────

    def _analyze_function(self, func: A.FunctionDef, outer: Scope) -> None:
        prev = self._current_func
        self._current_func = self._funcs.get(func.name)
        scope = outer.child()
        for p in func.params:
            scope.declare(Symbol(p.name, self._resolve_type(p.type_node, scope), False, p.span, assigned=True))
        if func.return_name:
            scope.declare(Symbol(func.return_name,
                                self._resolve_type(func.return_type, scope),
                                False, func.span, assigned=False))
        self._analyze_stmts(func.body, scope)
        self._current_func = prev

    def _analyze_operation(self, op: A.OperationDef, struct_name: str, outer: Scope) -> None:
        scope = outer.child()
        if op.return_name:
            scope.declare(Symbol(op.return_name, self._resolve_type(op.return_type, scope),
                                 False, op.span, assigned=False))
        for p in op.params:
            scope.declare(Symbol(p.name, self._resolve_type(p.type_node, scope), False, p.span, assigned=True))
        for f_name, f_type in self._structs.get(struct_name, {}).items():
            scope.declare(Symbol(f_name, f_type, False, op.span, assigned=True))
        self._analyze_stmts(op.body, scope)

    def _analyze_interrupt_handler(self, handler: A.InterruptHandlerDef, scope: Scope) -> None:
        old = self._in_interrupt_context
        self._in_interrupt_context = True
        self._analyze_stmts(handler.body, scope.child())
        self._in_interrupt_context = old

    # ── Statement dispatch ────────────────────────────────────────────────────

    def _analyze_stmts(self, stmts: list, scope: Scope) -> None:
        for stmt in stmts:
            self._analyze_stmt(stmt, scope)

    def _analyze_stmt(self, stmt, scope: Scope) -> None:
        if isinstance(stmt, A.DeclareStmt):
            self._chk_declare(stmt, scope)
        elif isinstance(stmt, A.AssignStmt):
            self._chk_assign(stmt, scope)
        elif isinstance(stmt, A.IfStmt):
            self._chk_if(stmt, scope)
        elif isinstance(stmt, A.RepeatStmt):
            self._chk_repeat(stmt, scope)
        elif isinstance(stmt, A.CallStmt):
            self._chk_call(stmt, scope)
        elif isinstance(stmt, A.SimpleCallStmt):
            self._chk_simple_call(stmt, scope)
        elif isinstance(stmt, A.RejectStmt):
            self._chk_reject(stmt, scope)
        elif isinstance(stmt, A.StopStmt):
            self._chk_stop(stmt)
        elif isinstance(stmt, A.SkipStmt):
            self._chk_skip(stmt)
        elif isinstance(stmt, A.ReturnStmt):
            self._chk_return(stmt, scope)
        elif isinstance(stmt, A.AllocateStmt):
            self._chk_allocate(stmt, scope)
        elif isinstance(stmt, A.ReleaseStmt):
            self._chk_release(stmt, scope)
        elif isinstance(stmt, A.MethodCallStmt):
            self._chk_method_call(stmt, scope)
        elif isinstance(stmt, A.HardwareWriteStmt):
            self._chk_hw_write(stmt)
        elif isinstance(stmt, A.MatchStmt):
            self._chk_match(stmt, scope)

    # ── Individual checkers ───────────────────────────────────────────────────

    def _chk_declare(self, stmt: A.DeclareStmt, scope: Scope) -> None:
        ctype = self._resolve_type(stmt.type_node, scope)
        if ctype.kind == "named" and ctype.name in self._user_types:
            ctype = self._user_types[ctype.name]
        val_type = self._infer_expr(stmt.initial_value, scope)
        if not ctype.is_assignable_from(val_type):
            self._error(f"Type Mismatch: Cannot initialize '{stmt.name}' of type {ctype} with value of type {val_type}", stmt.span)
        self._check_range_violation(ctype, stmt.initial_value)
        sym = Symbol(name=stmt.name, ctype=ctype, is_constant=stmt.is_constant, span=stmt.span, assigned=True)
        if not scope.declare(sym):
            self._error(f"'{stmt.name}' already declared", stmt.span)

    def _chk_assign(self, stmt: A.AssignStmt, scope: Scope) -> None:
        val_type = self._infer_expr(stmt.value, scope)
        if isinstance(stmt.target, A.Identifier):
            sym = scope.lookup(stmt.target.name)
            if sym is None:
                self._error(f"'{stmt.target.name}' not declared", stmt.target.span)
                return
            if sym.is_dead:
                self._error(f"OWNERSHIP VIOLATION: '{sym.name}' was already transferred as owner", stmt.span)
                return
            if sym.is_constant:
                self._error(f"'{sym.name}' is constant", stmt.span)
                return
            if not sym.ctype.is_assignable_from(val_type):
                self._error(f"Type Mismatch: Cannot assign {val_type} to '{sym.name}' of type {sym.ctype}", stmt.span)
            self._check_range_violation(sym.ctype, stmt.value)
            sym.assigned = True
        elif isinstance(stmt.target, A.FieldAccess):
            self._infer_expr(stmt.target, scope)
        elif isinstance(stmt.target, A.ValueAt):
            self._infer_expr(stmt.target.pointer, scope)

    def _check_range_violation(self, target_ctype: CType, value_expr: A.ExprNode) -> None:
        if target_ctype.min_val is not None and isinstance(value_expr, A.IntLiteral):
            val = value_expr.value
            if val < target_ctype.min_val or val > target_ctype.max_val:
                self._error(f"RANGE VIOLATION: Value {val} outside range [{target_ctype.min_val}, {target_ctype.max_val}] for type {target_ctype.name}", value_expr.span)

    def _chk_if(self, stmt: A.IfStmt, scope: Scope) -> None:
        self._infer_expr(stmt.condition, scope)
        self._analyze_stmts(stmt.then_body, scope.child())
        for cond, body in stmt.elseif_branches:
            self._infer_expr(cond, scope)
            self._analyze_stmts(body, scope.child())
        if stmt.else_body:
            self._analyze_stmts(stmt.else_body, scope.child())

    def _chk_repeat(self, stmt: A.RepeatStmt, scope: Scope) -> None:
        self._infer_expr(stmt.condition, scope)
        if stmt.loop_name:
            self._active_loops.append(stmt.loop_name)
        self._loop_depth += 1
        self._analyze_stmts(stmt.body, scope.child())
        self._loop_depth -= 1
        if stmt.loop_name:
            self._active_loops.pop()

    def _chk_call(self, stmt: A.CallStmt, scope: Scope) -> None:
        from ..parser.ast import OwnershipMode
        sig = self._get_call_sig(stmt.func_name, scope)
        if sig is None:
            if "." in stmt.func_name:
                obj = stmt.func_name.split(".")[0]
                if scope.lookup(obj):
                    self._warning(f"Function '{stmt.func_name}' not found (maybe external module)", stmt.span)
                else:
                    self._error(f"Unknown function '{stmt.func_name}'", stmt.span)
            else:
                self._error(f"Unknown function '{stmt.func_name}'", stmt.span)
            for h in stmt.handlers:
                self._analyze_stmts(h.body, scope.child())
            return
        provided = {name for name, _, __ in stmt.args}
        expected = {name for name, _ in sig.params}
        for missing in expected - provided:
            self._error(f"Call to '{stmt.func_name}' missing argument '{missing}'", stmt.span)
        for extra in provided - expected:
            self._error(f"Call to '{stmt.func_name}' unexpected argument '{extra}'", stmt.span)
        param_map = dict(sig.params)
        for arg_name, arg_mode, arg_expr in stmt.args:
            if arg_name in param_map:
                arg_type = self._infer_expr(arg_expr, scope)
                expected_type = param_map[arg_name]
                if not expected_type.is_assignable_from(arg_type):
                    self._error(f"Argument '{arg_name}' expects {expected_type} but got {arg_type}", arg_expr.span)
        for arg_name, arg_mode, arg_expr in stmt.args:
            if arg_mode == OwnershipMode.OWNER:
                if isinstance(arg_expr, A.Identifier):
                    sym = scope.lookup(arg_expr.name)
                    if sym:
                        if sym.is_dead:
                            self._error(f"OWNERSHIP VIOLATION: '{sym.name}' was already transferred as owner", arg_expr.span)
                        sym.is_dead = True
                        sym.owner_transferred_at = stmt.span
        handler_kinds = [h.kind for h in stmt.handlers]
        if "success" not in handler_kinds:
            self._error(f"Call to '{stmt.func_name}' missing 'on success' handler", stmt.span)
        error_handlers = [h for h in stmt.handlers if h.kind == "error"]
        if sig.declared_errors and not error_handlers:
            self._error(f"Call to '{stmt.func_name}' missing 'on error' handler(s)", stmt.span)
        for handler in stmt.handlers:
            self._analyze_stmts(handler.body, scope.child())

    def _chk_simple_call(self, stmt: A.SimpleCallStmt, scope: Scope) -> None:
        sig = self._get_call_sig(stmt.func_name, scope)
        if sig is None:
            self._warning(f"Function '{stmt.func_name}' not found", stmt.span)
            return
        if sig.return_type.kind != "nothing":
            self._error(f"'{stmt.func_name}' returns {sig.return_type}, use 'call ... on success' instead", stmt.span)
        if len(stmt.args) != len(sig.params):
            self._error(f"'{stmt.func_name}' expects {len(sig.params)} arg(s), got {len(stmt.args)}", stmt.span)
        for expr in stmt.args:
            self._infer_expr(expr, scope)

    def _chk_method_call(self, stmt: A.MethodCallStmt, scope: Scope) -> None:
        obj_type = self._infer_expr(stmt.obj, scope)
        if obj_type.kind != "named":
            self._error(f"Method call on non-struct type {obj_type}", stmt.span)
            return
        ops = self._struct_ops.get(obj_type.name, {})
        sig = ops.get(stmt.method_name)
        if sig is None:
            self._error(f"Struct '{obj_type.name}' has no operation '{stmt.method_name}'", stmt.span)
            return
        if len(stmt.args) != len(sig.params):
            self._error(f"'{stmt.method_name}' expects {len(sig.params)} arg(s), got {len(stmt.args)}", stmt.span)
        for a in stmt.args:
            self._infer_expr(a, scope)
        if sig.return_type.kind != "nothing":
            self._error(f"'{stmt.method_name}' returns {sig.return_type}, use 'call ... on success' instead", stmt.span)

    def _chk_reject(self, stmt: A.RejectStmt, scope: Scope) -> None:
        if self._current_func is None:
            self._error("'reject' used outside a function", stmt.span)
            return
        if stmt.error_name not in self._current_func.declared_errors:
            self._error(f"Error '{stmt.error_name}' not declared in function '{self._current_func.name}'", stmt.span)

    def _chk_stop(self, stmt: A.StopStmt) -> None:
        if self._loop_depth == 0:
            self._error("'stop' used outside a 'repeat while' block", stmt.span)
        if stmt.loop_name and stmt.loop_name not in self._active_loops:
            self._error(f"LOOP ERROR: No active loop named '{stmt.loop_name}'", stmt.span)

    def _chk_skip(self, stmt: A.SkipStmt) -> None:
        if self._loop_depth == 0:
            self._error("'skip' used outside a 'repeat while' block", stmt.span)

    def _chk_return(self, stmt: A.ReturnStmt, scope: Scope) -> None:
        if stmt.value is not None:
            self._infer_expr(stmt.value, scope)

    def _chk_allocate(self, stmt: A.AllocateStmt, scope: Scope) -> None:
        if self._in_interrupt_context:
            self._error("FORBIDDEN OPERATION: Memory allocation is forbidden inside interrupt handlers (Section 5.3)", stmt.span)
            return
        self._infer_expr(stmt.size, scope)
        sym = scope.lookup(stmt.name)
        if sym is None:
            self._error(f"'{stmt.name}' is not declared", stmt.span)
        elif sym.ctype.kind != "pointer":
            self._error(f"'allocate' target '{stmt.name}' must be a pointer type, got {sym.ctype}", stmt.span)

    def _chk_release(self, stmt: A.ReleaseStmt, scope: Scope) -> None:
        sym = scope.lookup(stmt.name)
        if sym is None:
            self._error(f"'{stmt.name}' is not declared", stmt.span)
        elif sym.ctype.kind not in ("pointer", "array"):
            self._error(f"'release' target '{stmt.name}' must be a pointer or array type, got {sym.ctype}", stmt.span)

    def _chk_hw_write(self, stmt: A.HardwareWriteStmt) -> None:
        reg = self._hw_regs.get(stmt.reg_name)
        if reg is None:
            self._error(f"Unknown hardware register '{stmt.reg_name}'", stmt.span)
            return
        if "write" not in reg.access:
            self._error(f"HARDWARE VIOLATION: Register '{stmt.reg_name}' is read-only", stmt.span)

    def _chk_match(self, stmt: A.MatchStmt, scope: Scope) -> None:
        expr_type = self._infer_expr(stmt.expr, scope)
        if expr_type.kind != "named":
            self._error("Match can only be used on Enum types", stmt.span)
            return
        expected = self._enums.get(expr_type.name)
        if not expected:
            self._error(f"Type '{expr_type.name}' is not an Enum", stmt.span)
            return
        handled = [c.variant_name for c in stmt.cases]
        missing = set(expected) - set(handled)
        if missing:
            self._error(f"INCOMPLETE MATCH: Missing variants: {', '.join(missing)}. Section 3.1 requires all states.", stmt.span)
        for case in stmt.cases:
            self._analyze_stmts(case.body, scope.child())

    # ── Expression inference ──────────────────────────────────────────────────

    def _infer_expr(self, expr, scope: Scope) -> CType:
        if isinstance(expr, A.IntLiteral):
            return T_INT32
        if isinstance(expr, A.FloatLiteral):
            return T_FLOAT64
        if isinstance(expr, A.BoolLiteral):
            return T_BOOL
        if isinstance(expr, A.TextLiteral):
            return T_TEXT
        if isinstance(expr, A.NullLiteral):
            return T_NOTHING

        if isinstance(expr, A.Identifier):
            sym = scope.lookup(expr.name)
            if sym is None:
                self._error(f"'{expr.name}' is not declared", expr.span)
                return T_UNKNOWN
            if sym.is_dead:
                self._error(f"OWNERSHIP VIOLATION: Variable '{expr.name}' no longer exists. It was transferred as owner at {sym.owner_transferred_at}", expr.span)
                return T_UNKNOWN
            ctype = sym.ctype
            if ctype.kind == "named" and ctype.name in self._user_types:
                ctype = self._user_types[ctype.name]
            return ctype

        if isinstance(expr, A.FieldAccess):
            obj_type = self._infer_expr(expr.obj, scope)
            if obj_type.kind == "named":
                field_map = self._structs.get(obj_type.name, {})
                if expr.field in field_map:
                    return field_map[expr.field]
                self._error(f"Struct '{obj_type.name}' has no field '{expr.field}'", expr.span)
            elif obj_type.kind != "unknown":
                self._warning(f"Field access on non-struct type {obj_type}", expr.span)
            return T_UNKNOWN

        if isinstance(expr, A.MethodCallExpr):
            obj_type = self._infer_expr(expr.obj, scope)
            if obj_type.kind == "named":
                ops = self._struct_ops.get(obj_type.name, {})
                sig = ops.get(expr.method)
                if sig is None:
                    self._error(f"Struct '{obj_type.name}' has no operation '{expr.method}'", expr.span)
                    return T_UNKNOWN
                if len(expr.args) != len(sig.params):
                    self._error(f"'{expr.method}' expects {len(sig.params)} arg(s), got {len(expr.args)}", expr.span)
                for a in expr.args:
                    self._infer_expr(a, scope)
                return sig.return_type
            else:
                self._error(f"Type {obj_type} does not support methods", expr.span)
                return T_UNKNOWN

        if isinstance(expr, A.BinaryOp):
            left = self._infer_expr(expr.left, scope)
            right = self._infer_expr(expr.right, scope)
            if not (left.is_numeric() or left.kind == "unknown") or not (right.is_numeric() or right.kind == "unknown"):
                self._error(f"Arithmetic '{expr.op}' requires numeric operands, got {left} and {right}", expr.span)
            return left if left.kind != "unknown" else right

        if isinstance(expr, A.CompareOp):
            left = self._infer_expr(expr.left, scope)
            right = self._infer_expr(expr.right, scope)
            if not left.is_comparable(right):
                self._error(f"Cannot compare {left} with {right}", expr.span)
            return T_BOOL

        if isinstance(expr, A.LogicOp):
            left = self._infer_expr(expr.left, scope)
            right = self._infer_expr(expr.right, scope)
            for t, side in ((left, "left"), (right, "right")):
                if t.kind not in ("boolean", "unknown"):
                    self._error(f"'{expr.op}' requires boolean operands, {side} side is {t}", expr.span)
            return T_BOOL

        if isinstance(expr, A.NotOp):
            t = self._infer_expr(expr.operand, scope)
            if t.kind not in ("boolean", "unknown"):
                self._error(f"'not' requires a boolean operand, got {t}", expr.span)
            return T_BOOL

        if isinstance(expr, A.AddressOf):
            from ..parser.ast import OwnershipMode
            sym = scope.lookup(expr.name)
            if sym is None:
                self._error(f"'{expr.name}' is not declared", expr.span)
                return T_UNKNOWN
            if sym.is_dead:
                self._error(f"OWNERSHIP VIOLATION: '{sym.name}' was already transferred as owner", expr.span)
                return T_UNKNOWN
            if expr.mode == OwnershipMode.OWNER:
                sym.is_dead = True
                sym.owner_transferred_at = expr.span
            return CType("pointer", inner=sym.ctype)

        if isinstance(expr, A.ValueAt):
            ptr_type = self._infer_expr(expr.pointer, scope)
            if ptr_type.kind == "pointer" and ptr_type.inner:
                return ptr_type.inner
            if ptr_type.kind != "unknown":
                self._error(f"'value at' requires a pointer, got {ptr_type}", expr.span)
            return T_UNKNOWN

        if isinstance(expr, A.SizeOf):
            return T_UINT32

        if isinstance(expr, A.ConvertExpr):
            self._infer_expr(expr.value, scope)
            return self._resolve_type(expr.target_type, scope)

        if isinstance(expr, A.CallExpr):
            sig = self._get_call_sig(expr.func_name, scope)
            if sig is None:
                self._error(f"Function '{expr.func_name}' not declared", expr.span)
                return T_UNKNOWN
            if len(expr.args) != len(sig.params):
                self._error(f"'{expr.func_name}' expects {len(sig.params)} arg(s), got {len(expr.args)}", expr.span)
            return sig.return_type

        return T_UNKNOWN

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _error(self, message: str, span: A.Span) -> None:
        self.diagnostics.append(Diagnostic("error", message, span))

    def _warning(self, message: str, span: A.Span) -> None:
        self.diagnostics.append(Diagnostic("warning", message, span))
