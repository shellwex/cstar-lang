"""
C* Compiler — AST nodes
Every construct in C* maps to exactly one node class.
All nodes are frozen dataclasses — immutable after creation.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from ..lexer.token import Span


# ── Ownership mode ───────────────────────────────────────────────────────────
# Used in: address-of expressions, parameter declarations, call arguments,
# and function return declarations.
# Section 2.3 — Ownership

from enum import Enum

class OwnershipMode(Enum):
    COPY   = "copy"    # as copy   — independent copy, caller keeps original
    OWNER  = "owner"   # as owner  — transfer ownership, original becomes dead
    ACCESS = "access"  # as access — borrow only, must not outlive owner
    NONE   = "none"    # not specified (stack variables, plain expressions)


# ── Base ─────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Node:
    span: Span


# ── Types ─────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class IntegerType(Node):
    """integer[signed, 32bit]"""
    signed: bool          # True = signed, False = unsigned
    bits: int             # 8 / 16 / 32 / 64

@dataclass(frozen=True)
class FloatType(Node):
    """float[32bit] / float[64bit]"""
    bits: int             # 32 / 64

@dataclass(frozen=True)
class ByteType(Node):
    """byte"""
    pass

@dataclass(frozen=True)
class BooleanType(Node):
    """boolean"""
    pass

@dataclass(frozen=True)
class TextType(Node):
    """text"""
    pass

@dataclass(frozen=True)
class NothingType(Node):
    """nothing"""
    pass

@dataclass(frozen=True)
class PointerType(Node):
    """pointer[to <inner>]"""
    inner: TypeNode

@dataclass(frozen=True)
class NamedType(Node):
    """User-defined type name: AudioSample, ConnectionState, …"""
    name: str

@dataclass(frozen=True)
class ArrayType(Node):
    """array[type, size]"""
    element_type: TypeNode
    size: int  # В Phase 1 — фиксированный размер

# Union alias for all type nodes
TypeNode = (
    IntegerType | FloatType | ByteType | BooleanType |
    TextType | NothingType | PointerType | NamedType |
    ArrayType
)


# ── Expressions ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class IntLiteral(Node):
    value: int

@dataclass(frozen=True)
class FloatLiteral(Node):
    value: float

@dataclass(frozen=True)
class BoolLiteral(Node):
    value: bool

@dataclass(frozen=True)
class TextLiteral(Node):
    value: str

@dataclass(frozen=True)
class NullLiteral(Node):
    pass

@dataclass(frozen=True)
class Identifier(Node):
    name: str

@dataclass(frozen=True)
class FieldAccess(Node):
    """expr.field"""
    obj: ExprNode
    field: str

@dataclass(frozen=True)
class BinaryOp(Node):
    """left <op> right   — arithmetic or comparison"""
    op: str               # "plus" | "minus" | "multiply" | "divide" | "remainder"
    left: ExprNode
    right: ExprNode

@dataclass(frozen=True)
class CompareOp(Node):
    """left <cmp> right"""
    op: str               # "is equal to" | "is greater than" | …
    left: ExprNode
    right: ExprNode

@dataclass(frozen=True)
class LogicOp(Node):
    """left and/or right"""
    op: str               # "and" | "or"
    left: ExprNode
    right: ExprNode

@dataclass(frozen=True)
class NotOp(Node):
    operand: ExprNode

@dataclass(frozen=True)
class BitwiseOp(Node):
    """bits of left [and/or/xor] bits of right"""
    op: str               # "and", "or", "xor"
    left: ExprNode
    right: ExprNode

@dataclass(frozen=True)
class ShiftOp(Node):
    """bits of value shifted [left/right] by amount"""
    direction: str        # "left", "right"
    value: ExprNode
    amount: ExprNode

@dataclass(frozen=True)
class SizeOf(Node):
    """size of <type>"""
    target: TypeNode

@dataclass(frozen=True)
class AddressOf(Node):
    """address of <name> as <mode>
    Section 2.5: address of value as access / as owner / as copy"""
    name: str
    mode: "OwnershipMode" = None  # required in strict mode

@dataclass(frozen=True)
class ValueAt(Node):
    """value at <expr>"""
    pointer: ExprNode

@dataclass(frozen=True)
class ConvertExpr(Node):
    """convert <expr> to <type>  on overflow <handler>"""
    value: ExprNode
    target_type: TypeNode
    on_overflow: list[StmtNode]   # Блок инструкций при ошибке переполнения

@dataclass(frozen=True)
class CallExpr(Node):
    """func_name receives arg1 and arg2"""
    func_name: str
    args: list[ExprNode]

@dataclass(frozen=True)
class MethodCallExpr(Node):
    """obj.method receives args"""
    obj: ExprNode
    method: str
    args: list[ExprNode]

@dataclass(frozen=True)
class ArrayIndex(Node):
    """target at index index_expr"""
    target: ExprNode
    index_expr: ExprNode

ExprNode = (
    IntLiteral | FloatLiteral | BoolLiteral | TextLiteral | NullLiteral |
    Identifier | FieldAccess | BinaryOp | CompareOp | LogicOp | NotOp |
    BitwiseOp | ShiftOp |
    SizeOf | AddressOf | ValueAt | ConvertExpr | CallExpr | MethodCallExpr |
    ArrayIndex
)


# ── Statements ────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class DeclareStmt(Node):
    """declare [constant] <type> named <name> [on stack|heap] is <value>"""
    type_node: TypeNode
    name: str
    initial_value: ExprNode
    is_constant: bool = False
    location: Optional[str] = None    # "stack" | "heap" | None

@dataclass(frozen=True)
class AssignStmt(Node):
    """<name> is <expr>   or   <field_access> is <expr>"""
    target: ExprNode      # Identifier or FieldAccess or ValueAt
    value: ExprNode

@dataclass(frozen=True)
class ReturnStmt(Node):
    """return <expr>  — inside body, assigns named return var"""
    value: Optional[ExprNode]

@dataclass(frozen=True)
class RejectStmt(Node):
    """reject with error[Name]"""
    error_name: str

@dataclass(frozen=True)
class StopStmt(Node):
    """stop  [loop[name]]"""
    loop_name: Optional[str] = None

@dataclass(frozen=True)
class SkipStmt(Node):
    """skip  [loop[name]]"""
    loop_name: Optional[str] = None

@dataclass(frozen=True)
class IfStmt(Node):
    """if <cond> ... [otherwise if ...] [otherwise ...] end if"""
    condition: ExprNode
    then_body: list[StmtNode]
    elseif_branches: list[tuple[ExprNode, list[StmtNode]]]
    else_body: Optional[list[StmtNode]]

@dataclass(frozen=True)
class RepeatStmt(Node):
    """repeat while <cond> [named <loop_name>] ... end repeat"""
    condition: ExprNode
    body: list[StmtNode]
    loop_name: Optional[str] = None
    max_iterations: Optional[int] = None
    on_limit_body: list[StmtNode] = field(default_factory=list)

@dataclass(frozen=True)
class OnHandler(Node):
    """on error[Name] / on success / on overflow — inside call"""
    kind: str             # "error" | "success" | "overflow" | condition-expr
    error_name: Optional[str]
    body: list[StmtNode]

@dataclass(frozen=True)
class CallStmt(Node):
    """call <func> with <args> on error/success end call
    Section 1.6: with param_name as mode: value"""
    func_name: str
    args: list[tuple[str, "OwnershipMode", ExprNode]]  # [(name, mode, value)]
    handlers: list[OnHandler]

@dataclass(frozen=True)
class SimpleCallStmt(Node):
    """<func> receives <arg> and <arg>  — nothing-returning call"""
    func_name: str
    args: list[ExprNode]

@dataclass(frozen=True)
class AllocateStmt(Node):
    """allocate <size> bytes for <name>"""
    name: str
    size: ExprNode

@dataclass(frozen=True)
class ReleaseStmt(Node):
    """release <name>"""
    name: str

StmtNode = (
    DeclareStmt | AssignStmt | ReturnStmt | RejectStmt |
    StopStmt | SkipStmt | IfStmt | RepeatStmt |
    CallStmt | SimpleCallStmt | AllocateStmt | ReleaseStmt
)


# ── Function ──────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Param(Node):
    type_node: TypeNode
    name: str
    mode: "OwnershipMode" = None  # as owner / as access / as copy on param

@dataclass(frozen=True)
class OnGuard(Node):
    """on <condition-expr>  reject with error[Name]  — in function header"""
    condition: ExprNode
    error_name: str

@dataclass(frozen=True)
class FunctionDef(Node):
    name: str
    params: list[Param]               # empty list if receives nothing
    return_type: TypeNode             # NothingType if returns nothing
    return_name: Optional[str]        # named return variable
    guards: list[OnGuard]
    stops_when: Optional[ExprNode]   # recursion stop condition
    body: list[StmtNode]
    visibility: str = "private"       # "public" | "private" | "internal"


# ── Operation definition (belongs to a struct) ───────────────────────────────

@dataclass(frozen=True)
class OperationDef(Node):
    """Struct operation — like a function but bound to a type"""
    name: str
    params: list[Param]
    return_type: TypeNode
    return_name: Optional[str]        # named return variable
    body: list[StmtNode]


# ── Interrupt handler definition ─────────────────────────────────────────────

@dataclass(frozen=True)
class InterruptHandlerDef(Node):
    """Interrupt service routine with a vector and a body"""
    name: str
    vector: int
    body: list[StmtNode]


# ── Type definitions ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class StructField(Node):
    type_node: TypeNode
    name: str

@dataclass(frozen=True)
class StructDef(Node):
    name: str
    fields: list[StructField]
    operations: list[OperationDef]   # operations bound to this struct
    alignment: int                    # bytes

@dataclass(frozen=True)
class EnumVariant(Node):
    name: str

@dataclass(frozen=True)
class EnumDef(Node):
    name: str
    variants: list[EnumVariant]

@dataclass(frozen=True)
class AliasDef(Node):
    """define type[Name] as <type>"""
    name: str
    target: TypeNode
    min_val: Optional[int] = None     # Минимальное значение (для диапазонов)
    max_val: Optional[int] = None     # Максимальное значение (для диапазонов)

TypeDefNode = StructDef | EnumDef | AliasDef


# ── Module / Program ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ModuleDef(Node):
    name: str
    functions: list[FunctionDef]
    type_defs: list[TypeDefNode]
    body: list[StmtNode]              # module-level init (on module load)
    interrupt_handlers: list[InterruptHandlerDef] = field(default_factory=list)

@dataclass(frozen=True)
class ProgramDef(Node):
    name: str
    functions: list[FunctionDef]
    type_defs: list[TypeDefNode]
    body: list[StmtNode]              # program body block
    interrupt_handlers: list[InterruptHandlerDef] = field(default_factory=list)
