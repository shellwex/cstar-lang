"""
C* Compiler — Stage 7: Linking
Transpiles LLVM IR (produced by Stage 6) to C, then compiles with gcc.

Why not clang/llc directly?
    In many environments (Termux, minimal Linux) clang and llc are not
    installed. gcc is almost always available. The IR that Stage 6 produces
    is a restricted subset — alloca/store/load/add/icmp/br/call/ret — which
    maps cleanly to C without needing the full LLVM toolchain.

Pipeline:
    .cstar → [Stage 1-6] → LLVM IR → [Stage 7] → .c → gcc → binary
"""

from __future__ import annotations
import os
import re
import subprocess
import tempfile
from dataclasses import dataclass, field
from typing import Optional


# ── Result ────────────────────────────────────────────────────────────────────

@dataclass
class LinkResult:
    success:     bool
    output_path: str = ""
    error:       str = ""
    c_source:    str = ""   # generated C (for --emit-c / debugging)


# ── IR → C transpiler ─────────────────────────────────────────────────────────

class IRTranspiler:
    """
    Converts the restricted LLVM IR subset that C* codegen produces into
    a valid C source file that gcc can compile.

    Supported IR constructs:
        Global string constants  (@name = ... constant [...] c"...")
        Function definitions     (define TYPE @name(...) { ... })
        alloca                   (stack slot declaration)
        store / load             (write / read slot)
        trunc / sext / zext      (integer conversion)
        sitofp / fptosi / uitofp / fptoui
        add / sub / mul / sdiv   (arithmetic)
        icmp slt/sgt/sle/sge/eq/ne
        br / conditional br      (gotos + labels)
        call                     (function calls, including printf)
        ret                      (return)
    """

    def __init__(self):
        self._lines: list[str] = []
        self._globals: dict[str, str] = {}   # IR name → C string literal
        self._slots: dict[str, str]   = {}   # alloca name → C type
        self._temps: dict[str, str]   = {}   # %tN → expression string
        self._out:   list[str]        = []

    # ── Public entry point ────────────────────────────────────────────────────

    def transpile(self, ir: str) -> str:
        self._lines = [l.rstrip() for l in ir.splitlines()]
        self._out = []

        self._emit("#include <stdio.h>")
        self._emit("#include <stdlib.h>")
        self._emit("#include <stdint.h>")
        self._emit("")

        # Collect global string constants first
        self._collect_globals()

        # Emit them as C string literals
        for ir_name, (c_name, c_val) in self._globals.items():
            self._emit(f'static const char {c_name}[] = {c_val};')
        if self._globals:
            self._emit("")

        # Process function definitions
        i = 0
        while i < len(self._lines):
            line = self._lines[i]
            if line.startswith("define "):
                i = self._process_function(i)
            else:
                i += 1

        return "\n".join(self._out)

    # ── Globals ───────────────────────────────────────────────────────────────

    def _collect_globals(self):
        for line in self._lines:
            # @fmt.int = private unnamed_addr constant [4 x i8] c"%d\0A\00"
            # @str.0   = private unnamed_addr constant [15 x i8] c"Hello from C*!\00"
            m = re.match(r'@([\w.]+)\s*=.*?c"(.*)"', line)
            if m:
                ir_name = m.group(1)
                raw     = m.group(2)
                # ir name → valid C identifier: replace dots with underscores
                c_name  = "g_" + re.sub(r'[.\-]', '_', ir_name)
                c_str   = self._ir_string_to_c(raw)
                # ir_name → (c_variable_name, string_literal)
                self._globals[ir_name] = (c_name, f'"{c_str}"')

    def _ir_string_to_c(self, raw: str) -> str:
        """Convert IR c"..." content to C string content."""
        result = []
        i = 0
        while i < len(raw):
            if raw[i] == "\\" and i + 2 < len(raw):
                hex_byte = raw[i+1:i+3]
                try:
                    val = int(hex_byte, 16)
                    if val == 0:
                        pass  # NUL terminator — C handles it
                    elif val == 10:
                        result.append("\\n")
                    elif val == 13:
                        result.append("\\r")
                    elif val == 9:
                        result.append("\\t")
                    elif 32 <= val < 127:
                        result.append(chr(val))
                    else:
                        result.append(f"\\x{hex_byte}")
                    i += 3
                    continue
                except ValueError:
                    pass
            result.append(raw[i])
            i += 1
        return "".join(result)

    # ── Functions ─────────────────────────────────────────────────────────────

    def _process_function(self, start: int) -> int:
        """Process one function definition. Returns index after closing '}'."""
        self._slots = {}
        self._temps = {}

        header = self._lines[start]
        # define i32 @main() {  or  define i32 @add_numbers(i32 %arg_x, i32 %arg_y) {
        m = re.match(r'define\s+(\S+)\s+@(\w+)\((.*?)\)', header)
        if not m:
            return start + 1

        ret_type = self._ir_type_to_c(m.group(1))
        func_name = m.group(2)
        params_ir = m.group(3).strip()

        params_c = self._parse_params(params_ir)
        self._emit(f"{ret_type} {func_name}({params_c}) {{")

        # Collect all alloca first for declarations at top of function
        body_lines = []
        i = start + 1
        while i < len(self._lines) and self._lines[i] != "}":
            body_lines.append(self._lines[i])
            i += 1

        # First pass: collect allocas
        for bl in body_lines:
            bl = bl.strip()
            am = re.match(r'%(\w+)\s*=\s*alloca\s+(\S+)', bl)
            if am:
                slot_name = am.group(1)
                ir_type   = am.group(2)
                c_type    = self._ir_type_to_c(ir_type)
                self._slots[slot_name] = c_type
                self._emit(f"    {c_type} {slot_name};")

        self._emit("")   # blank line after declarations

        # Second pass: emit statements
        skip_entry_label = True
        for bl in body_lines:
            bl_stripped = bl.strip()
            if not bl_stripped or bl_stripped.startswith(";"):
                continue
            # Labels (basic blocks)
            if re.match(r'^[\w.]+:$', bl_stripped):
                label = bl_stripped[:-1]
                if label == "entry" and skip_entry_label:
                    skip_entry_label = False
                    continue
                self._emit(f"  {label}:;")
                continue
            self._emit_statement(bl_stripped)

        self._emit("}")
        self._emit("")
        return i + 1  # skip closing '}'

    def _parse_params(self, params_ir: str) -> str:
        if not params_ir or params_ir == "...":
            return "void" if not params_ir else "..."
        parts = []
        for p in params_ir.split(","):
            p = p.strip()
            if not p:
                continue
            tokens = p.split()
            if len(tokens) >= 2:
                c_type = self._ir_type_to_c(tokens[0])
                c_name = tokens[-1].lstrip("%")
                parts.append(f"{c_type} {c_name}")
            else:
                parts.append(self._ir_type_to_c(tokens[0]))
        return ", ".join(parts) if parts else "void"

    # ── Statement emitter ─────────────────────────────────────────────────────

    def _emit_statement(self, line: str):
        # %TMP = trunc/sext/zext/sitofp/fptosi TYPE %VAL to TARGET_TYPE
        m = re.match(r'%(\w+)\s*=\s*(trunc|sext|zext|sitofp|fptosi|uitofp|fptoui)\s+(\S+)\s+(.+?)\s+to\s+(\S+)', line)
        if m:
            tmp = m.group(1)
            op  = m.group(2)
            src_val = self._resolve_operand(m.group(4))
            dst_type = self._ir_type_to_c(m.group(5))
            
            self._temps[tmp] = tmp
            # В C это просто явное приведение типа: (int8_t)big_val
            self._emit(f"    {dst_type} {tmp} = ({dst_type}){src_val};")
            return

        # store TYPE VALUE, ptr %SLOT
        m = re.match(r'store\s+(\S+)\s+(.+?),\s*ptr\s+%(\w+)', line)
        if m:
            val = self._resolve_val(m.group(1), m.group(2))
            slot = m.group(3)
            self._emit(f"    {slot} = {val};")
            return

        # %TMP = load TYPE, ptr %SLOT
        m = re.match(r'%(\w+)\s*=\s*load\s+(\S+),\s*ptr\s+%(\w+)', line)
        if m:
            tmp      = m.group(1)
            ir_type  = m.group(2)
            slot     = m.group(3)
            c_type   = self._ir_type_to_c(ir_type)
            # Always emit as a named variable so it can be used in br/icmp
            self._temps[tmp] = tmp
            self._emit(f"    {c_type} {tmp} = {slot};")
            return

        # %TMP = add/sub/mul/sdiv TYPE %A, %B
        m = re.match(r'%(\w+)\s*=\s*(add|sub|mul|sdiv|udiv)\s+\S+\s+(.+?),\s*(.+)', line)
        if m:
            tmp  = m.group(1)
            op   = {"add": "+", "sub": "-", "mul": "*", "sdiv": "/", "udiv": "/"}[m.group(2)]
            lhs  = self._resolve_operand(m.group(3))
            rhs  = self._resolve_operand(m.group(4))
            self._temps[tmp] = tmp
            self._emit(f"    int32_t {tmp} = ({lhs} {op} {rhs});")
            return

        # %TMP = icmp PRED TYPE %A, %B
        m = re.match(r'%(\w+)\s*=\s*icmp\s+(\w+)\s+\S+\s+(.+?),\s*(.+)', line)
        if m:
            tmp  = m.group(1)
            pred = m.group(2)
            lhs  = self._resolve_operand(m.group(3))
            rhs  = self._resolve_operand(m.group(4))
            op_map = {"slt": "<", "sgt": ">", "sle": "<=", "sge": ">=",
                      "eq": "==", "ne": "!=", "ult": "<", "ugt": ">"}
            cop  = op_map.get(pred, "==")
            self._temps[tmp] = tmp
            self._emit(f"    int {tmp} = ({lhs} {cop} {rhs});")
            return

        # br i1 %COND, label %TRUE, label %FALSE
        m = re.match(r'br\s+i1\s+%(\w+),\s*label\s+%(\w+),\s*label\s+%(\w+)', line)
        if m:
            cond  = self._resolve_operand(m.group(1))
            true_ = m.group(2)
            false_= m.group(3)
            self._emit(f"    if ({cond}) goto {true_}; else goto {false_};")
            return

        # br label %TARGET
        m = re.match(r'br\s+label\s+%(\w+)', line)
        if m:
            self._emit(f"    goto {m.group(1)};")
            return

        # ret TYPE VALUE  /  ret void
        m = re.match(r'ret\s+(\S+)\s*(.*)', line)
        if m:
            if m.group(1) == "void":
                self._emit("    return;")
            else:
                val = self._resolve_operand(m.group(2))
                self._emit(f"    return {val};")
            return

        # %TMP = call ... @FUNC(...)  or  call ... @FUNC(...)
        m = re.match(r'(?:%(\w+)\s*=\s*)?call\s+.+?@(\w+)\((.*)\)', line)
        if m:
            ret_tmp  = m.group(1)
            func     = m.group(2)
            args_raw = m.group(3)
            args_c   = self._parse_call_args(args_raw)

            if func == "printf":
                call_expr = f'printf({args_c})'
            elif func == "malloc":
                call_expr = f'malloc({args_c})'
            elif func == "free":
                call_expr = f'free({args_c})'
            elif func == "putchar":
                call_expr = f'putchar({args_c})'
            else:
                call_expr = f'{func}({args_c})'

            if ret_tmp:
                self._temps[ret_tmp] = call_expr
                # If temp is never stored, emit as statement anyway
                self._emit(f"    {call_expr};")
            else:
                self._emit(f"    {call_expr};")
            return

        # alloca already handled in first pass — skip
        if re.match(r'%\w+\s*=\s*alloca', line):
            return

    # ── Call argument parser ──────────────────────────────────────────────────

    def _parse_call_args(self, args_raw: str) -> str:
        if not args_raw.strip():
            return ""
        parts = []
        # Split by comma but respect nested parens
        depth = 0
        cur   = []
        for ch in args_raw:
            if ch == "(" : depth += 1
            elif ch == ")": depth -= 1
            if ch == "," and depth == 0:
                parts.append("".join(cur).strip())
                cur = []
            else:
                cur.append(ch)
        if cur:
            parts.append("".join(cur).strip())

        c_args = []
        for part in parts:
            part = part.strip()
            if not part:
                continue
            # ptr @global_name  →  global C name
            m = re.match(r'ptr\s+@([\w.]+)', part)
            if m:
                ir_name = m.group(1)
                if ir_name in self._globals:
                    c_args.append(self._globals[ir_name][0])
                else:
                    c_args.append("g_" + re.sub(r'[.\-]', '_', ir_name))
                continue
            # TYPE %name  or  TYPE value
            tokens = part.split(None, 1)
            if len(tokens) == 2:
                c_args.append(self._resolve_operand(tokens[1]))
            else:
                c_args.append(self._resolve_operand(tokens[0]))

        return ", ".join(c_args)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _resolve_val(self, ir_type: str, val_str: str) -> str:
        val_str = val_str.strip()
        # ИСПРАВЛЕНО: добавляем обработку null
        if val_str == "null":
            return "NULL"
        if val_str.startswith("%"):
            name = val_str[1:]
            return self._temps.get(name, name)
        if val_str in ("true", "1") and ir_type == "i1":
            return "1"
        if val_str in ("false", "0") and ir_type == "i1":
            return "0"
        return val_str

    def _resolve_operand(self, op: str) -> str:
        op = op.strip()
        # ИСПРАВЛЕНО: добавляем обработку null здесь тоже
        if op == "null":
            return "NULL"
        if op.startswith("%"):
            name = op[1:]
            return self._temps.get(name, name)
        if op.startswith("@"):
            ir_name = op[1:]
            if ir_name in self._globals:
                return self._globals[ir_name][0]
            return "g_" + re.sub(r'[.\-]', '_', ir_name)
        return op

    def _ir_type_to_c(self, ir_type: str) -> str:
        return {
            "i1":     "int",
            "i8":     "int8_t",
            "i16":    "int16_t",
            "i32":    "int32_t",
            "i64":    "int64_t",
            "u8":     "uint8_t",
            "u32":    "uint32_t",
            "u64":    "uint64_t",
            "double": "double",
            "float":  "float",
            "ptr":    "void*",
            "void":   "void",
        }.get(ir_type, "int32_t")

    def _emit(self, line: str):
        self._out.append(line)


# ── Linker ────────────────────────────────────────────────────────────────────

def link(
    ir:          str,
    output_path: str,
    *,
    emit_c:      bool = False,
    verbose:     bool = False,
) -> LinkResult:
    """
    Stage 7: transpile IR → C → binary via gcc.

    Args:
        ir:          LLVM IR string from Stage 6
        output_path: destination binary path
        emit_c:      if True, also return the generated C in result.c_source
        verbose:     print gcc command
    Returns:
        LinkResult
    """
    # Step 1 — transpile
    transpiler = IRTranspiler()
    c_source   = transpiler.transpile(ir)

    # Step 2 — write C to temp file
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    with tempfile.NamedTemporaryFile(
        suffix=".c", mode="w", delete=False, encoding="utf-8"
    ) as tf:
        tf.write(c_source)
        c_path = tf.name

    # Step 3 — compile with gcc
    cmd = ["gcc", c_path, "-o", output_path, "-lm"]
    if verbose:
        print(f"         gcc {' '.join(cmd[1:])}")

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            return LinkResult(
                success=False,
                error=proc.stderr,
                c_source=c_source if emit_c else "",
            )
    except FileNotFoundError:
        return LinkResult(
            success=False,
            error="gcc not found. Install gcc to enable Stage 7.",
        )
    finally:
        os.unlink(c_path)

    return LinkResult(
        success=True,
        output_path=output_path,
        c_source=c_source if emit_c else "",
    )
